"""
rewriter.py
===========
Riscrittura URL nei contenuti scaricati per consentire navigazione offline:
- HTML: aggiorna href/src/srcset/style inline puntando ai file locali
- CSS:  aggiorna url(...) e @import puntando ai file locali

I link a URL non scaricati (esterni esclusi, errori, asset non rilevati,
pagine fuori dal limite di profondità/pagine) vengono riscritti come URL
assoluti completi (anche se nel sorgente erano relativi o root-relative):
aprendo i file localmente (file://) un link del genere punta comunque a
una risorsa valida online, invece di risolversi contro il filesystem
locale (es. "/pagina" aperto da file:// cercherebbe la radice del disco).
"""

from __future__ import annotations
import logging
import re
from typing import Dict, Optional, Tuple
from bs4 import BeautifulSoup

from .config import HTML_URL_ATTRS, SRCSET_ATTRS, META_URL_KEYS, CSS_URL_RE, CSS_IMPORT_RE
from .utils import normalize_url, relative_path, parse_srcset


log = logging.getLogger("sitecloner.rewriter")


class LinkRewriter:
    """
    Riscrive link nei contenuti.
    Costruito una sola volta dal Crawler con lo snapshot finale del registry.
    """

    def __init__(self, url_to_local: Dict[str, str]) -> None:
        self.url_to_local = url_to_local

    def _resolve(
        self, raw_url: str, base_url: str, current_file: str
    ) -> Tuple[Optional[str], Optional[str]]:
        """
        Risolve `raw_url` (così com'è nel sorgente).

        Ritorna (local_relative_path, absolute_url):
        - local_relative_path: path relativo POSIX verso il file locale se
          la risorsa è stata scaricata e mappata, altrimenti None.
        - absolute_url: l'URL assoluto normalizzato, utile come fallback
          quando la risorsa non è stata scaricata (link esterno, scartato
          per profondità/dominio, errore, ecc.). None solo se `raw_url` non
          è un URL http/https valido (es. mailto:, javascript:, data:).
        """
        if not raw_url:
            return None, None
        abs_url = normalize_url(raw_url, base_url)
        if not abs_url:
            return None, None
        local_target = self.url_to_local.get(abs_url)
        if not local_target:
            return None, abs_url
        return relative_path(current_file, local_target), abs_url

    # ------------------------------------------------------------------
    # HTML
    # ------------------------------------------------------------------

    def rewrite_html(
        self,
        soup: BeautifulSoup,
        base_url: str,
        current_file: str,
    ) -> str:
        """
        Riscrive in-place gli URL nel soup, poi ritorna l'HTML serializzato.
        """
        rewritten = 0

        # Rimuove <base href="..."> per non interferire con la risoluzione
        # dei link relativi in locale. Tutti gli URL sono già stati
        # riscritti come path relativi alla pagina corrente.
        for base_tag in soup.find_all("base"):
            if base_tag.get("href"):
                base_tag.decompose()
                rewritten += 1

        for tag_name, attr in HTML_URL_ATTRS:
            for node in soup.find_all(tag_name):
                raw = node.get(attr)
                if not raw:
                    continue

                # Filtra meta non interessanti
                if tag_name == "meta":
                    key = (node.get("property") or node.get("name") or "").lower()
                    if key not in META_URL_KEYS:
                        continue

                # srcset: lista
                if attr in SRCSET_ATTRS:
                    new_parts = []
                    changed = False
                    # Conserviamo i descriptor (1x, 200w, ...)
                    for candidate in re.split(r",(?![^(]*\))", raw):
                        candidate = candidate.strip()
                        if not candidate:
                            continue
                        tokens = candidate.split(None, 1)
                        url_part = tokens[0]
                        descriptor = " " + tokens[1] if len(tokens) > 1 else ""
                        local, abs_url = self._resolve(url_part, base_url, current_file)
                        if local:
                            new_parts.append(local + descriptor)
                            changed = True
                        elif abs_url and abs_url != url_part:
                            new_parts.append(abs_url + descriptor)
                            changed = True
                        else:
                            new_parts.append(candidate)
                    if changed:
                        node[attr] = ", ".join(new_parts)
                        rewritten += 1
                    continue

                # Singolo URL
                local, abs_url = self._resolve(raw, base_url, current_file)
                if local:
                    node[attr] = local
                    rewritten += 1
                elif abs_url and abs_url != raw:
                    node[attr] = abs_url
                    rewritten += 1

        # Riscrittura style inline
        for node in soup.find_all(style=True):
            style_val = node.get("style") or ""
            new_style = self._rewrite_css_text(style_val, base_url, current_file)
            if new_style != style_val:
                node["style"] = new_style
                rewritten += 1

        # Riscrittura <style>
        for style_tag in soup.find_all("style"):
            css = style_tag.string
            if not css:
                continue
            new_css = self._rewrite_css_text(css, base_url, current_file)
            if new_css != css:
                style_tag.string = new_css
                rewritten += 1

        log.debug("HTML rewritten: %d url(s) updated in %s", rewritten, current_file)
        return str(soup)

    # ------------------------------------------------------------------
    # CSS
    # ------------------------------------------------------------------

    def rewrite_css(self, css_text: str, base_url: str, current_file: str) -> str:
        """Riscrive url(...) e @import in un file CSS standalone."""
        return self._rewrite_css_text(css_text, base_url, current_file)

    def _rewrite_css_text(self, css_text: str, base_url: str, current_file: str) -> str:
        if not css_text:
            return css_text

        def replace_url(match: re.Match) -> str:
            raw = match.group("u1") or match.group("u2") or ""
            if not raw or raw.startswith(("data:", "#")):
                return match.group(0)
            local, abs_url = self._resolve(raw, base_url, current_file)
            if local:
                return f"url('{local}')"
            if abs_url and abs_url != raw:
                return f"url('{abs_url}')"
            return match.group(0)

        def replace_import(match: re.Match) -> str:
            raw = match.group("u1") or match.group("u2") or ""
            if not raw:
                return match.group(0)
            local, abs_url = self._resolve(raw, base_url, current_file)
            if local:
                return f"@import url('{local}');"
            if abs_url and abs_url != raw:
                return f"@import url('{abs_url}');"
            return match.group(0)

        # Order matters: import prima di url() generico, ma il regex di import
        # cattura anche la forma url(...) per evitare doppi match
        result = CSS_IMPORT_RE.sub(replace_import, css_text)
        result = CSS_URL_RE.sub(replace_url, result)
        return result
