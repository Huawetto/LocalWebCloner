"""
parsers.py
==========
Estrazione URL dai contenuti:
- HTML: tutti gli attributi href/src/data-*, srcset, meta og:*, manifest, ecc.
- CSS:  url(...) e @import, anche annidati
- Inline style="...": idem
- Metadati: email, telefoni, link social

Mantengo il DOM BeautifulSoup originale per consentire la successiva
*riscrittura* dei link nel rewriter, senza ri-parsare il documento.
"""

from __future__ import annotations
import re
import logging
from dataclasses import dataclass, field
from typing import List, Set, Tuple, Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from .config import (
    HTML_URL_ATTRS,
    SRCSET_ATTRS,
    META_URL_KEYS,
    CSS_URL_RE,
    CSS_IMPORT_RE,
    EMAIL_RE,
    PHONE_RE,
    SOCIAL_DOMAINS,
)
from .utils import normalize_url, parse_srcset


log = logging.getLogger("sitecloner.parsers")


@dataclass
class ExtractedUrl:
    """Un URL trovato in un documento, con contesto per la riscrittura."""
    url: str                # URL assoluto e normalizzato
    raw: str                # valore originale così com'era nell'HTML/CSS
    location: str           # "html_attr" | "srcset" | "css_url" | "css_import" | "inline_style" | "meta"
    element_id: Optional[int] = None  # id(soup_node) per identificare il tag durante la riscrittura


@dataclass
class HtmlExtractionResult:
    """Risultato del parsing HTML."""
    soup: BeautifulSoup
    urls: List[ExtractedUrl] = field(default_factory=list)
    emails: Set[str] = field(default_factory=set)
    phones: Set[str] = field(default_factory=set)
    social_links: Set[str] = field(default_factory=set)


# ---------------------------------------------------------------------------
# HTML parsing
# ---------------------------------------------------------------------------

# Validazione "telefono plausibile" (almeno 7 cifre, max 15 - standard E.164)
_PHONE_DIGIT_RE = re.compile(r"\d")


def _is_plausible_phone(raw: str) -> bool:
    digits = _PHONE_DIGIT_RE.findall(raw)
    return 7 <= len(digits) <= 15


def _detect_parser() -> str:
    """Usa lxml se disponibile (più veloce), altrimenti html.parser."""
    try:
        import lxml  # noqa: F401
        return "lxml"
    except ImportError:
        return "html.parser"


_HTML_PARSER = _detect_parser()


def extract_from_html(
    html: str | bytes,
    base_url: str,
    *,
    parse_inline_styles: bool = True,
    extract_metadata: bool = True,
) -> HtmlExtractionResult:
    """
    Parsa una pagina HTML estraendo tutti gli URL referenziati e i metadati.
    Restituisce un soup modificabile (per la fase successiva di riscrittura).
    """
    soup = BeautifulSoup(html, _HTML_PARSER)
    result = HtmlExtractionResult(soup=soup)

    # <base href="..."> sovrascrive base_url
    base_tag = soup.find("base", href=True)
    if base_tag and base_tag.get("href"):
        try:
            base_url = urljoin(base_url, base_tag["href"].strip())
        except Exception:
            pass

    # Estrazione attributi HTML standard
    seen_combos: Set[Tuple[int, str, str]] = set()  # dedup per (tag-id, attr, raw)
    for tag_name, attr in HTML_URL_ATTRS:
        for node in soup.find_all(tag_name):
            raw = node.get(attr)
            if not raw:
                continue

            # Filtro meta: solo property/name interessanti
            if tag_name == "meta":
                key = (node.get("property") or node.get("name") or "").lower()
                if key not in META_URL_KEYS:
                    continue

            # srcset: lista di URL
            if attr in SRCSET_ATTRS:
                for sub in parse_srcset(raw):
                    abs_url = normalize_url(sub, base_url)
                    if abs_url:
                        combo = (id(node), attr, sub)
                        if combo not in seen_combos:
                            seen_combos.add(combo)
                            result.urls.append(ExtractedUrl(
                                url=abs_url, raw=sub,
                                location="srcset", element_id=id(node),
                            ))
                continue

            # Caso normale: singolo URL
            abs_url = normalize_url(raw, base_url)
            if abs_url:
                combo = (id(node), attr, raw)
                if combo in seen_combos:
                    continue
                seen_combos.add(combo)
                location = "meta" if tag_name == "meta" else "html_attr"
                result.urls.append(ExtractedUrl(
                    url=abs_url, raw=raw,
                    location=location, element_id=id(node),
                ))

    # Inline style="..." e <style>...</style>
    if parse_inline_styles:
        # style inline negli elementi
        for node in soup.find_all(style=True):
            css_inline = node.get("style") or ""
            for raw_url, abs_url in _extract_from_css_text(css_inline, base_url):
                result.urls.append(ExtractedUrl(
                    url=abs_url, raw=raw_url,
                    location="inline_style", element_id=id(node),
                ))

        # <style> tags
        for style_tag in soup.find_all("style"):
            css_text = style_tag.string or ""
            for raw_url, abs_url in _extract_from_css_text(css_text, base_url):
                result.urls.append(ExtractedUrl(
                    url=abs_url, raw=raw_url,
                    location="inline_style", element_id=id(style_tag),
                ))

    # Metadati testuali
    if extract_metadata:
        text = soup.get_text(separator=" ", strip=True)
        result.emails.update(EMAIL_RE.findall(text))
        for m in PHONE_RE.findall(text):
            if _is_plausible_phone(m):
                normalized = re.sub(r"[\s\-.()]", "", m)
                result.phones.add(normalized)

        # Anche href mailto:/tel: arricchiscono emails/phones
        for a in soup.find_all("a", href=True):
            href = a["href"].strip()
            if href.lower().startswith("mailto:"):
                addr = href[7:].split("?", 1)[0]
                if EMAIL_RE.match(addr):
                    result.emails.add(addr)
            elif href.lower().startswith("tel:"):
                num = href[4:]
                if _is_plausible_phone(num):
                    result.phones.add(re.sub(r"[\s\-.()]", "", num))

        # Social media links
        for eu in result.urls:
            host = _hostname(eu.url)
            if host and any(host == d or host.endswith("." + d) for d in SOCIAL_DOMAINS):
                result.social_links.add(eu.url)

    return result


def _hostname(url: str) -> str:
    """Estrae hostname lowercase da un URL (senza www.)."""
    try:
        from urllib.parse import urlparse
        host = urlparse(url).netloc.lower()
        return host[4:] if host.startswith("www.") else host
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# CSS parsing
# ---------------------------------------------------------------------------

def _extract_from_css_text(css_text: str, base_url: str) -> List[Tuple[str, str]]:
    """
    Estrae (raw_url, absolute_url) da un blocco CSS.
    Funziona su CSS completi o frammenti inline.
    """
    if not css_text:
        return []
    out: List[Tuple[str, str]] = []

    # @import "..." | url(...)
    for m in CSS_IMPORT_RE.finditer(css_text):
        raw = m.group("u1") or m.group("u2")
        if not raw:
            continue
        raw = raw.strip()
        if raw.startswith("data:"):
            continue
        abs_url = normalize_url(raw, base_url)
        if abs_url:
            out.append((raw, abs_url))

    # url(...) generico — esclude quelli già catturati da @import
    # (li ri-includiamo: deduplica avviene a livello di registry, quindi non causa problemi)
    for m in CSS_URL_RE.finditer(css_text):
        raw = m.group("u1") or m.group("u2")
        if not raw:
            continue
        raw = raw.strip()
        if raw.startswith(("data:", "#")):
            continue
        abs_url = normalize_url(raw, base_url)
        if abs_url:
            out.append((raw, abs_url))

    return out


@dataclass
class CssExtractionResult:
    """Risultato del parsing di un file CSS."""
    text: str
    urls: List[Tuple[str, str]] = field(default_factory=list)  # (raw, absolute)


def extract_from_css(css_text: str, base_url: str) -> CssExtractionResult:
    """Estrae tutti gli URL da un file CSS standalone."""
    return CssExtractionResult(
        text=css_text,
        urls=_extract_from_css_text(css_text, base_url),
    )
