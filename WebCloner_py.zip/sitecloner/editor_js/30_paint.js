/* ------------------------------------------------ editor "Paint" per le immagini */
SC.openPaint = async function (img) {
    var src = img.currentSrc || img.src;
    if (!src) { SC.toast("Immagine senza sorgente", "err"); return; }
    var im = new Image();
    im.crossOrigin = "anonymous";
    try {
        await new Promise(function (res, rej) { im.onload = res; im.onerror = rej; im.src = src; });
    } catch (e) { SC.toast("Impossibile caricare l'immagine nell'editor", "err"); return; }
    var W = im.naturalWidth || 400, H = im.naturalHeight || 300;
    var cv = document.createElement("canvas"); cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(im, 0, 0);
    try { ctx.getImageData(0, 0, 1, 1); }
    catch (e) { SC.toast("Canvas bloccato dal browser (file:// o dominio diverso): apri il sito dal server di editing per usare il Paint", "err"); return; }

    var S = { tool: "pen", color: "#ff0000", size: 8, alpha: 100, fill: false, tol: 24 };
    var undo = [ctx.getImageData(0, 0, W, H)], redo = [], base = null, start = null, last = null, drawing = false;
    var original = ctx.getImageData(0, 0, W, H);

    cv.style.cssText = "max-width:min(78vw,1100px);max-height:64vh;cursor:crosshair;background:conic-gradient(#555 25%,#777 0 50%,#555 0 75%,#777 0) 0 0/16px 16px;touch-action:none";

    function pos(e) {
        var r = cv.getBoundingClientRect();
        return { x: (e.clientX - r.left) * W / r.width, y: (e.clientY - r.top) * H / r.height };
    }
    function style() { ctx.globalAlpha = S.alpha / 100; ctx.strokeStyle = S.color; ctx.fillStyle = S.color; ctx.lineWidth = S.size; ctx.lineCap = "round"; ctx.lineJoin = "round"; }
    function pushUndo() { undo.push(ctx.getImageData(0, 0, W, H)); if (undo.length > 30) undo.shift(); redo = []; }
    function pickAt(p) {
        var d = ctx.getImageData(clamp(Math.floor(p.x), 0, W - 1), clamp(Math.floor(p.y), 0, H - 1), 1, 1).data;
        function t(n) { return ("0" + n.toString(16)).slice(-2); }
        S.color = "#" + t(d[0]) + t(d[1]) + t(d[2]);
        colorIn.value = S.color; hexIn.value = S.color;
        SC.toast("Colore preso: " + S.color, "ok");
    }
    function flood(p) {
        var x0 = clamp(Math.floor(p.x), 0, W - 1), y0 = clamp(Math.floor(p.y), 0, H - 1);
        var id = ctx.getImageData(0, 0, W, H), d = id.data;
        var i0 = (y0 * W + x0) * 4, tr = d[i0], tg = d[i0 + 1], tb = d[i0 + 2], ta = d[i0 + 3];
        var fc = parseColor(S.color), fa = S.alpha / 100;
        function match(i) { return Math.abs(d[i] - tr) + Math.abs(d[i + 1] - tg) + Math.abs(d[i + 2] - tb) + Math.abs(d[i + 3] - ta) <= S.tol * 4; }
        if (Math.abs(fc.r - tr) + Math.abs(fc.g - tg) + Math.abs(fc.b - tb) < 3 && fa >= 1 && ta === 255) return;
        var stack = [[x0, y0]], seen = new Uint8Array(W * H);
        while (stack.length) {
            var pt = stack.pop(), x = pt[0], y = pt[1];
            if (x < 0 || y < 0 || x >= W || y >= H) continue;
            var k = y * W + x;
            if (seen[k]) continue;
            var i = k * 4;
            if (!match(i)) continue;
            seen[k] = 1;
            d[i] = Math.round(d[i] * (1 - fa) + fc.r * fa); d[i + 1] = Math.round(d[i + 1] * (1 - fa) + fc.g * fa); d[i + 2] = Math.round(d[i + 2] * (1 - fa) + fc.b * fa); d[i + 3] = 255;
            stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
        }
        ctx.putImageData(id, 0, 0);
    }
    function shape(a, b) {
        ctx.putImageData(base, 0, 0); style();
        ctx.beginPath();
        if (S.tool === "line") { ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); return; }
        if (S.tool === "rect") { ctx.rect(a.x, a.y, b.x - a.x, b.y - a.y); }
        if (S.tool === "ellipse") { ctx.ellipse((a.x + b.x) / 2, (a.y + b.y) / 2, Math.abs(b.x - a.x) / 2, Math.abs(b.y - a.y) / 2, 0, 0, Math.PI * 2); }
        if (S.fill) ctx.fill(); else ctx.stroke();
    }
    cv.addEventListener("pointerdown", function (e) {
        e.preventDefault();
        var p = pos(e);
        if (S.tool === "picker" || e.altKey) { try { pickAt(p); } catch (er) { SC.toast("Lettura pixel non consentita", "err"); } return; }
        if (S.tool === "fill") { pushUndo(); flood(p); return; }
        if (S.tool === "text") {
            var t = prompt("Testo da scrivere:"); if (!t) return;
            pushUndo(); style(); ctx.font = (S.size * 3) + "px sans-serif"; ctx.textBaseline = "top"; ctx.fillText(t, p.x, p.y); return;
        }
        cv.setPointerCapture(e.pointerId);
        drawing = true; start = p; last = p; pushUndo();
        base = ctx.getImageData(0, 0, W, H);
        if (S.tool === "pen" || S.tool === "eraser") {
            style(); ctx.beginPath();
            if (S.tool === "eraser") { ctx.globalCompositeOperation = "destination-out"; ctx.globalAlpha = 1; }
            ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + 0.01, p.y + 0.01); ctx.stroke();
            ctx.globalCompositeOperation = "source-over";
        }
    });
    cv.addEventListener("pointermove", function (e) {
        if (!drawing) return;
        var p = pos(e);
        if (S.tool === "pen" || S.tool === "eraser") {
            style();
            if (S.tool === "eraser") { ctx.globalCompositeOperation = "destination-out"; ctx.globalAlpha = 1; }
            ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke();
            ctx.globalCompositeOperation = "source-over";
            last = p;
        } else shape(start, p);
    });
    cv.addEventListener("pointerup", function () { drawing = false; ctx.globalAlpha = 1; });

    function restore(id) { ctx.putImageData(id, 0, 0); }
    function doUndo() { if (undo.length < 2) return; redo.push(undo.pop()); restore(undo[undo.length - 1]); }
    function doRedo() { if (!redo.length) return; var s = redo.pop(); undo.push(s); restore(s); }
    function transform(fn) {
        pushUndo();
        var tmp = document.createElement("canvas"); tmp.width = cv.width; tmp.height = cv.height; tmp.getContext("2d").drawImage(cv, 0, 0);
        fn(tmp); W = cv.width; H = cv.height; undo[undo.length - 1] = ctx.getImageData(0, 0, W, H);
    }
    function rot90() {
        transform(function (tmp) { cv.width = tmp.height; cv.height = tmp.width; ctx.save(); ctx.translate(cv.width, 0); ctx.rotate(Math.PI / 2); ctx.drawImage(tmp, 0, 0); ctx.restore(); });
    }
    function flip(h_) {
        transform(function (tmp) { ctx.save(); ctx.clearRect(0, 0, cv.width, cv.height); if (h_) { ctx.translate(cv.width, 0); ctx.scale(-1, 1); } else { ctx.translate(0, cv.height); ctx.scale(1, -1); } ctx.drawImage(tmp, 0, 0); ctx.restore(); });
    }

    var colorIn = ui.color(S.color, function (v) { S.color = v; hexIn.value = v; });
    var hexIn = h("input", { type: "text", value: S.color, style: "width:76px" });
    hexIn.addEventListener("input", function () { if (/^#[0-9a-f]{6}$/i.test(hexIn.value)) { S.color = hexIn.value; colorIn.value = hexIn.value; } });
    var toolBtns = {};
    function setTool(t) { S.tool = t; Object.keys(toolBtns).forEach(function (k) { toolBtns[k].classList.toggle("on", k === t); }); }
    [["pen", "Penna"], ["eraser", "Gomma"], ["line", "Linea"], ["rect", "Rettangolo"], ["ellipse", "Ellisse"], ["fill", "Secchiello"], ["picker", "Contagocce"], ["text", "Testo"]].forEach(function (t) {
        toolBtns[t[0]] = ui.btn(t[1], function () { setTool(t[0]); });
    });
    setTool("pen");
    var close = function () { modal.remove(); };
    var modal = h("div", { class: "modal", "data-sc-ui": "1" },
        h("div", { class: "box" },
            h("div", { class: "hd" }, h("b", { text: "Paint - " + W + "x" + H }), Object.keys(toolBtns).map(function (k) { return toolBtns[k]; })),
            h("div", { class: "hd" },
                "Colore", colorIn, hexIn,
                ui.btn("Contagocce schermo", async function () {
                    if (!window.EyeDropper) { SC.toast("EyeDropper non supportato: usa lo strumento Contagocce sul disegno", "warn"); return; }
                    try { var r = await new EyeDropper().open(); S.color = r.sRGBHex; colorIn.value = S.color; hexIn.value = S.color; } catch (e) {}
                }, "sm"),
                "Dimensione penna", ui.range(S.size, { min: 1, max: 120 }, function (v) { S.size = v; }),
                "Opacita %", ui.num(S.alpha, { min: 1, max: 100, w: "56px" }, function (v) { S.alpha = v; }),
                ui.check("riempi forme", false, function (v) { S.fill = v; }),
                "Tolleranza secchiello", ui.num(S.tol, { min: 0, max: 100, w: "56px" }, function (v) { S.tol = v; })),
            h("div", { class: "bd", style: "text-align:center" }, cv),
            h("div", { class: "hd" },
                ui.btn("Annulla", doUndo, "sm"), ui.btn("Ripeti", doRedo, "sm"),
                ui.btn("Ruota 90", rot90, "sm"), ui.btn("Specchia orizz.", function () { flip(true); }, "sm"), ui.btn("Specchia vert.", function () { flip(false); }, "sm"),
                ui.btn("Ripristina originale", function () { pushUndo(); cv.width = original.width; cv.height = original.height; W = cv.width; H = cv.height; ctx.putImageData(original, 0, 0); }, "sm danger"),
                h("span", { style: "flex:1" }),
                ui.btn("Annulla modifiche", close),
                ui.btn("Applica all'immagine", async function () {
                    try {
                        var url = await SC.canvasToUrl(cv, "paint-" + Date.now() + ".png");
                        SC.setImageSrc(img, url); SC.commit("Immagine disegnata"); close(); SC.refreshPane();
                        SC.toast("Immagine aggiornata", "ok");
                    } catch (e) { SC.toast("Errore: " + e.message, "err"); }
                }, "primary"))));
    SC.shadow.appendChild(modal);
};
