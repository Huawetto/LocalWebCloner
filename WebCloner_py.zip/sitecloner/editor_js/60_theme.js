/* --------------------------------------------------------------- Main Themes */
var theme = SC.theme = {};
var COLOR_RE = /#[0-9a-f]{8}\b|#[0-9a-f]{6}\b|#[0-9a-f]{3,4}\b|rgba?\([^)]*\)|hsla?\([^)]*\)/gi;
var COLOR_PROPS = ["color", "background-color", "border-top-color", "border-right-color", "border-bottom-color", "border-left-color", "outline-color", "fill", "stroke", "text-decoration-color", "caret-color", "column-rule-color"];
var BG_PROPS = { "background-color": 1 };

function hexOf(v) { var p = parseColor(v); return p.a < 0.5 ? null : toHex(v); }
function eachRule(rules, wrap, fn) {
    Array.prototype.forEach.call(rules, function (r) {
        if (r.type === 1) fn(r, wrap);
        else if (r.cssRules && (r.type === 4 || r.type === 12)) eachRule(r.cssRules, wrap + (r.type === 4 ? "@media " + r.conditionText + "{" : "@supports " + r.conditionText + "{"), fn);
    });
}
function eachSheet(fn) {
    Array.prototype.forEach.call(document.styleSheets, function (sh) {
        var n = sh.ownerNode;
        if (n && n.id && n.id.indexOf("sc-") === 0) return;
        try { fn(sh.cssRules); } catch (e) { /* cross-origin */ }
    });
}
function closeWrap(w) { return new Array((w.match(/\{/g) || []).length + 1).join("}"); }

theme.collect = function () {
    var counts = {}, vars = {};
    eachSheet(function (rules) {
        eachRule(rules, "", function (r) {
            var st = r.style;
            for (var i = 0; i < st.length; i++) {
                var name = st[i], val = st.getPropertyValue(name);
                if (name.indexOf("--") === 0) {
                    if (r.selectorText && /^(:root|html|body)$/.test(r.selectorText.trim()) && /^\s*(#|rgb|hsl)/i.test(val)) { var hx = hexOf(val.trim()); if (hx) vars[name] = hx; }
                    continue;
                }
                if (COLOR_PROPS.indexOf(name) < 0 || /var\(/.test(val)) continue;
                var m = val.match(COLOR_RE);
                if (!m) continue;
                var hx2 = hexOf(m[0]);
                if (hx2) counts[hx2] = (counts[hx2] || 0) + (BG_PROPS[name] ? 2 : 1);
            }
        });
    });
    var list = Object.keys(counts).map(function (c) {
        var p = parseColor(c), mx = Math.max(p.r, p.g, p.b), mn = Math.min(p.r, p.g, p.b), sat = mx ? (mx - mn) / mx : 0;
        return { c: c, n: counts[c], score: counts[c] * (1 + sat * 3) };
    }).sort(function (a, b) { return b.score - a.score; });
    return { colors: list, vars: vars };
};

function hexToHsl(hex) {
    var p = parseColor(hex), r = p.r / 255, g = p.g / 255, b = p.b / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, s = 0, hh = 0;
    if (mx !== mn) {
        var d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
        hh = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; hh *= 60;
    }
    return { h: hh, s: s * 100, l: l * 100 };
}
theme.shift = function (hex, dh, ds, dl) {
    var c = hexToHsl(hex);
    return toHex(hsl((c.h + dh + 360) % 360, clamp(c.s + ds, 0, 100), clamp(c.l + dl, 0, 100)));
};

/* map: { "#orig": {mode:"color", color:"#new"} | {mode:"gradient", grad:{...}} }, vars: { "--x": "#new" } */
theme.build = function (map, vars) {
    var out = [];
    var keys = Object.keys(map || {});
    if (keys.length) {
        eachSheet(function (rules) {
            eachRule(rules, "", function (r, wrap) {
                var st = r.style, decl = [];
                COLOR_PROPS.forEach(function (p) {
                    var v = st.getPropertyValue(p);
                    if (!v || /var\(/.test(v)) return;
                    var m = v.match(COLOR_RE); if (!m) return;
                    var hx = hexOf(m[0]); if (!hx || !map[hx]) return;
                    var t = map[hx];
                    if (t.mode === "gradient") {
                        if (BG_PROPS[p]) decl.push("background-image:" + grad.css(t.grad) + "!important");
                        else decl.push(p + ":" + t.grad.stops[0].c + "!important");
                    } else decl.push(p + ":" + t.color + "!important");
                });
                if (decl.length) out.push(wrap + r.selectorText + "{" + decl.join(";") + "}" + closeWrap(wrap));
            });
        });
    }
    var vk = Object.keys(vars || {});
    if (vk.length) out.unshift(":root{" + vk.map(function (k) { return k + ":" + vars[k] + "!important"; }).join(";") + "}");
    return out.join("\n");
};
theme.apply = function (doc, map, vars) {
    var m = cssMgr(doc);
    var css = theme.build(map, vars);
    if (!css) { m.del("theme"); m.del("theme-map"); return; }
    m.set("theme", css);
    m.set("theme-map", "/*" + JSON.stringify({ map: map, vars: vars }) + "*/");
};
theme.load = function () {
    var s = SC.css.get("theme-map");
    if (!s) return { map: {}, vars: {} };
    try { return JSON.parse(s.replace(/^\/\*/, "").replace(/\*\/$/, "")); } catch (e) { return { map: {}, vars: {} }; }
};
theme.randomMap = function (found) {
    var map = {}, vars = {};
    found.colors.slice(0, 16).forEach(function (c) { map[c.c] = { mode: "color", color: toHex(randGoodColor()) }; });
    Object.keys(found.vars).forEach(function (k) { vars[k] = toHex(randGoodColor()); });
    return { map: map, vars: vars };
};

SC.addTab("theme", "Tema", function (root) {
    var found = theme.collect();
    var st = theme.load();
    var map = st.map || {}, vars = st.vars || {};
    var live = debounce(function () { theme.apply(document, map, vars); SC.commit("Tema modificato"); }, 250);

    root.appendChild(ui.hint("Colori principali del tema del sito (letti dai fogli di stile). Cambiali per fare il redesign: la modifica e' un livello che si puo' rimuovere in qualsiasi momento."));
    var wrap = h("div", {});
    function draw() {
        wrap.innerHTML = "";
        if (!found.colors.length && !Object.keys(found.vars).length) wrap.appendChild(ui.hint("Nessun colore trovato (fogli di stile non leggibili da file://? Usa il server di editing)."));
        found.colors.slice(0, 16).forEach(function (c) {
            var cur = map[c.c];
            var box = h("div", { style: "border-bottom:1px solid #2a3138;padding:5px 0" });
            var gbox = h("div", {});
            var row = h("div", { class: "row" },
                h("span", { class: "sw", style: "background:" + c.c, title: "originale " + c.c }), h("span", { class: "hint", text: c.c + " (" + c.n + "x)" }), h("span", { text: "->" }),
                ui.color(cur && cur.mode === "color" ? cur.color : c.c, function (v) { map[c.c] = { mode: "color", color: v }; gbox.innerHTML = ""; live(); }),
                ui.check("gradient", cur && cur.mode === "gradient", function (on) {
                    if (on) { map[c.c] = { mode: "gradient", grad: grad.make(c.c, theme.shift(c.c, 40, 0, 0)) }; drawG(); } else { map[c.c] = { mode: "color", color: c.c }; gbox.innerHTML = ""; }
                    live();
                }),
                ui.btn("ripristina", function () { delete map[c.c]; live(); draw(); }, "sm"));
            function drawG() { gbox.innerHTML = ""; var t = map[c.c]; if (t && t.mode === "gradient") gbox.appendChild(grad.editor(t.grad, live)); }
            box.append(row, gbox); drawG();
            wrap.appendChild(box);
        });
        var vk = Object.keys(found.vars);
        if (vk.length) {
            var vb = h("div", {});
            vk.forEach(function (k) {
                vb.appendChild(ui.row(k.slice(0, 22), h("span", { class: "sw", style: "background:" + found.vars[k] }), "->",
                    ui.color(vars[k] || found.vars[k], function (v) { vars[k] = v; live(); }),
                    ui.btn("x", function () { delete vars[k]; live(); draw(); }, "sm")));
            });
            wrap.appendChild(ui.section("Variabili CSS (:root) - " + vk.length, vb, false));
        }
    }
    draw();

    var hue = 0, sat = 0, lig = 0;
    function global() {
        found.colors.slice(0, 16).forEach(function (c) { map[c.c] = { mode: "color", color: theme.shift(c.c, hue, sat, lig) }; });
        Object.keys(found.vars).forEach(function (k) { vars[k] = theme.shift(found.vars[k], hue, sat, lig); });
        live();
    }
    root.appendChild(ui.section("Ritocco globale della palette", h("div", {},
        ui.row("Tinta", ui.range(0, { min: -180, max: 180 }, function (v) { hue = v; global(); })),
        ui.row("Saturazione", ui.range(0, { min: -100, max: 100 }, function (v) { sat = v; global(); })),
        ui.row("Luminosita'", ui.range(0, { min: -60, max: 60 }, function (v) { lig = v; global(); })),
        ui.hint("Trascina e poi, se vuoi, ritocca i singoli colori qui sotto.")), true));
    root.appendChild(h("div", { class: "row" },
        ui.btn("Random", function () { var r = theme.randomMap(found); map = r.map; vars = r.vars; live(); draw(); }, "sm"),
        ui.btn("Rimuovi tema", function () { map = {}; vars = {}; theme.apply(document, {}, {}); SC.commit("Tema rimosso"); draw(); }, "sm danger"),
        ui.btn("Applica a TUTTE le pagine", function () {
            theme.apply(document, map, vars);
            var css = SC.css.get("theme"), mp = SC.css.get("theme-map");
            SC.siteWide(function (doc) { var m = cssMgr(doc); if (css) { m.set("theme", css); m.set("theme-map", mp); } else { m.del("theme"); m.del("theme-map"); } }, "Tema applicato");
        }, "primary")));
    root.appendChild(wrap);
}, 40);
