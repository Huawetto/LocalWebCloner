/* ------------------------------------------------------------- Script editor + IDE */
var SCR = { sort: "size", dir: "desc", filter: "", types: { js: true, css: false, inline: true }, files: null, loading: false };

function fmtSize(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : n > 1024 ? (n / 1024).toFixed(1) + " KB" : n + " B"; }
function fmtDate(t) { if (!t) return "-"; var d = new Date(t * 1000); return d.toLocaleDateString() + " " + d.toLocaleTimeString().slice(0, 5); }
function extOf(p) { var m = /\.[^.\/]+$/.exec(p); return m ? m[0].toLowerCase() : ""; }

function inlineScripts() {
    var out = [];
    document.querySelectorAll("script:not([src])").forEach(function (s, i) {
        if (s.id === "sc-runtime" || SC.isUI(s)) return;
        var t = (s.getAttribute("type") || "").toLowerCase();
        if (t && !/javascript|module|^$/.test(t)) return;
        out.push({ kind: "inline", el: s, path: "(inline #" + (i + 1) + (s.id ? " id=" + s.id : "") + ")", ext: ".js", size: s.textContent.length, mtime: 0 });
    });
    return out;
}

async function loadScriptFiles() {
    if (!SC.server) { SCR.files = []; return; }
    SCR.loading = true;
    try {
        var r = await SC.api("files", { query: { ext: "js,mjs,cjs,css" } });
        SCR.files = r.files.map(function (f) { return { kind: "file", path: f.path, ext: extOf(f.path), size: f.size, mtime: f.mtime }; });
    } catch (e) { SCR.files = []; SC.toast(e.message, "err"); }
    SCR.loading = false;
}

SC.addTab("scripts", "Script", function (root) {
    if (SCR.files === null && !SCR.loading) { loadScriptFiles().then(function () { if (SC.active === "scripts") SC.renderPane(); }); }
    var head = h("div", {});
    head.appendChild(ui.row("Ordina per", ui.select([["size", "Grandezza"], ["date", "Data modifica"], ["name", "Nome"]], SCR.sort, function (v) { SCR.sort = v; SC.renderPane(); }),
        ui.btn(SCR.dir === "desc" ? "Decrescente" : "Crescente", function () { SCR.dir = SCR.dir === "desc" ? "asc" : "desc"; SC.renderPane(); }, "sm")));
    head.appendChild(ui.row("Mostra", ui.check("js", SCR.types.js, function (v) { SCR.types.js = v; SC.renderPane(); }),
        ui.check("css", SCR.types.css, function (v) { SCR.types.css = v; SC.renderPane(); }), ui.check("inline", SCR.types.inline, function (v) { SCR.types.inline = v; SC.renderPane(); })));
    head.appendChild(ui.row("Cerca", ui.text(SCR.filter, function (v) { SCR.filter = v; drawRows(); }, "nome file...")));
    head.appendChild(ui.row("", ui.btn("Aggiorna elenco", function () { SCR.files = null; SC.renderPane(); }, "sm"),
        ui.btn("Nuovo file...", async function () {
            if (!SC.needServer("Creare un file")) return;
            var p = prompt("Percorso del nuovo file (es. js/mio.js), relativo a " + SC.siteRoot() + "/", "js/nuovo.js");
            if (!p) return;
            var full = SC.siteRoot() + "/" + p.replace(/^\/+/, "");
            try { await SC.api("write", { json: { path: full, content: "", skipCheck: true } }); SCR.files = null; SC.openIde({ kind: "file", path: full, ext: extOf(full) }); }
            catch (e) { SC.toast(e.message, "err"); }
        }, "sm")));
    if (!SC.server) head.appendChild(ui.hint("Server di editing non attivo: sono elencati solo gli script inline della pagina. Per editare i file .js avvia  python crawl.py --serve <cartella>."));
    var tbl = h("div", {});
    function drawRows() {
        tbl.innerHTML = "";
        var items = (SCR.files || []).concat(inlineScripts()).filter(function (it) {
            var t = it.kind === "inline" ? "inline" : it.ext === ".css" ? "css" : "js";
            if (!SCR.types[t]) return false;
            return !SCR.filter || it.path.toLowerCase().indexOf(SCR.filter.toLowerCase()) >= 0;
        });
        items.sort(function (a, b) {
            var r = SCR.sort === "size" ? a.size - b.size : SCR.sort === "date" ? a.mtime - b.mtime : a.path.localeCompare(b.path);
            return SCR.dir === "desc" ? -r : r;
        });
        var t = h("table", {}, h("tr", {}, h("th", { text: "File" }), h("th", { text: "Dim." }), h("th", { text: "Modificato" })));
        items.slice(0, 600).forEach(function (it) {
            t.appendChild(h("tr", { class: "click", onclick: function () { SC.openIde(it); } },
                h("td", { class: "mono", text: it.path.length > 52 ? "..." + it.path.slice(-50) : it.path }),
                h("td", { text: fmtSize(it.size) }), h("td", { text: fmtDate(it.mtime) })));
        });
        tbl.appendChild(h("div", { class: "hint", text: items.length + " file" + (SCR.loading ? " (carico...)" : "") + (items.length > 600 ? " - mostrati i primi 600" : "") }));
        tbl.appendChild(t);
    }
    drawRows();
    root.append(head, tbl);
}, 30);

/* -------------------------------------------------------------------------- IDE */
SC.openIde = async function (item) {
    var content = "";
    if (item.kind === "file") {
        if (!SC.needServer("Aprire un file")) return;
        try { content = (await SC.api("file", { query: { path: item.path } })).content; }
        catch (e) { SC.toast(e.message, "err"); return; }
    } else content = item.el.textContent;
    var ext = item.ext || extOf(item.path);
    var lang = ext === ".css" ? "CSS" : "JavaScript";
    var original = content;

    var ta = h("textarea", { spellcheck: "false", wrap: "off", style: "flex:1;height:100%;min-height:340px;resize:none;white-space:pre;overflow:auto;line-height:18px;font:13px/18px Consolas,monospace;border:0;border-radius:0;padding:6px;tab-size:2" });
    ta.value = content;
    var gutter = h("div", { style: "width:46px;background:#10141a;color:#6b747c;text-align:right;padding:6px 6px 6px 0;font:13px/18px Consolas,monospace;overflow:hidden;white-space:pre;user-select:none" });
    var errBox = h("div", { style: "max-height:150px;overflow:auto;padding:6px 10px;border-top:1px solid #2f363d;font:12px Consolas,monospace" });
    var pos = h("span", { class: "hint" });
    var errLines = {};
    function drawGutter() {
        var n = ta.value.split("\n").length, out = [];
        for (var i = 1; i <= n; i++) out.push(errLines[i] ? "●" + i : String(i));
        gutter.textContent = out.join("\n");
        gutter.scrollTop = ta.scrollTop;
    }
    function updPos() { var v = ta.value.slice(0, ta.selectionStart).split("\n"); pos.textContent = "Riga " + v.length + ", col " + (v[v.length - 1].length + 1) + " - " + ta.value.length + " caratteri" + (ta.value !== original ? " - MODIFICATO" : ""); }
    ta.addEventListener("input", function () { errLines = {}; drawGutter(); updPos(); });
    ta.addEventListener("scroll", function () { gutter.scrollTop = ta.scrollTop; });
    ta.addEventListener("keyup", updPos); ta.addEventListener("click", updPos);
    ta.addEventListener("keydown", function (e) {
        if (e.key === "Tab") {
            e.preventDefault();
            var s = ta.selectionStart, en = ta.selectionEnd;
            if (e.shiftKey) {
                var ls = ta.value.lastIndexOf("\n", s - 1) + 1, seg = ta.value.slice(ls, en), un = seg.replace(/^( {1,2}|\t)/gm, "");
                ta.setRangeText(un, ls, en, "preserve");
            } else if (s !== en && ta.value.slice(s, en).indexOf("\n") >= 0) {
                var ls2 = ta.value.lastIndexOf("\n", s - 1) + 1;
                ta.setRangeText(ta.value.slice(ls2, en).replace(/^/gm, "  "), ls2, en, "preserve");
            } else ta.setRangeText("  ", s, en, "end");
            ta.dispatchEvent(new Event("input"));
        } else if (e.key === "Enter") {
            var st = ta.selectionStart, ls3 = ta.value.lastIndexOf("\n", st - 1) + 1, ind = /^[ \t]*/.exec(ta.value.slice(ls3, st))[0];
            var before = ta.value.slice(0, st).trimEnd().slice(-1), extra = (before === "{" || before === "(" || before === "[") ? "  " : "";
            e.preventDefault(); ta.setRangeText("\n" + ind + extra, st, ta.selectionEnd, "end"); ta.dispatchEvent(new Event("input"));
        }
    });

    function showResult(res, saved) {
        errBox.innerHTML = ""; errLines = {};
        if (res.ok) {
            errBox.appendChild(h("div", { class: "ok-line", text: "OK - verificato con " + res.checker + (saved ? " e salvato" : "") }));
        } else {
            res.errors.forEach(function (er) {
                errLines[er.line] = true;
                errBox.appendChild(h("div", { class: "err-line", text: "Riga " + er.line + ": " + er.message, onclick: function () { jump(er.line); } }));
                if (er.detail) errBox.appendChild(h("pre", { style: "color:#c99;margin:2px 0 6px;white-space:pre-wrap", text: er.detail }));
            });
            if (res.available === false && item.kind === "file") {
                errBox.appendChild(ui.btn("Salva comunque (NON verificato)", function () { doSave(true); }, "danger"));
            }
        }
        drawGutter();
    }
    function jump(line) {
        var idx = 0, ls = ta.value.split("\n");
        for (var i = 0; i < line - 1 && i < ls.length; i++) idx += ls[i].length + 1;
        ta.focus(); ta.setSelectionRange(idx, idx + (ls[line - 1] || "").length);
        ta.scrollTop = Math.max(0, (line - 4) * 18);
    }
    async function check() {
        var code = ta.value;
        if (SC.server) {
            try { var r = await SC.api("check", { json: { ext: ext, content: code } }); showResult(r); return r; }
            catch (e) { errBox.textContent = "Errore verifica: " + e.message; return { ok: false }; }
        }
        if (ext === ".js") {
            try { new Function(code); var ok = { ok: true, checker: "parser del browser (new Function)", errors: [] }; showResult(ok); return ok; }
            catch (e) { var bad = { ok: false, available: true, checker: "browser", errors: [{ line: 1, message: e.message }] }; showResult(bad); return bad; }
        }
        errBox.textContent = "Nessun compilatore disponibile senza server."; return { ok: false };
    }
    async function doSave(skip) {
        var code = ta.value;
        if (item.kind === "inline") {
            var r = await check();
            if (!r.ok) { SC.toast("Errore di sintassi: script NON applicato", "err"); return; }
            item.el.textContent = code; original = code; updPos(); SC.commit("Script inline modificato");
            SC.toast("Script inline aggiornato (ricorda di salvare la pagina)", "ok"); return;
        }
        if (!SC.needServer("Salvare il file")) return;
        try {
            var res = await SC.api("write", { json: { path: item.path, content: code, skipCheck: !!skip } });
            original = code; updPos(); showResult(res.check, true);
            SC.toast("File salvato: " + item.path + (skip ? " (non verificato)" : ""), skip ? "warn" : "ok");
            SCR.files = null;
        } catch (e) {
            if (e.data && e.data.check) { showResult(e.data.check); SC.toast("Compilatore: errori, file NON salvato", "err"); }
            else SC.toast(e.message, "err");
        }
    }
    SC.ideSaveHook = function () { doSave(false); };

    var close = function () {
        if (ta.value !== original && !confirm("Ci sono modifiche non salvate. Chiudere comunque?")) return;
        SC.ideOpen = false; SC.ideSaveHook = null; modal.remove();
    };
    var modal = h("div", { class: "modal", "data-sc-ui": "1" }, h("div", { class: "box", style: "width:min(1100px,96vw);height:min(86vh,820px)" },
        h("div", { class: "hd" }, h("b", { text: lang + " - " + item.path }),
            h("span", { style: "flex:1" }),
            ui.btn("Verifica", check), ui.btn("Salva (verificato)", function () { doSave(false); }, "primary"),
            item.kind === "file" ? ui.btn("Backup...", async function () {
                try {
                    var b = (await SC.api("backups", { query: { path: item.path } })).backups;
                    errBox.innerHTML = "";
                    if (!b.length) { errBox.textContent = "Nessun backup."; return; }
                    b.forEach(function (x) { errBox.appendChild(h("div", { class: "err-line", style: "color:#9cf", text: "Ripristina " + x.stamp + " (" + fmtSize(x.size) + ")", onclick: async function () {
                        if (!confirm("Ripristinare questo backup? Il file attuale viene salvato a sua volta come backup.")) return;
                        await SC.api("restore", { json: { path: item.path, stamp: x.stamp } });
                        ta.value = (await SC.api("file", { query: { path: item.path } })).content; original = ta.value; drawGutter(); updPos(); SC.toast("Backup ripristinato", "ok");
                    } })); });
                } catch (e) { SC.toast(e.message, "err"); }
            }, "sm") : null,
            ui.btn("Chiudi", close)),
        h("div", { style: "display:flex;flex:1;min-height:0;background:#10141a" }, gutter, ta),
        errBox,
        h("div", { class: "hd", style: "border-top:1px solid #2f363d;border-bottom:0" }, pos,
            h("span", { class: "hint", text: "Tab = rientro - Ctrl+S = salva (dopo la verifica del compilatore)" }))));
    SC.ideOpen = true;
    SC.shadow.appendChild(modal);
    drawGutter(); updPos(); ta.focus();
    if (ext === ".js") check();
};
