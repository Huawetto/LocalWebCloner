/* ------------------------------------------------------------------------ avvio */
function offerRestore() {
    var stored = null;
    try { stored = localStorage.getItem(AUTOSAVE_KEY); } catch (e) {}
    if (!stored || stored === SC.baseline) return;
    var banner = h("div", { id: "banner" }, "Ci sono modifiche non salvate su disco per questa pagina (bozza locale).",
        ui.btn("Ripristina", function () {
            var d = new DOMParser().parseFromString(stored, "text/html");
            var css = d.getElementById("sc-runtime-styles");
            SC.applySnapshot({ body: d.body.innerHTML, css: css ? css.textContent : null, style: d.documentElement.getAttribute("style"), patches: d.documentElement.getAttribute("data-sc-patches"), fu: null });
            SC.commit("Bozza ripristinata"); banner.remove(); SC.toast("Bozza ripristinata", "ok");
        }, "primary"),
        ui.btn("Scarta", function () { SC.clearAutosave(); banner.remove(); }));
    SC.shadow.appendChild(banner);
}

function start() {
    SC.initIds();
    SC.buildUI();
    SC.baseline = SC.serialize();
    SC.initHistory();
    SC.ping().then(function (s) {
        SC.serverEl.textContent = s ? "server: attivo" : "server: assente (salva = download)";
        SC.serverEl.style.color = s ? "#7ee787" : "#d29922";
        if (SC.active === "misc" || SC.active === "scripts") SC.renderPane();
    });
    offerRestore();
    SC.setStatus("Premi \"Modifica: OFF\" per iniziare");
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
