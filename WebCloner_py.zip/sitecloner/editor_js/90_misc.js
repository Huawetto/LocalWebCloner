/* --------------------------------------------------------- Altro: trova/sostituisci, backup, aiuto */
var MISC = { find: "", repl: "", cs: false, re: false };

function replaceInDoc(doc, find, repl, cs, isRe) {
    var re;
    try { re = new RegExp(isRe ? find : find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), cs ? "g" : "gi"); }
    catch (e) { return -1; }
    var n = 0;
    function rep(v) { return v.replace(re, function () { n++; return repl; }); }
    SC.textNodes(doc).forEach(function (t) {
        var v = t.nodeValue, nv = rep(v);
        if (nv !== v) t.nodeValue = nv;
    });
    var title = doc.querySelector("head > title");
    if (title) { var tv = rep(title.textContent); if (tv !== title.textContent) title.textContent = tv; }
    return n;
}

SC.addTab("misc", "Altro", function (root) {
    root.appendChild(ui.section("Trova e sostituisci testo", h("div", {},
        ui.row("Trova", ui.text(MISC.find, function (v) { MISC.find = v; })),
        ui.row("Sostituisci", ui.text(MISC.repl, function (v) { MISC.repl = v; })),
        ui.row("", ui.check("maiuscole/minuscole", MISC.cs, function (v) { MISC.cs = v; }), ui.check("regex", MISC.re, function (v) { MISC.re = v; })),
        ui.row("", ui.btn("In questa pagina", function () {
            if (!MISC.find) return;
            var n = replaceInDoc(document, MISC.find, MISC.repl, MISC.cs, MISC.re);
            if (n < 0) { SC.toast("Espressione regolare non valida", "err"); return; }
            SC.commit("Trova e sostituisci"); SC.toast(n + " sostituzioni", "ok");
        }, "primary"), ui.btn("In TUTTE le pagine", function () {
            if (!MISC.find) return;
            if (replaceInDoc(document.implementation.createHTMLDocument(""), MISC.find, "", MISC.cs, MISC.re) < 0) { SC.toast("Espressione regolare non valida", "err"); return; }
            if (!confirm("Sostituire \"" + MISC.find + "\" con \"" + MISC.repl + "\" in TUTTE le pagine del sito? (viene fatto un backup di ogni pagina)")) return;
            SC.siteWide(function (doc) { return replaceInDoc(doc, MISC.find, MISC.repl, MISC.cs, MISC.re); }, "Trova e sostituisci");
        }))), true));

    var bk = h("div", {});
    root.appendChild(ui.section("Backup di questa pagina", h("div", {},
        ui.hint("Ogni salvataggio crea un backup automatico (gli ultimi 30) in _sitecloner_backups/."),
        ui.btn("Mostra backup", async function () {
            if (!SC.needServer("I backup")) return;
            try {
                var b = (await SC.api("backups", { query: { path: SC.pagePath() } })).backups;
                bk.innerHTML = "";
                if (!b.length) { bk.appendChild(ui.hint("Nessun backup ancora.")); return; }
                b.forEach(function (x) {
                    bk.appendChild(h("div", { class: "row" }, h("span", { class: "mono", text: x.stamp }), h("span", { class: "hint", text: fmtSize(x.size) }),
                        ui.btn("Ripristina", async function () {
                            if (!confirm("Ripristinare questa versione? La pagina verra' ricaricata.")) return;
                            await SC.api("restore", { json: { path: SC.pagePath(), stamp: x.stamp } });
                            SC.dirty = false; SC.clearAutosave(); location.reload();
                        }, "sm")));
                });
            } catch (e) { SC.toast(e.message, "err"); }
        }, "sm"), bk), false));

    root.appendChild(ui.section("Scorciatoie", h("div", { class: "hint", style: "line-height:1.7" },
        "Click = seleziona - Doppio click su testo = scrivi", h("br"),
        "Ctrl+S salva su disco - Ctrl+Z / Ctrl+Y annulla/ripeti", h("br"),
        "Frecce = sposta 1px (Shift = 10px) - Canc = elimina", h("br"),
        "Esc = deseleziona / termina la scrittura", h("br"),
        "Maniglia in alto a destra = sposta - in basso a destra = ridimensiona (Shift = proporzioni)"), false));

    root.appendChild(ui.section("Info", h("div", { class: "hint", style: "line-height:1.7" },
        "Server: " + (SC.server ? "attivo (" + SC.server.root + ") - node " + (SC.server.node ? "si" : "NO") : "assente (modalita' file: salva = download)"), h("br"),
        "Pagina: " + SC.pagePath(), h("br"),
        "Le modifiche si salvano nel file .html di questa pagina; gli asset caricati restano nella cartella del sito."), false));
}, 70);
