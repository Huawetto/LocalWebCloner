/* -------------------------------------------------------------------- Upload */
var UPL = { items: [], dest: "" };
var KIND_BY_EXT = {
    image: ".png .jpg .jpeg .gif .webp .svg .bmp .ico .avif", video: ".mp4 .webm .ogv .mov .m4v", audio: ".mp3 .wav .ogg .m4a .flac .aac",
    html: ".html .htm", css: ".css", js: ".js .mjs", font: ".ttf .otf .woff .woff2"
};
var BLOCKED_UP = /\.(php[0-9s]?|phtml|phar|db3?|sqlite3?|sql|mdb|accdb|dump)$/i;
function kindOfFile(name) {
    var e = extOf(name);
    for (var k in KIND_BY_EXT) if (KIND_BY_EXT[k].split(" ").indexOf(e) >= 0) return k;
    return "other";
}
var DIR_BY_KIND = { image: "images", video: "videos", audio: "audio", html: "pages", css: "css", js: "js", font: "fonts", other: "files" };

function insertAfterSel(node) {
    var s = SC.sel;
    if (s && s !== document.body && s.parentNode) s.after(node); else document.body.appendChild(node);
    SC.commit("Inserito elemento"); SC.select(node);
}
async function doUpload(files) {
    if (!SC.needServer("Il caricamento dei file")) return;
    for (var i = 0; i < files.length; i++) {
        var f = files[i], kind = kindOfFile(f.name);
        if (BLOCKED_UP.test(f.name)) { SC.toast("Upload di file PHP e database non consentito: " + f.name, "err"); continue; }
        var dir = UPL.dest ? SC.siteRoot() + "/" + UPL.dest.replace(/^\/+|\/+$/g, "") : SC.siteRoot() + "/_uploads/" + DIR_BY_KIND[kind];
        try {
            var r = await SC.upload(f, kind, f.name, dir);
            UPL.items.unshift({ name: f.name, path: r.path, kind: kind, size: r.size });
            SC.toast("Caricato: " + r.path, "ok");
        } catch (e) { SC.toast("Upload fallito (" + f.name + "): " + e.message, "err"); }
    }
    if (SC.active === "upload") SC.renderPane();
}

function itemActions(it) {
    var rel = SC.rel(it.path), box = h("div", { class: "row" });
    var sel = SC.sel;
    function mk(tag, attrs) { var n = document.createElement(tag); Object.keys(attrs).forEach(function (k) { n.setAttribute(k, attrs[k]); }); return n; }
    if (it.kind === "image") {
        var info = sel ? SC.imageInfo(sel) : null;
        if (info) box.appendChild(ui.btn("Sostituisci " + info.label + " selezionata", function () { SC.replaceImage(info, rel); SC.commit("Immagine sostituita"); SC.updateOverlay(); }, "sm primary"));
        if (sel && sel !== document.body) box.appendChild(ui.btn("Usa come sfondo", function () {
            var st = getJson(sel, "data-sc-bg", null) || { mode: "image", color: "#fff", grad: grad.make(), img: "", size: "cover", tile: 600, repeat: "no-repeat", bright: 100, contrast: 100, anim: "none", speed: 12, dir: "normal" };
            st.mode = "image"; st.img = rel; applyBg(sel, st); SC.commit("Sfondo immagine");
        }, "sm"));
        box.appendChild(ui.btn("Inserisci <img>", function () { insertAfterSel(mk("img", { src: rel, alt: it.name })); }, "sm"));
    }
    if (it.kind === "video" || it.kind === "audio") {
        if (sel && sel.tagName === it.kind.toUpperCase()) box.appendChild(ui.btn("Sostituisci selezionato", function () { sel.querySelectorAll("source").forEach(function (s) { s.remove(); }); sel.src = rel; sel.load(); SC.commit("Media sostituito"); }, "sm primary"));
        box.appendChild(ui.btn("Inserisci <" + it.kind + ">", function () { insertAfterSel(mk(it.kind, { src: rel, controls: "" })); }, "sm"));
    }
    if (it.kind === "html" && sel) box.appendChild(ui.btn("Collega all'elemento selezionato", function () {
        var a = sel.closest("a");
        if (a) a.setAttribute("href", rel);
        else { a = mk("a", { href: rel }); sel.parentNode.insertBefore(a, sel); a.appendChild(sel); }
        SC.commit("Link a pagina"); SC.toast("Collegamento creato", "ok");
    }, "sm primary"));
    if (it.kind === "css") box.appendChild(ui.btn("Aggiungi <link> alla pagina", function () { document.head.appendChild(mk("link", { rel: "stylesheet", href: rel })); SC.commit("CSS aggiunto"); }, "sm"));
    if (it.kind === "js") box.appendChild(ui.btn("Aggiungi <script> alla pagina", function () { document.body.appendChild(mk("script", { src: rel })); SC.commit("Script aggiunto"); }, "sm"));
    if (it.kind === "js" || it.kind === "css" || it.kind === "html") box.appendChild(ui.btn("Apri nell'editor", function () { SC.openIde({ kind: "file", path: it.path, ext: extOf(it.path) }); }, "sm"));
    box.appendChild(ui.btn("Copia percorso", function () { navigator.clipboard && navigator.clipboard.writeText(rel); SC.toast("Copiato: " + rel, "ok"); }, "sm"));
    return box;
}

SC.addTab("upload", "Upload", function (root) {
    if (!SC.server) root.appendChild(ui.hint("Serve il server di editing per caricare file nel sito locale:  python crawl.py --serve <cartella>"));
    var drop = h("div", { style: "border:2px dashed #3a434b;border-radius:8px;padding:18px;text-align:center;color:#9aa3ab;margin-bottom:8px", text: "Trascina qui i file oppure usa il pulsante" });
    drop.addEventListener("dragover", function (e) { e.preventDefault(); drop.style.borderColor = "#2271b1"; });
    drop.addEventListener("dragleave", function () { drop.style.borderColor = "#3a434b"; });
    drop.addEventListener("drop", function (e) { e.preventDefault(); drop.style.borderColor = "#3a434b"; doUpload(Array.prototype.slice.call(e.dataTransfer.files)); });
    root.appendChild(drop);
    root.appendChild(ui.row("Cartella", ui.text(UPL.dest, function (v) { UPL.dest = v; }, "vuoto = automatica per tipo (es. images/)"), ));
    root.appendChild(ui.row("", ui.btn("Scegli file...", async function () { var fs = await SC.pickFile("", true); if (fs.length) doUpload(fs); }, "primary")));
    root.appendChild(ui.hint("Puoi caricare: immagini, video, audio, html, css, js, font e altri file (PHP e database non sono ammessi). Finiscono in " + (SC.siteRoot() || "/") + "/_uploads/<tipo>/ (non esegue nulla: sono solo salvati)."));
    if (!UPL.items.length) return;
    root.appendChild(h("div", { class: "hint", text: "Caricati in questa sessione:" }));
    UPL.items.slice(0, 40).forEach(function (it) {
        root.appendChild(h("div", { style: "border-bottom:1px solid #2a3138;padding:5px 0" },
            h("div", {}, h("b", { text: it.name }), " ", h("span", { class: "hint", text: it.kind + " - " + fmtSize(it.size) })),
            h("div", { class: "hint mono", text: it.path }), itemActions(it)));
    });
}, 60);
