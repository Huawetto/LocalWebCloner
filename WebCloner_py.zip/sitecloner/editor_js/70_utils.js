/* -------------------------------------------------------- Fun utils (patch on/off)
   Ogni patch deve essere: reversibile, valida (HTML/CSS), e non deve rompere il layout:
   - niente override di transform/animation/display/position del sito
   - le immagini cambiano aspetto via CSS, il riquadro mantiene le dimensioni originali
   - i colori vengono rimappati solo dove il sito li usa gia' */
var FU = SC.fu = {};
function docPath(doc) { return doc === document ? SC.pagePath() : (doc.__scPath || SC.pagePath()); }
/* lista separata da SPAZI: il selettore CSS [attr~="id"] riconosce solo parole separate da spazi */
function activeP(doc) { return (doc.documentElement.getAttribute("data-sc-patches") || "").split(/[\s,]+/).filter(Boolean); }
function setActiveP(doc, arr) { if (arr.length) doc.documentElement.setAttribute("data-sc-patches", arr.join(" ")); else doc.documentElement.removeAttribute("data-sc-patches"); }
function addActive(doc, id) { var a = activeP(doc); if (a.indexOf(id) < 0) a.push(id); setActiveP(doc, a); }
function delActive(doc, id) { setActiveP(doc, activeP(doc).filter(function (x) { return x !== id; })); }
function PSEL(id) { return 'html[data-sc-patches~="' + id + '"]'; }
function fuCss(doc, id, css) { SC.ensureFx(doc); cssMgr(doc).set("fu-" + id, css); }
function fuDel(doc, id) { cssMgr(doc).del("fu-" + id); }
function normalizeP(doc) { setActiveP(doc, activeP(doc)); } // converte le vecchie liste con la virgola

/* un unico "orologio" su <html> anima le variabili registrate lette dagli elementi */
var CLOCKS = { txtmq: "sc-mqv 14s linear infinite", imgmq: "sc-mqv 14s linear infinite", allmq: "sc-mqv 14s linear infinite",
               imgspin: "sc-rotv 6s linear infinite", glitch: "sc-gxv .6s steps(2) infinite" };
function refreshClock(doc) {
    var seen = {}, list = [];
    activeP(doc).forEach(function (id) { var c = CLOCKS[id]; if (c && !seen[c]) { seen[c] = 1; list.push(c); } });
    if (list.length) fuCss(doc, "clock", "html{animation:" + list.join(", ") + "}"); else fuDel(doc, "clock");
}
function afterChange(doc) { refreshClock(doc); if (doc === document) SC.runtime(document); }

/* pulizia di attributi lasciati da versioni precedenti dell'editor */
function legacyUntag(doc, token, varNames) {
    doc.querySelectorAll('[data-sc-fu~="' + token + '"]').forEach(function (el) {
        var cur = (el.getAttribute("data-sc-fu") || "").split(/\s+/).filter(function (t) { return t && t !== token; });
        if (cur.length) el.setAttribute("data-sc-fu", cur.join(" ")); else el.removeAttribute("data-sc-fu");
        (varNames || []).forEach(function (v) { el.style.removeProperty(v); });
        if (el.getAttribute("style") === "") el.removeAttribute("style");
    });
}

/* separa un selectorText ai livello-0 (non dentro :is(...) ecc.) */
function splitSelectors(s) {
    var out = [], depth = 0, cur = "";
    for (var i = 0; i < s.length; i++) {
        var ch = s[i];
        if (ch === "(" || ch === "[") depth++;
        else if (ch === ")" || ch === "]") depth--;
        if (ch === "," && depth === 0) { out.push(cur.trim()); cur = ""; } else cur += ch;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
}
function prefixed(id, selectorText) {
    return splitSelectors(selectorText).map(function (s) { return /^(html|:root)\b/.test(s) ? s.replace(/^(html|:root)/, PSEL(id)) : PSEL(id) + " " + s; }).join(",");
}

/* ------------------------------------------------------ mutazioni di testo reversibili */
function wrapText(doc, node, id) {
    var p = node.parentNode;
    if (p && p.nodeType === 1 && p.hasAttribute("data-sc-orig")) { p.setAttribute("data-sc-t", id); return p; }
    var s = doc.createElement("span");
    s.setAttribute("data-sc-t", id); s.setAttribute("data-sc-orig", node.nodeValue);
    p.replaceChild(s, node); s.appendChild(node);
    return s;
}
function restoreText(doc) {
    doc.querySelectorAll("span[data-sc-t][data-sc-orig]").forEach(function (s) {
        s.replaceWith(doc.createTextNode(s.getAttribute("data-sc-orig")));
    });
}
var TEXT_IDS = ["txtshuffle", "txtrandom", "letters", "deltext", "b64enc", "b64dec"];
function textRevert(doc) { restoreText(doc); TEXT_IDS.forEach(function (i) { delActive(doc, i); }); fuDel(doc, "textwrap"); }
function textWrapCss(doc) { fuCss(doc, "textwrap", "span[data-sc-t]{overflow-wrap:anywhere}"); }
function mapText(doc, id, fn) {
    SC.textNodes(doc).forEach(function (n) {
        var v = n.nodeValue, lead = /^\s*/.exec(v)[0], trail = /\s*$/.exec(v)[0], core = v.trim();
        var nv = fn(core);
        if (nv == null || nv === core) return;
        wrapText(doc, n, id);
        n.nodeValue = lead + nv + trail;
    });
}
function b64e(s) { return btoa(unescape(encodeURIComponent(s))); }
function b64d(s) { return decodeURIComponent(escape(atob(s))); }
function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
function randWord(len, upperFirst) {
    var L = "abcdefghijklmnopqrstuvwxyz", s = "";
    for (var i = 0; i < len; i++) s += L[Math.floor(Math.random() * L.length)];
    return upperFirst ? s[0].toUpperCase() + s.slice(1) : s;
}

/* vecchia versione: le immagini venivano sostituite cambiando src. Ora e' solo CSS, ma
   resta il ripristino per le pagine salvate con la versione precedente. */
function restoreImages(doc) {
    doc.querySelectorAll("img[data-sc-o-src]").forEach(function (img) {
        var o = img.getAttribute("data-sc-o-src");
        if (o) img.setAttribute("src", o); else img.removeAttribute("src");
        img.removeAttribute("data-sc-o-src");
        ["srcset", "sizes", "data-src", "data-srcset"].forEach(function (a) { if (img.hasAttribute("data-sc-o-" + a)) { img.setAttribute(a, img.getAttribute("data-sc-o-" + a)); img.removeAttribute("data-sc-o-" + a); } });
    });
    doc.querySelectorAll("source[data-sc-o-srcset]").forEach(function (s) { s.setAttribute("srcset", s.getAttribute("data-sc-o-srcset")); s.removeAttribute("data-sc-o-srcset"); });
}
/* il contenuto dell'immagine viene spostato fuori dal suo riquadro (object-position) e si vede lo
   sfondo: dimensioni, layout e attributi dell'<img> restano identici */
function imageSkin(id, bgCss) {
    return PSEL(id) + " img{" + bgCss + ";object-position:-99999px -99999px!important}";
}
var IMG_IDS = ["imggrad", "imgone"];
function imgRevert(doc) { IMG_IDS.forEach(function (i) { fuDel(doc, i); delActive(doc, i); }); restoreImages(doc); }

/* overlay composti (bw / invert / sepia / blur): un velo fisso con backdrop-filter, non tocca il DOM */
var OVERLAY = { bw: "grayscale(1) contrast(1.05)", invert: "invert(1)", sepia: "sepia(1)", blurall: "blur(2px)" };
function refreshOverlay(doc) {
    var act = activeP(doc).filter(function (i) { return OVERLAY[i]; });
    if (!act.length) { fuDel(doc, "overlay"); return; }
    var f = act.map(function (i) { return OVERLAY[i]; }).join(" ");
    fuCss(doc, "overlay", "html::after{content:\"\";position:fixed;inset:0;z-index:2147482980;pointer-events:none;-webkit-backdrop-filter:" + f + ";backdrop-filter:" + f + "}");
}
function overlayPatch(id, label, desc) {
    return { id: id, label: label, desc: desc, apply: function (doc) { addActive(doc, id); refreshOverlay(doc); }, revert: function (doc) { delActive(doc, id); refreshOverlay(doc); } };
}
function cssPatch(id, label, desc, css, extra) {
    var p = { id: id, label: label, desc: desc, apply: function (doc) { fuCss(doc, id, css); addActive(doc, id); }, revert: function (doc) { fuDel(doc, id); delActive(doc, id); } };
    for (var k in (extra || {})) p[k] = extra[k];
    return p;
}
var CLIP = "html,body{overflow-x:clip}"; // a differenza di hidden non rompe position:sticky

/* font delle icone: non vanno mai sostituiti (sparirebbero le icone) */
var ICON_NOT = [":not(i)", ":not(svg)", ":not(svg *)", ":not(code)", ":not(pre)", ":not(kbd)", ":not(samp)", ":not([class*=\"icon\"])", ":not([class*=\"Icon\"])",
    ":not([class*=\"fa-\"])", ":not(.fa)", ":not(.fas)", ":not(.far)", ":not(.fab)", ":not(.fal)", ":not(.fad)", ":not([class*=\"dashicons\"])",
    ":not([class*=\"glyph\"])", ":not([class*=\"material-\"])", ":not(.material-icons)", ":not([class*=\"eicon\"])", ":not([class*=\"genericon\"])", ":not([aria-hidden=\"true\"])"].join("");

FU.list = [
    { id: "txtcolor", label: "Tutti i testi: 1 colore random", desc: "Un unico colore casuale per ogni testo del sito.", random: true,
      prepare: function () { return toHex(randGoodColor()); },
      apply: function (doc, c) { fuCss(doc, "txtcolor", PSEL("txtcolor") + " body *:not(script):not(style){color:" + c + "!important;-webkit-text-fill-color:" + c + "!important}"); addActive(doc, "txtcolor"); },
      revert: function (doc) { fuDel(doc, "txtcolor"); delActive(doc, "txtcolor"); } },

    { id: "letters", label: "1 lettera = 1 colore", desc: "Ogni lettera ha un colore diverso (mai giallo, bianco o nero scuro).", group: "text", random: true,
      apply: function (doc) {
          var budget = 60000;
          SC.textNodes(doc).forEach(function (n) {
              if (budget <= 0) return;
              var v = n.nodeValue;
              var wrap = doc.createElement("span"); wrap.setAttribute("data-sc-t", "letters"); wrap.setAttribute("data-sc-orig", v);
              for (var i = 0; i < v.length; i++) {
                  var ch = v[i];
                  if (/\s/.test(ch)) { wrap.appendChild(doc.createTextNode(ch)); continue; }
                  var s = doc.createElement("span"); s.style.color = randGoodColor(); s.textContent = ch; wrap.appendChild(s); budget--;
              }
              n.parentNode.replaceChild(wrap, n);
          });
          textWrapCss(doc); addActive(doc, "letters");
      }, revert: textRevert },

    { id: "txtshuffle", label: "Testi scambiati di posto", desc: "I testi del sito vengono rimescolati fra i vari elementi.", group: "text", random: true,
      apply: function (doc) {
          var nodes = SC.textNodes(doc), vals = shuffle(nodes.map(function (n) { return n.nodeValue.trim(); })), i = 0;
          nodes.forEach(function (n) {
              var v = n.nodeValue, lead = /^\s*/.exec(v)[0], trail = /\s*$/.exec(v)[0];
              wrapText(doc, n, "txtshuffle"); n.nodeValue = lead + vals[i++] + trail;
          });
          textWrapCss(doc); addActive(doc, "txtshuffle");
      }, revert: textRevert },

    { id: "txtrandom", label: "Testo originale -> testo random", desc: "Le parole diventano parole casuali della stessa lunghezza.", group: "text", random: true,
      apply: function (doc) {
          mapText(doc, "txtrandom", function (core) { return core.replace(/[A-Za-zÀ-ɏ]+/g, function (w) { return randWord(w.length, w[0] === w[0].toUpperCase() && w[0] !== w[0].toLowerCase()); }); });
          textWrapCss(doc); addActive(doc, "txtrandom");
      }, revert: textRevert },

    { id: "deltext", label: "Cancella testi (lascia gli spazi)", desc: "Ogni carattere diventa uno spazio vuoto: il layout resta.", group: "text",
      apply: function (doc) { mapText(doc, "deltext", function (core) { return core.replace(/\S/g, " "); }); textWrapCss(doc); addActive(doc, "deltext"); }, revert: textRevert },

    { id: "b64enc", label: "Tutti i testi -> base64", desc: "Codifica ogni testo in base64 (UTF-8). Le parole lunghe vanno a capo senza uscire dai riquadri.", group: "text",
      apply: function (doc) { mapText(doc, "b64enc", function (core) { try { return b64e(core); } catch (e) { return null; } }); textWrapCss(doc); addActive(doc, "b64enc"); }, revert: textRevert },

    { id: "b64dec", label: "Tutti i base64 -> testo", desc: "Decodifica i testi che sono base64 validi (anche quelli prodotti dal pulsante precedente).", group: "text", chain: true,
      apply: function (doc) {
          mapText(doc, "b64dec", function (core) {
              if (core.length < 8 || core.length % 4 || !/^[A-Za-z0-9+\/]+={0,2}$/.test(core)) return null;
              try { var t = b64d(core); return /[\u0000-\u0008\u000e-\u001f�]/.test(t) ? null : t; } catch (e) { return null; }
          });
          textWrapCss(doc); addActive(doc, "b64dec");
      }, revert: textRevert },

    { id: "imggrad", label: "Tutte le immagini -> 1 gradient random", desc: "Ogni immagine mostra lo stesso gradient casuale, con le sue dimensioni originali.", group: "img", random: true,
      prepare: function () { return grad.random(3); },
      apply: function (doc, g) {
          imgRevert(doc);
          fuCss(doc, "imggrad", imageSkin("imggrad", "background:" + grad.css(g) + "!important;background-size:100% 100%!important"));
          addActive(doc, "imggrad");
      }, revert: imgRevert },

    { id: "imgone", label: "Tutte le immagini -> 1 immagine", desc: "Ogni immagine mostra quella che scegli dal PC, ritagliata nel riquadro originale.", group: "img",
      prepare: async function () {
          var f = await SC.pickFile("image/*"); if (!f) return null;
          if (SC.server) { var up = await SC.upload(f, "images", f.name); return { abs: up.path }; }
          return { data: await SC.readDataURL(f) };
      },
      apply: function (doc, p) {
          imgRevert(doc);
          var url = p.abs ? SC.rel(p.abs, docPath(doc)) : p.data;
          fuCss(doc, "imgone", imageSkin("imgone", "background:url(\"" + url.replace(/"/g, "%22") + "\") center/cover no-repeat!important"));
          addActive(doc, "imgone");
      }, revert: imgRevert },

    { id: "noimg", label: "Nessuna immagine", desc: "Nasconde immagini e immagini di sfondo lasciando lo spazio (i gradient restano).",
      prepare: function () {
          var rules = [];
          eachSheet(function (rs) {
              eachRule(rs, "", function (r, wrap) {
                  var v = r.style.getPropertyValue("background-image") + " " + r.style.getPropertyValue("background");
                  if (/url\(/i.test(v)) rules.push({ wrap: wrap, sel: r.selectorText });
              });
          });
          return rules;
      },
      apply: function (doc, rules) {
          var P = PSEL("noimg");
          var css = [P + " img," + P + " picture," + P + " input[type=image]," + P + " svg image," + P + " video[poster]:not([src]){visibility:hidden!important}",
                     P + " [style*=\"url(\"]{background-image:none!important}"];
          (rules || []).forEach(function (r) {
              css.push(r.wrap + prefixed("noimg", r.sel) + "{background-image:none!important}" + closeWrap(r.wrap));
          });
          fuCss(doc, "noimg", css.join("\n")); addActive(doc, "noimg");
      },
      revert: function (doc) { fuDel(doc, "noimg"); delActive(doc, "noimg"); } },

    { id: "themerand", label: "Colori del tema random", desc: "Randomizza la palette principale (separata dalla scheda Tema).", random: true,
      prepare: function () { var f = theme.collect(), r = theme.randomMap(f); return theme.build(r.map, r.vars); },
      apply: function (doc, css) { if (css) fuCss(doc, "themerand", css); addActive(doc, "themerand"); },
      revert: function (doc) { fuDel(doc, "themerand"); delActive(doc, "themerand"); } },

    { id: "allrand", label: "Tutti i colori random", desc: "Ogni colore usato dal sito diventa un colore casuale (sfondi trasparenti restano trasparenti).", random: true,
      prepare: function () {
          var f = theme.collect(), map = {}, vars = {};
          f.colors.forEach(function (c) { map[c.c] = { mode: "color", color: toHex(randColor()) }; });
          Object.keys(f.vars).forEach(function (k) { vars[k] = toHex(randColor()); });
          return theme.build(map, vars);
      },
      apply: function (doc, css) { legacyUntag(doc, "allrand", ["--sc-rc1", "--sc-rc2"]); if (css) fuCss(doc, "allrand", css); addActive(doc, "allrand"); },
      revert: function (doc) { legacyUntag(doc, "allrand", ["--sc-rc1", "--sc-rc2"]); fuDel(doc, "allrand"); delActive(doc, "allrand"); } },

    { id: "txtmq", label: "Marquee su tutti i testi", desc: "Ogni blocco di testo scorre orizzontalmente (senza cambiare il layout).",
      apply: function (doc) { legacyUntag(doc, "txtmq", ["--sc-mqd"]); fuCss(doc, "txtmq", CLIP); addActive(doc, "txtmq"); },
      revert: function (doc) { legacyUntag(doc, "txtmq", ["--sc-mqd"]); fuDel(doc, "txtmq"); delActive(doc, "txtmq"); } },
    cssPatch("imgmq", "Marquee su tutte le immagini", "Ogni immagine scorre orizzontalmente.", CLIP + "\n" + PSEL("imgmq") + " img{translate:var(--sc-mq) 0}"),
    cssPatch("allmq", "Marquee su tutto il contenuto", "Ogni blocco principale della pagina scorre (gli header fissi restano fissi).", CLIP + " /* data-sc-rt: blocchi calcolati dal runtime */"),

    overlayPatch("bw", "Bianco e nero", "Tutta la pagina in scala di grigi."),
    overlayPatch("invert", "Colori invertiti", "Inverte tutti i colori."),
    overlayPatch("sepia", "Seppia", "Effetto vecchia foto."),
    overlayPatch("blurall", "Sfocatura leggera", "Sfoca tutta la pagina."),

    cssPatch("rainbow", "Tutti i colori (arcobaleno)", "Arcobaleno animato con contrasto su tutto il sito.",
        "html::before{content:\"\";position:fixed;inset:0;z-index:2147482970;pointer-events:none;background:linear-gradient(115deg,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00);background-size:300% 300%;mix-blend-mode:color;opacity:.9;animation:sc-gshift 6s ease infinite;-webkit-backdrop-filter:contrast(1.4) saturate(1.8);backdrop-filter:contrast(1.4) saturate(1.8)}"),

    cssPatch("mirror", "Pagina specchiata", "Specchia la pagina in orizzontale; header fissi e menu restano al loro posto.", CLIP + " /* data-sc-rt: calcolato dal runtime */"),
    cssPatch("comic", "Tutto in Comic Sans", "Sostituisce il font dei testi (le icone restano intatte).", PSEL("comic") + " body *" + ICON_NOT + "{font-family:'Comic Sans MS','Comic Neue','Chalkboard SE',cursive!important}"),
    cssPatch("imgcircle", "Immagini tonde", "Tutte le immagini diventano cerchi (dimensioni invariate).", PSEL("imgcircle") + " img{border-radius:50%!important;object-fit:cover}"),
    cssPatch("imgspin", "Immagini che girano", "Tutte le immagini ruotano di continuo.", PSEL("imgspin") + " img{rotate:var(--sc-rot)}"),
    cssPatch("glitch", "Glitch su tutti i testi", "Effetto glitch RGB animato sui testi (le animazioni del sito restano).",
        PSEL("glitch") + " body *:not(svg):not(svg *){text-shadow:var(--sc-gx) 0 0 rgba(255,0,0,.85),calc(var(--sc-gx) * -1) 0 0 rgba(0,255,255,.85)!important}")
];
FU.byId = function (id) { return FU.list.filter(function (p) { return p.id === id; })[0]; };

FU.set = async function (p, on, whole) {
    var payload = null;
    if (on && p.prepare) {
        try { payload = await p.prepare(); } catch (e) { SC.toast("Errore: " + e.message, "err"); return false; }
        if (payload == null) return false;
    }
    var fn = function (doc) {
        normalizeP(doc);
        if (on) {
            if (p.group === "text" && !p.chain) textRevert(doc);
            p.apply(doc, payload);
        } else p.revert(doc);
        afterChange(doc);
    };
    if (whole) return SC.siteWide(fn, (on ? "Attivato: " : "Rimosso: ") + p.label);
    fn(document); SC.commit((on ? "Attivato: " : "Rimosso: ") + p.label); return true;
};

var FU_STATE = { whole: false };
SC.addTab("utils", "Utils", function (root) {
    var act = activeP(document);
    root.appendChild(ui.hint("Patch reversibili: attivale e disattivale con l'interruttore. Non modificano layout, animazioni o posizioni del sito; si salvano nella pagina e si possono applicare a tutto il sito."));
    root.appendChild(h("div", { class: "row" }, ui.check("Applica a TUTTE le pagine del sito (richiede il server)", FU_STATE.whole, function (v) { FU_STATE.whole = v; }),
        ui.btn("Rimuovi tutte", async function () {
            for (var i = 0; i < FU.list.length; i++) { var p = FU.list[i]; if (activeP(document).indexOf(p.id) >= 0) await FU.set(p, false, FU_STATE.whole); }
            SC.renderPane();
        }, "sm danger")));
    FU.list.forEach(function (p) {
        var on = act.indexOf(p.id) >= 0;
        var sw = ui.toggle(on, async function (v, el) {
            var ok = await FU.set(p, v, FU_STATE.whole);
            if (!ok) el.setOn(!v); else SC.renderPane();
        });
        var row = h("div", { class: "row", style: "border-bottom:1px solid #2a3138;padding:4px 0;flex-wrap:nowrap" },
            h("div", { style: "flex:1" }, h("div", { text: p.label, style: "font-weight:600" }), h("div", { class: "hint", text: p.desc })), sw);
        if (p.random) row.appendChild(ui.btn("Re-roll", async function () { await FU.set(p, false, FU_STATE.whole); await FU.set(p, true, FU_STATE.whole); SC.renderPane(); }, "sm"));
        root.appendChild(row);
    });
}, 50);
