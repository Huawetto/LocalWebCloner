/* ------------------------------------------------------------ UI CSS (shadow) */
var UI_CSS = [
":host{all:initial}",
"*{box-sizing:border-box}",
"#bar{position:fixed;top:0;left:0;right:0;height:46px;z-index:2147483600;background:#14181c;color:#e6e8ea;display:flex;align-items:center;gap:6px;padding:0 10px;font:13px/1.3 Segoe UI,system-ui,Arial,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.45);overflow-x:auto;overflow-y:hidden;white-space:nowrap}",
"#bar .logo{font-weight:700;letter-spacing:.3px;color:#6cb4ff;margin-right:4px}",
"#bar .sp{flex:1}",
"#bar .sep{width:1px;height:22px;background:#2f363d;margin:0 4px}",
"#bar .st{font-size:11px;color:#8c959d;max-width:34vw;overflow:hidden;text-overflow:ellipsis;flex:0 1 auto}",
"button,.btn{font:inherit;font-size:12px;background:#262d33;color:#e6e8ea;border:1px solid #3a434b;border-radius:4px;padding:5px 10px;cursor:pointer}",
"button:hover{background:#323b43}",
"button:disabled{opacity:.4;cursor:not-allowed}",
"button.on,button.primary{background:#2271b1;border-color:#2271b1;color:#fff}",
"button.danger{background:#7a2323;border-color:#a33}",
"button.sm{padding:2px 7px;font-size:11px}",
"#panel{position:fixed;top:46px;bottom:0;right:0;width:min(410px,46vw);z-index:2147483500;background:#1b2025;color:#d7dbde;font:12px/1.35 Segoe UI,system-ui,Arial,sans-serif;display:flex;flex-direction:column;box-shadow:-2px 0 10px rgba(0,0,0,.4)}",
"#panel.left{right:auto;left:0;box-shadow:2px 0 10px rgba(0,0,0,.4)}",
"#bar.bottom{top:auto;bottom:0;box-shadow:0 -2px 8px rgba(0,0,0,.45)}",
"#panel.barbottom{top:0;bottom:46px}",
"#panel.hide{display:none}",
"@media (max-width:760px){#panel,#panel.left{top:auto;left:0;right:0;bottom:0;width:100%;height:52vh}#panel.barbottom{bottom:46px}}",
"#tabs{display:flex;flex-wrap:wrap;background:#14181c;border-bottom:1px solid #2f363d}",
"#tabs button{border:0;border-radius:0;background:transparent;padding:8px 10px;color:#9aa3ab}",
"#tabs button.on{background:#1b2025;color:#fff;box-shadow:inset 0 -2px 0 #2271b1}",
"#pane{flex:1;overflow:auto;padding:10px}",
".row{display:flex;align-items:center;gap:6px;margin:5px 0;flex-wrap:wrap}",
".row>label.l{flex:0 0 92px;color:#9aa3ab}",
".row .grow{flex:1;min-width:0}",
"input[type=text],input[type=number],input:not([type]),select,textarea{font:inherit;font-size:12px;background:#10141a;color:#e6e8ea;border:1px solid #3a434b;border-radius:3px;padding:4px 6px;min-width:0}",
"input.num{width:64px}",
"input[type=range]{flex:1;min-width:70px;accent-color:#2271b1}",
"input[type=color]{width:34px;height:26px;padding:0;border:1px solid #3a434b;background:none;cursor:pointer}",
"textarea{width:100%;resize:vertical;font-family:Consolas,monospace}",
"details{border:1px solid #2f363d;border-radius:5px;margin:8px 0;background:#161b20}",
"summary{cursor:pointer;padding:7px 9px;font-weight:600;color:#cfd6dc;user-select:none}",
"details>.body{padding:4px 9px 9px}",
".hint{color:#8c959d;font-size:11px;margin:4px 0}",
".chip{display:inline-flex;align-items:center;gap:4px;background:#262d33;border:1px solid #3a434b;border-radius:10px;padding:1px 4px 1px 8px;margin:2px;font-size:11px}",
".chip b{cursor:pointer;color:#e88}",
".crumbs{display:flex;flex-wrap:wrap;gap:2px;margin-bottom:6px}",
".crumbs span{background:#262d33;border-radius:3px;padding:1px 6px;cursor:pointer;font-size:11px}",
".crumbs span.cur{background:#2271b1;color:#fff}",
".grad-prev{height:22px;border-radius:4px;border:1px solid #3a434b;margin:4px 0}",
".stop{display:flex;gap:4px;align-items:center;margin:3px 0}",
".sw{display:inline-block;width:26px;height:26px;border-radius:4px;border:1px solid #555;cursor:pointer;vertical-align:middle}",
"table{border-collapse:collapse;width:100%}",
"td,th{padding:3px 5px;border-bottom:1px solid #2a3138;text-align:left;vertical-align:top}",
"th{color:#9aa3ab;font-weight:600;cursor:pointer}",
"tr.click:hover{background:#232a31;cursor:pointer}",
".mono{font-family:Consolas,monospace;font-size:11px;word-break:break-all}",
".sw-on{display:inline-block;width:34px;height:18px;border-radius:9px;background:#444;position:relative;vertical-align:middle;cursor:pointer}",
".sw-on:after{content:'';position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;background:#fff;transition:left .15s}",
".sw-on.on{background:#2271b1}.sw-on.on:after{left:18px}",
"#toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:2147483700;display:flex;flex-direction:column;gap:6px;align-items:center;pointer-events:none}",
"#toast div{background:#222;color:#fff;border-left:4px solid #2271b1;padding:8px 14px;border-radius:4px;font:13px Segoe UI,system-ui,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.5);max-width:80vw}",
"#toast .ok{border-color:#2ea043}#toast .err{border-color:#e5484d}#toast .warn{border-color:#d29922}",
".ov{position:fixed;pointer-events:none;z-index:2147483400;display:none}",
"#ov-hover{border:1px dashed #6cb4ff;background:rgba(108,180,255,.07)}",
"#ov-sel{border:2px solid #2271b1;box-shadow:0 0 0 1px rgba(255,255,255,.6)}",
"#ov-label{position:absolute;left:-2px;top:-20px;background:#2271b1;color:#fff;font:11px Consolas,monospace;padding:1px 6px;border-radius:3px 3px 0 0;white-space:nowrap}",
".grip{position:absolute;width:16px;height:16px;background:#2271b1;border:1px solid #fff;pointer-events:auto;border-radius:3px}",
"#g-move{right:-8px;top:-8px;cursor:move}#g-size{right:-8px;bottom:-8px;cursor:nwse-resize}",
"#banner{position:fixed;top:56px;left:50%;transform:translateX(-50%);z-index:2147483650;background:#fff3cd;color:#333;border:1px solid #d29922;border-radius:6px;padding:8px 12px;display:flex;gap:10px;align-items:center;font:13px Segoe UI,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.4)}",
".modal{position:fixed;inset:0;z-index:2147483640;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center}",
".modal .box{background:#1b2025;color:#d7dbde;border:1px solid #3a434b;border-radius:8px;max-width:96vw;max-height:94vh;display:flex;flex-direction:column;font:12px Segoe UI,sans-serif}",
".modal .hd{display:flex;align-items:center;gap:8px;padding:8px 12px;border-bottom:1px solid #2f363d;flex-wrap:wrap}",
".modal .bd{overflow:auto;padding:10px;flex:1}",
".err-line{color:#ff8b8b;cursor:pointer}",
".ok-line{color:#7ee787}"
].join("\n");

var PAGE_CSS = [
"html.sc-on [data-sc-editing]{outline:2px solid #2271b1!important;outline-offset:2px;cursor:text!important;user-select:text!important}",
"html.sc-bar{padding-top:46px!important}",
"html.sc-barb{padding-bottom:46px!important}"
].join("\n");

/* ---------------------------------------------------------------- UI control */
var ui = SC.ui = {};
ui.row = function (label) {
    var kids = Array.prototype.slice.call(arguments, 1);
    return h("div", { class: "row" }, label ? h("label", { class: "l", text: label }) : null, kids);
};
ui.btn = function (text, fn, cls) { return h("button", { text: text, class: cls || "", onclick: fn }); };
ui.num = function (val, o, cb) {
    o = o || {};
    var i = h("input", { type: "number", class: "num", value: val == null || isNaN(val) ? "" : val, min: o.min, max: o.max, step: o.step || 1 });
    if (o.w) i.style.width = o.w;
    i.addEventListener("input", function () { var v = parseFloat(i.value); if (!isNaN(v)) cb(v, i); });
    return i;
};
ui.range = function (val, o, cb) {
    o = o || {};
    var r = h("input", { type: "range", min: o.min, max: o.max, step: o.step || 1, value: val });
    var n = ui.num(val, o, function (v) { r.value = v; cb(v); });
    r.addEventListener("input", function () { n.value = r.value; cb(parseFloat(r.value)); });
    var w = h("span", { class: "grow", style: "display:flex;gap:6px;align-items:center" }, r, n);
    w.set = function (v) { r.value = v; n.value = v; };
    return w;
};
ui.color = function (val, cb) {
    var i = h("input", { type: "color", value: toHex(val || "#000000") });
    i.addEventListener("input", function () { cb(i.value, i); });
    return i;
};
ui.text = function (val, cb, ph) {
    var i = h("input", { type: "text", value: val == null ? "" : val, placeholder: ph || "", class: "grow" });
    i.addEventListener("input", function () { cb(i.value, i); });
    return i;
};
ui.select = function (opts, val, cb) {
    var s = h("select", {});
    opts.forEach(function (o) { var v = Array.isArray(o) ? o[0] : o, t = Array.isArray(o) ? o[1] : o; var op = h("option", { value: v, text: t }); if (String(v) === String(val)) op.selected = true; s.appendChild(op); });
    s.addEventListener("change", function () { cb(s.value, s); });
    return s;
};
ui.check = function (label, val, cb) {
    var c = h("input", { type: "checkbox", checked: !!val });
    c.addEventListener("change", function () { cb(c.checked, c); });
    return h("label", { style: "display:inline-flex;gap:5px;align-items:center;cursor:pointer" }, c, label);
};
ui.toggle = function (val, cb) {
    var s = h("span", { class: "sw-on" + (val ? " on" : "") });
    s.addEventListener("click", function () { var on = !s.classList.contains("on"); s.classList.toggle("on", on); cb(on, s); });
    s.setOn = function (on) { s.classList.toggle("on", !!on); };
    return s;
};
ui.section = function (title, body, open) {
    var d = h("details", {}, h("summary", { text: title }), h("div", { class: "body" }, body));
    if (open) d.open = true;
    return d;
};
ui.hint = function (t) { return h("div", { class: "hint", text: t }); };

/* -------------------------------------------------------------------- toast */
SC.toast = function (msg, kind) {
    if (!SC.toastBox) { console.log("[SC]", msg); return; }
    var d = h("div", { class: kind || "", text: msg });
    SC.toastBox.appendChild(d);
    setTimeout(function () { d.remove(); }, kind === "err" ? 7000 : 3800);
};

/* ----------------------------------------------------------------- tab pane */
SC.addTab = function (id, label, render, order) { SC.tabs.push({ id: id, label: label, render: render, order: order || 50 }); SC.tabs.sort(function (a, b) { return a.order - b.order; }); };
SC.renderPane = function () {
    if (!SC.pane) return;
    var t = SC.tabs.filter(function (x) { return x.id === SC.active; })[0] || SC.tabs[0];
    SC.pane.innerHTML = "";
    try { t.render(SC.pane); } catch (e) { SC.pane.appendChild(h("div", { class: "err-line", text: "Errore pannello: " + e.message })); console.error(e); }
    SC.tabBar.querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.dataset.id === t.id); });
};
SC.openTab = function (id) { SC.active = id; SC.renderPane(); };
SC.refreshPane = function () { SC.renderPane(); };

/* --------------------------------------------------------------- transform */
SC.applyTx = function (el) {
    var tx = parseFloat(el.getAttribute("data-sc-tx")) || 0, ty = parseFloat(el.getAttribute("data-sc-ty")) || 0;
    var rot = parseFloat(el.getAttribute("data-sc-rot")) || 0, sc = parseFloat(el.getAttribute("data-sc-scale")) || 1;
    var fx = el.getAttribute("data-sc-flipx") === "1", fy = el.getAttribute("data-sc-flipy") === "1";
    var sx = (fx ? -1 : 1) * sc, sy = (fy ? -1 : 1) * sc;
    /* proprieta' individuali: si SOMMANO al transform del sito (es. translate(-50%,-50%) di centratura)
       invece di sostituirlo */
    function set(p, on, v) { if (on) el.style.setProperty(p, v); else el.style.removeProperty(p); }
    set("translate", tx || ty, tx + "px " + ty + "px");
    set("rotate", rot, rot + "deg");
    set("scale", sx !== 1 || sy !== 1, sx + " " + sy);
    var any = tx || ty || rot || sx !== 1 || sy !== 1;
    if (any && !el.__scTxWarned && SC.safeToTransform && !SC.safeToTransform(el)) {
        el.__scTxWarned = true;
        SC.toast("Attenzione: l'elemento contiene parti fisse o ancorate fuori da lui, che si muoveranno insieme a lui", "warn");
    }
    if (any && getComputedStyle(el).display === "inline") { el.style.display = "inline-block"; el.setAttribute("data-sc-txdisp", "1"); }
    if (!any && el.hasAttribute("data-sc-txdisp")) { el.style.removeProperty("display"); el.removeAttribute("data-sc-txdisp"); }
    if (el.getAttribute("style") === "") el.removeAttribute("style");
};

/* ----------------------------------------------------------------- overlay */
SC.updateOverlay = function () {
    if (!SC.ov) return;
    var el = SC.sel;
    if (!el || !el.isConnected || !SC.editMode) { SC.ov.sel.style.display = "none"; return; }
    var r = el.getBoundingClientRect();
    var s = SC.ov.sel.style;
    s.display = "block"; s.left = r.left + "px"; s.top = r.top + "px"; s.width = Math.max(r.width, 4) + "px"; s.height = Math.max(r.height, 4) + "px";
    SC.ov.label.textContent = SC.describe(el) + "  " + Math.round(r.width) + "x" + Math.round(r.height);
    SC.ov.label.style.top = r.top < 70 ? (Math.max(r.height, 4) + 2) + "px" : "-20px";
};
SC.onSelect = function (fn) { SC.selListeners.push(fn); };
SC.select = function (el) {
    if (el && el.nodeType !== 1) el = el.parentElement;
    if (el && el.tagName === "HTML") el = document.body;
    if (el && SC.isUI(el)) return;
    if (SC.editingEl && el !== SC.editingEl) SC.stopTextEdit();
    SC.sel = el || null;
    SC.updateOverlay();
    SC.selListeners.forEach(function (f) { try { f(SC.sel); } catch (e) { console.error(e); } });
    if (SC.active === "el" || SC.active === "tags" || SC.active === "insert") SC.renderPane();
};
SC.deselect = function () { SC.sel = null; SC.updateOverlay(); SC.selListeners.forEach(function (f) { try { f(null); } catch (e) {} }); if (SC.active === "el" || SC.active === "tags" || SC.active === "insert") SC.renderPane(); };

/* --------------------------------------------------------- modifica del testo */
SC.startTextEdit = function (el) {
    if (SC.editingEl) SC.stopTextEdit();
    el.setAttribute("contenteditable", "true");
    el.setAttribute("data-sc-editing", "1");
    SC.editingEl = el;
    el.focus();
    SC.toast("Modifica testo: clicca fuori o premi Esc per terminare", "ok");
};
SC.stopTextEdit = function (silent) {
    var el = SC.editingEl;
    if (!el) return;
    SC.editingEl = null;
    el.removeAttribute("contenteditable");
    el.removeAttribute("data-sc-editing");
    if (el.hasAttribute("data-sc-text")) el.setAttribute("data-sc-text", el.textContent);
    if (!silent) SC.commit("Testo modificato");
};

/* ---------------------------------------------------------- modalita' modifica */
SC.setEditMode = function (on) {
    SC.editMode = !!on;
    document.documentElement.classList.toggle("sc-on", SC.editMode);
    SC.modeBtn.classList.toggle("on", SC.editMode);
    SC.modeBtn.textContent = SC.editMode ? "Modifica: ON" : "Modifica: OFF";
    SC.ov.hover.style.display = "none";
    if (!SC.editMode) { SC.stopTextEdit(); SC.sel = null; }
    SC.updateOverlay();
    SC.setStatus(SC.editMode ? "Clicca un elemento per selezionarlo - doppio click su un testo per scriverci" : "Anteprima: il sito si comporta normalmente");
    if (SC.active === "el" || SC.active === "tags" || SC.active === "insert") SC.renderPane();
};
SC.setStatus = function (t) { if (SC.statusEl) SC.statusEl.textContent = t; };
SC.updateTitleState = function () { if (SC.dirtyEl) SC.dirtyEl.textContent = SC.dirty ? "modifiche non salvate" : ""; };
SC.refreshHistoryUI = function () {
    if (!SC.undoBtn) return;
    SC.undoBtn.disabled = SC.history.length < 2;
    SC.redoBtn.disabled = SC.future.length < 1;
};

/* Molti siti mettono un livello trasparente (link, overlay, didascalia vuota) sopra le immagini:
   se il punto cliccato non ha testo ne' immagine propria, scegliamo l'immagine che sta sotto. */
function isMediaLike(n) { return /^(IMG|PICTURE|VIDEO|AUDIO|CANVAS)$/i.test(n.tagName) || (n.tagName && n.tagName.toLowerCase() === "svg"); }
SC.pickTarget = function (e, t) {
    if (!t || isMediaLike(t) || SC.hasOwnText(t) || t === document.body || t === document.documentElement) return t;
    if (t.tagName !== "HTML" && SC.bgUrlOf && SC.bgUrlOf(t)) return t;
    var stack = document.elementsFromPoint ? document.elementsFromPoint(e.clientX, e.clientY) : [];
    for (var i = 0; i < stack.length && i < 12; i++) {
        var n = stack[i];
        if (n === t || SC.isUI(n) || n === document.body || n === document.documentElement) continue;
        if (isMediaLike(n)) return n;
        if (SC.hasOwnText(n)) break;
        if (SC.bgUrlOf && SC.bgUrlOf(n)) return n;
    }
    return t;
};
function evTargetEl(e) { var t = e.target; if (t && t.nodeType !== 1) t = t.parentElement; return t; }
function fromUI(e) {
    var p = e.composedPath ? e.composedPath() : [];
    if (p.indexOf(SC.host) >= 0) return true;
    var t = e.target;
    return !!(t && t.nodeType === 1 && t.closest && t.closest("[data-sc-ui]"));
}
function inEditing(e) { return SC.editingEl && SC.editingEl.contains(e.target); }

function wireEvents() {
    ["mousedown", "mouseup", "pointerdown", "pointerup", "touchstart", "touchend", "submit", "auxclick"].forEach(function (t) {
        window.addEventListener(t, function (e) {
            if (!SC.editMode || fromUI(e) || inEditing(e)) return;
            e.stopImmediatePropagation();
            if (t === "mousedown" && SC.editingEl) SC.stopTextEdit();
        }, true);
    });
    window.addEventListener("click", function (e) {
        if (!SC.editMode || fromUI(e) || inEditing(e)) return;
        e.preventDefault(); e.stopImmediatePropagation();
        var t = evTargetEl(e);
        if (t) SC.select(SC.pickTarget(e, t));
    }, true);
    window.addEventListener("dblclick", function (e) {
        if (!SC.editMode || fromUI(e)) return;
        var t = evTargetEl(e);
        if (!t || inEditing(e)) return;
        e.preventDefault(); e.stopImmediatePropagation();
        var k = SC.kindOf(t);
        if (k === "image" || k === "video" || k === "audio") return;
        SC.select(t);
        SC.startTextEdit(t);
    }, true);
    window.addEventListener("mousemove", function (e) {
        if (!SC.editMode || SC.dragging) return;
        if (fromUI(e)) { SC.ov.hover.style.display = "none"; return; }
        var t = evTargetEl(e);
        if (!t || t === SC.sel) { SC.ov.hover.style.display = "none"; return; }
        var r = t.getBoundingClientRect(), s = SC.ov.hover.style;
        s.display = "block"; s.left = r.left + "px"; s.top = r.top + "px"; s.width = r.width + "px"; s.height = r.height + "px";
    }, true);
    window.addEventListener("scroll", function () { SC.updateOverlay(); }, true);
    window.addEventListener("resize", function () { SC.updateOverlay(); });
    setInterval(function () { if (SC.sel) SC.updateOverlay(); }, 350);

    window.addEventListener("keydown", function (e) {
        var ctrl = e.ctrlKey || e.metaKey;
        var path = e.composedPath ? e.composedPath() : [];
        var first = path[0];
        var typing = first && first.nodeType === 1 && (/^(INPUT|TEXTAREA|SELECT)$/.test(first.tagName) || first.isContentEditable);
        if (ctrl && (e.key === "s" || e.key === "S")) { e.preventDefault(); if (SC.ideSaveHook && SC.ideOpen) SC.ideSaveHook(); else SC.save(); return; }
        if (typing) { if (e.key === "Escape" && SC.editingEl) { SC.stopTextEdit(); } return; }
        if (!SC.editMode) return;
        if (ctrl && (e.key === "z" || e.key === "Z")) { e.preventDefault(); e.shiftKey ? SC.redo() : SC.undo(); return; }
        if (ctrl && !e.shiftKey && !e.altKey) {
            var k = e.key.toLowerCase();
            var hasTextSel = !!(window.getSelection && String(window.getSelection()).trim());
            if (k === "v") { e.preventDefault(); SC.pasteClip(); return; }
            if (SC.sel && !hasTextSel) {
                if (k === "c") { e.preventDefault(); SC.copySel(false); return; }
                if (k === "x") { e.preventDefault(); SC.copySel(true); return; }
                if (k === "d") { e.preventDefault(); SC.duplicateSel(); return; }
            }
        }
        if (ctrl && (e.key === "y" || e.key === "Y")) { e.preventDefault(); SC.redo(); return; }
        if (e.key === "Escape") { SC.deselect(); return; }
        if (!SC.sel) return;
        if (e.key === "Delete") { e.preventDefault(); SC.deleteSel(); return; }
        var step = e.shiftKey ? 10 : 1, mv = null;
        if (e.key === "ArrowLeft") mv = [-step, 0]; else if (e.key === "ArrowRight") mv = [step, 0];
        else if (e.key === "ArrowUp") mv = [0, -step]; else if (e.key === "ArrowDown") mv = [0, step];
        if (mv) {
            e.preventDefault();
            var el = SC.sel;
            el.setAttribute("data-sc-tx", (parseFloat(el.getAttribute("data-sc-tx")) || 0) + mv[0]);
            el.setAttribute("data-sc-ty", (parseFloat(el.getAttribute("data-sc-ty")) || 0) + mv[1]);
            SC.applyTx(el); SC.updateOverlay();
            clearTimeout(SC._nudge); SC._nudge = setTimeout(function () { SC.commit("Spostamento"); }, 500);
        }
    }, true);
    window.addEventListener("beforeunload", function (e) {
        if (SC.dirty) { e.preventDefault(); e.returnValue = ""; }
    });
}

SC.deleteSel = function () {
    var el = SC.sel;
    if (!el || el === document.body || el === document.documentElement) { SC.toast("Questo elemento non si puo' eliminare", "warn"); return; }
    SC.deselect();
    el.remove();
    SC.commit("Elemento eliminato");
};

function wireGrips() {
    function drag(grip, onMove, label) {
        grip.addEventListener("pointerdown", function (e) {
            if (!SC.sel) return;
            e.preventDefault(); e.stopPropagation();
            SC.dragging = true;
            var el = SC.sel, sx = e.clientX, sy = e.clientY;
            var st = { tx: parseFloat(el.getAttribute("data-sc-tx")) || 0, ty: parseFloat(el.getAttribute("data-sc-ty")) || 0,
                       w: el.getBoundingClientRect().width, hh: el.getBoundingClientRect().height };
            grip.setPointerCapture(e.pointerId);
            function mv(ev) { onMove(el, st, ev.clientX - sx, ev.clientY - sy, ev); SC.updateOverlay(); }
            function up() { grip.removeEventListener("pointermove", mv); grip.removeEventListener("pointerup", up); SC.dragging = false; SC.commit(label); if (SC.active === "el") SC.renderPane(); }
            grip.addEventListener("pointermove", mv); grip.addEventListener("pointerup", up);
        });
    }
    drag(SC.ov.gMove, function (el, st, dx, dy) {
        el.setAttribute("data-sc-tx", Math.round(st.tx + dx)); el.setAttribute("data-sc-ty", Math.round(st.ty + dy)); SC.applyTx(el);
    }, "Spostamento");
    drag(SC.ov.gSize, function (el, st, dx, dy, ev) {
        var w = Math.max(8, st.w + dx), hh = Math.max(8, st.hh + dy);
        if (ev.shiftKey) hh = w * (st.hh / st.w);
        el.style.width = Math.round(w) + "px"; el.style.height = Math.round(hh) + "px";
        if (getComputedStyle(el).display === "inline") el.style.display = "inline-block";
    }, "Ridimensionamento");
}

/* ------------------------------------------------------------------ costruzione */
SC.buildUI = function () {
    SC.host = document.createElement("div");
    SC.host.id = "sc-root";
    SC.host.setAttribute("data-sc-ui", "1");
    var sh = SC.shadow = SC.host.attachShadow({ mode: "open" });
    sh.appendChild(h("style", { text: UI_CSS }));

    SC.modeBtn = ui.btn("Modifica: OFF", function () { SC.setEditMode(!SC.editMode); });
    SC.undoBtn = ui.btn("Annulla", function () { SC.undo(); }); SC.undoBtn.title = "Ctrl+Z";
    SC.redoBtn = ui.btn("Ripeti", function () { SC.redo(); }); SC.redoBtn.title = "Ctrl+Y";
    SC.statusEl = h("span", { class: "st" });
    SC.dirtyEl = h("span", { class: "st", style: "color:#d29922" });
    SC.serverEl = h("span", { class: "st", text: "server: ..." });
    var bar = h("div", { id: "bar" },
        h("span", { class: "logo", text: "SiteEditor" }),
        SC.modeBtn, h("span", { class: "sep" }), SC.undoBtn, SC.redoBtn, h("span", { class: "sep" }),
        ui.btn("Salva su disco", function () { SC.save(); }, "primary"),
        ui.btn("Scarica", function () { SC.stopTextEdit(); SC.download(SC.serialize()); }),
        ui.btn("Esporta pulito", function () { SC.stopTextEdit(); SC.download(SC.cleanHtml()); }),
        h("span", { class: "sep" }), SC.serverEl, SC.dirtyEl, SC.statusEl, h("span", { class: "sp" }),
        ui.btn("Pannello <>", function () { SC.panel.classList.toggle("left"); }),
        ui.btn("Barra su/giu", function () { SC.setBarBottom(!SC.barBottom); }),
        ui.btn("Mostra/nascondi", function () { SC.panel.classList.toggle("hide"); })
    );

    SC.tabBar = h("div", { id: "tabs" });
    SC.pane = h("div", { id: "pane" });
    SC.panel = h("div", { id: "panel" }, SC.tabBar, SC.pane);
    SC.toastBox = h("div", { id: "toast" });
    SC.ov = {
        hover: h("div", { class: "ov", id: "ov-hover" }),
        label: h("div", { id: "ov-label" }),
        gMove: h("div", { class: "grip", id: "g-move", title: "Trascina per spostare (frecce = 1px, Shift+frecce = 10px)" }),
        gSize: h("div", { class: "grip", id: "g-size", title: "Trascina per ridimensionare (Shift = proporzioni)" })
    };
    SC.ov.sel = h("div", { class: "ov", id: "ov-sel" }, SC.ov.label, SC.ov.gMove, SC.ov.gSize);
    sh.append(bar, SC.panel, SC.ov.hover, SC.ov.sel, SC.toastBox);

    SC.tabs.forEach(function (t) {
        SC.tabBar.appendChild(h("button", { text: t.label, "data-id": t.id, onclick: function () { SC.openTab(t.id); } }));
    });

    var st = document.createElement("style");
    st.id = "sc-editor-style"; st.setAttribute("data-sc-ui", "1"); st.textContent = PAGE_CSS;
    document.head.appendChild(st);
    SC.barEl = bar;
    SC.setBarBottom = function (on) {
        SC.barBottom = !!on;
        bar.classList.toggle("bottom", SC.barBottom);
        SC.panel.classList.toggle("barbottom", SC.barBottom);
        document.documentElement.classList.toggle("sc-bar", !SC.barBottom);
        document.documentElement.classList.toggle("sc-barb", SC.barBottom);
        try { localStorage.setItem("sc2::barBottom", SC.barBottom ? "1" : ""); } catch (e) {}
    };
    var pref = ""; try { pref = localStorage.getItem("sc2::barBottom") || ""; } catch (e) {}
    SC.setBarBottom(pref === "1");
    document.documentElement.appendChild(SC.host);
    wireGrips();
    wireEvents();
    SC.renderPane();
};
