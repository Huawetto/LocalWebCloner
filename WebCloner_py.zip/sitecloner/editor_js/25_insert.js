/* --------------------------------------- copia / taglia / incolla / duplica / inserisci elementi
   Regole:
   - un elemento copiato porta con se' le regole CSS dell'editor (sfondi, contorni, gradient...)
     e riceve nuovi data-sc-id, cosi' la copia e' indipendente dall'originale;
   - i link relativi (src/href/...) vengono resi assoluti alla copia e di nuovo relativi
     all'incolla: funzionano anche incollando in un'altra pagina, in un'altra cartella;
   - gli id HTML duplicati vengono rinominati e l'inserimento rispetta il modello HTML
     (niente <div> dentro <p>, niente <p> diretto dentro <ul> o <tr>...). */
var CLIP_KEY = "sc2::clipboard";
var URL_ATTRS = ["href", "src", "poster", "data", "action", "srcset", "data-src", "data-srcset"];
var ABS = "sc-abs:";
var BLOCK_TAGS = /^(DIV|P|H[1-6]|UL|OL|DL|TABLE|HR|BLOCKQUOTE|SECTION|ARTICLE|FIGURE|PRE|FORM|HEADER|FOOTER|NAV|ASIDE|ADDRESS|FIELDSET|MAIN|DETAILS)$/;
var PHRASING_ONLY = /^(P|H[1-6]|SPAN|A|B|STRONG|EM|I|U|S|SMALL|LABEL|BUTTON|CODE|SUP|SUB|MARK|Q|ABBR|TIME|CITE|DFN|KBD|SAMP|VAR|DT|LEGEND|CAPTION|SUMMARY)$/;
var STRUCT_PARENT = /^(UL|OL|DL|TABLE|TBODY|THEAD|TFOOT|TR|SELECT|COLGROUP|OPTGROUP|DATALIST|PICTURE|VIDEO|AUDIO)$/;
var VOID_TAGS = /^(IMG|HR|BR|INPUT|META|LINK|SOURCE|TRACK|WBR|AREA|EMBED|COL|IFRAME|VIDEO|AUDIO|CANVAS|SVG|svg|TEXTAREA|SELECT)$/;

function isRelUrl(u) { return !!u && !/^\s*([a-z][a-z0-9+.\-]*:|\/\/|#|\/)/i.test(u); }
function toAbs(u) {
    try { var x = new URL(u, location.href); return x.origin === location.origin ? ABS + decodeURIComponent(x.pathname) + x.search + x.hash : x.href; }
    catch (e) { return u; }
}
function fromAbs(v) {
    if (v.indexOf(ABS) !== 0) return v;
    var rest = v.slice(ABS.length), m = /^([^?#]*)(.*)$/.exec(rest);
    return SC.rel(m[1]) + m[2];
}
function mapUrls(root, fn, srcsetFn) {
    [root].concat(Array.prototype.slice.call(root.querySelectorAll("*"))).forEach(function (n) {
        URL_ATTRS.forEach(function (a) {
            var v = n.getAttribute && n.getAttribute(a);
            if (!v) return;
            if (a === "srcset" || a === "data-srcset") n.setAttribute(a, v.split(",").map(function (p) { var t = p.trim().split(/\s+/); t[0] = srcsetFn(t[0]); return t.join(" "); }).join(", "));
            else n.setAttribute(a, fn(v));
        });
    });
}
function cssUrls(css, fn) { return css.replace(/url\((["']?)([^"')]+)\1\)/g, function (m, q, u) { return "url(\"" + fn(u) + "\")"; }); }

/* --------------------------------------------------------------- clipboard */
SC.makeClip = function (el) {
    var clone = el.cloneNode(true);
    clone.querySelectorAll("[data-sc-ui]").forEach(function (n) { n.remove(); });
    [clone].concat(Array.prototype.slice.call(clone.querySelectorAll("*"))).forEach(function (n) {
        ["data-sc-editing", "data-sc-rt-mirror", "data-sc-rt-mq", "data-sc-rt-amq"].forEach(function (a) { n.removeAttribute(a); });
        if (n.getAttribute("contenteditable") === "true" && el.hasAttribute("data-sc-editing")) n.removeAttribute("contenteditable");
    });
    var rules = {};
    [el].concat(Array.prototype.slice.call(el.querySelectorAll("[data-sc-id]"))).forEach(function (n) {
        var id = n.getAttribute("data-sc-id");
        if (!id) return;
        SC.css.keys().forEach(function (k) {
            if (k.indexOf("e" + id + "-") === 0) {
                rules[id] = rules[id] || {};
                rules[id][k.slice(("e" + id + "-").length)] = cssUrls(SC.css.get(k), function (u) { return isRelUrl(u) ? toAbs(u) : u; });
            }
        });
    });
    mapUrls(clone, function (v) { return isRelUrl(v) ? toAbs(v) : v; }, function (v) { return isRelUrl(v) ? toAbs(v) : v; });
    return { html: clone.outerHTML, rules: rules, from: SC.pagePath(), label: SC.describe(el) };
};
SC.materialize = function (clip) {
    var t = document.createElement("template");
    t.innerHTML = clip.html;
    var node = t.content.firstElementChild;
    if (!node) return null;
    mapUrls(node, fromAbs, fromAbs);
    /* nuovi data-sc-id + copia delle regole CSS */
    [node].concat(Array.prototype.slice.call(node.querySelectorAll("[data-sc-id]"))).forEach(function (n) {
        var old = n.getAttribute("data-sc-id");
        if (!old) return;
        var nid = String(SC.nextId++);
        n.setAttribute("data-sc-id", nid);
        var r = (clip.rules || {})[old];
        if (r) Object.keys(r).forEach(function (suf) {
            SC.ensureFx();
            SC.css.set("e" + nid + "-" + suf, cssUrls(r[suf].split('[data-sc-id="' + old + '"]').join('[data-sc-id="' + nid + '"]'), fromAbs));
        });
    });
    /* id HTML unici */
    [node].concat(Array.prototype.slice.call(node.querySelectorAll("[id]"))).forEach(function (n) {
        var id = n.getAttribute("id");
        if (!id || !document.getElementById(id)) return;
        var k = 2; while (document.getElementById(id + "-" + k)) k++;
        var nid = id + "-" + k;
        node.querySelectorAll('[for="' + id + '"]').forEach(function (l) { l.setAttribute("for", nid); });
        n.setAttribute("id", nid);
    });
    return node;
};
SC.clipboard = null;
SC.getClip = function () {
    if (SC.clipboard) return SC.clipboard;
    try { var s = localStorage.getItem(CLIP_KEY); if (s) return JSON.parse(s); } catch (e) {}
    return null;
};
SC.setClip = function (clip) {
    SC.clipboard = clip;
    try { localStorage.setItem(CLIP_KEY, JSON.stringify(clip)); } catch (e) { /* troppo grande per localStorage: resta in memoria */ }
    try { if (navigator.clipboard) navigator.clipboard.writeText(clip.html.split(ABS).join("")); } catch (e) {}
};

/* ---------------------------------------------------------- posizionamento */
function defaultContainer() { return document.querySelector("main") || document.body; }
/* where: after | before | inside-end | inside-start */
SC.placeNode = function (node, where, target) {
    target = target || SC.sel;
    where = where || "after";
    var isBlock = BLOCK_TAGS.test(node.tagName);
    if (!target || target === document.documentElement || target === document.body) { target = defaultContainer(); where = "inside-end"; }
    if (where.indexOf("inside") === 0) {
        var bad = VOID_TAGS.test(target.tagName) || STRUCT_PARENT.test(target.tagName) || (isBlock && PHRASING_ONLY.test(target.tagName));
        if (bad) where = "after";
    }
    if (where === "after" || where === "before") {
        /* risale finche' l'inserimento produce HTML valido */
        while (target.parentElement && target.parentElement !== document.body &&
               (STRUCT_PARENT.test(target.parentElement.tagName) || (isBlock && PHRASING_ONLY.test(target.parentElement.tagName)))) {
            target = target.parentElement;
        }
    }
    if (where === "after") target.after(node);
    else if (where === "before") target.before(node);
    else if (where === "inside-start") target.prepend(node);
    else target.append(node);
    return node;
};
SC.insertAndSelect = function (node, where, editText) {
    SC.placeNode(node, where);
    SC.commit("Inserito " + SC.describe(node));
    SC.select(node);
    try { node.scrollIntoView({ block: "center", behavior: "smooth" }); } catch (e) {}
    if (editText) {
        SC.startTextEdit(node);
        try { var r = document.createRange(); r.selectNodeContents(node); var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); } catch (e) {}
    }
    return node;
};

/* ----------------------------------------------------------- operazioni */
SC.copySel = function (cut) {
    var el = SC.sel;
    if (!el || el === document.body || el === document.documentElement) { SC.toast("Seleziona prima un elemento", "warn"); return; }
    SC.setClip(SC.makeClip(el));
    if (cut) { SC.deleteSel(); SC.toast("Tagliato: " + SC.describe(el) + " (incollalo dove vuoi, anche in un'altra pagina)", "ok"); }
    else SC.toast("Copiato: " + SC.describe(el) + " (Ctrl+V per incollare, anche in un'altra pagina)", "ok");
    if (SC.active === "insert") SC.renderPane();
};
SC.pasteClip = function (where) {
    var clip = SC.getClip();
    if (!clip) { SC.toast("Niente da incollare: copia prima un elemento", "warn"); return; }
    var node = SC.materialize(clip);
    if (!node) { SC.toast("Contenuto degli appunti non valido", "err"); return; }
    SC.insertAndSelect(node, where || INS.where);
    SC.toast("Incollato " + clip.label, "ok");
};
SC.duplicateSel = function () {
    var el = SC.sel;
    if (!el || el === document.body || el === document.documentElement) return;
    var node = SC.materialize(SC.makeClip(el));
    el.after(node);
    SC.commit("Duplicato"); SC.select(node);
};

/* ---------------------------------------------------------- nuovi elementi */
function mk(html) { var t = document.createElement("template"); t.innerHTML = html.trim(); return t.content.firstElementChild; }
function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
async function mediaNode(kind) {
    var f = await SC.pickFile(kind === "image" ? "image/*" : kind + "/*");
    if (!f) return null;
    var url = await SC.placeFile(f, kind === "image" ? "images" : kind === "video" ? "videos" : "audio");
    if (kind === "image") return mk('<img src="' + esc(url) + '" alt="' + esc(f.name.replace(/\.[^.]+$/, "")) + '" style="max-width:100%;height:auto">');
    if (kind === "video") return mk('<video src="' + esc(url) + '" controls style="max-width:100%"></video>');
    return mk('<audio src="' + esc(url) + '" controls></audio>');
}
var INS = { where: "after" };
var NEW_ITEMS = [
    ["Titolo grande (H1)", function () { return mk("<h1>Nuovo titolo</h1>"); }, true],
    ["Titolo (H2)", function () { return mk("<h2>Nuovo titolo</h2>"); }, true],
    ["Sottotitolo (H3)", function () { return mk("<h3>Nuovo sottotitolo</h3>"); }, true],
    ["Paragrafo", function () { return mk("<p>Nuovo paragrafo: scrivi qui il tuo testo.</p>"); }, true],
    ["Testo", function () { return mk("<span>Nuovo testo</span>"); }, true],
    ["Link", function () { var u = prompt("Indirizzo del link (URL o pagina):", "#"); if (u == null) return null; return mk('<a href="' + esc(u) + '">Nuovo link</a>'); }, true],
    ["Bottone personalizzato...", function () { SC.openButtonBuilder(null); return null; }],
    ["Elenco puntato", function () { return mk("<ul><li>Primo punto</li><li>Secondo punto</li><li>Terzo punto</li></ul>"); }],
    ["Elenco numerato", function () { return mk("<ol><li>Primo passo</li><li>Secondo passo</li><li>Terzo passo</li></ol>"); }],
    ["Citazione", function () { return mk("<blockquote><p>Una citazione.</p></blockquote>"); }],
    ["Immagine dal PC...", function () { return mediaNode("image"); }],
    ["Video dal PC...", function () { return mediaNode("video"); }],
    ["Audio dal PC...", function () { return mediaNode("audio"); }],
    ["Linea (separatore)", function () { return mk('<hr style="border:0;border-top:2px solid currentColor;opacity:.3;margin:24px 0">'); }],
    ["Spazio vuoto", function () { return mk('<div style="height:40px" aria-hidden="true"></div>'); }],
    ["Contenitore (div)", function () { return mk('<div style="min-height:60px;padding:16px"><p>Nuovo blocco: scrivi qui oppure incolla altri elementi dentro.</p></div>'); }],
    ["Due colonne", function () { return mk('<div style="display:flex;gap:24px;flex-wrap:wrap"><div style="flex:1;min-width:220px"><p>Prima colonna</p></div><div style="flex:1;min-width:220px"><p>Seconda colonna</p></div></div>'); }],
    ["Tabella", function () { return mk('<table style="border-collapse:collapse"><tbody><tr><td style="border:1px solid #ccc;padding:6px 10px">Cella 1</td><td style="border:1px solid #ccc;padding:6px 10px">Cella 2</td></tr><tr><td style="border:1px solid #ccc;padding:6px 10px">Cella 3</td><td style="border:1px solid #ccc;padding:6px 10px">Cella 4</td></tr></tbody></table>'); }],
    ["Incorpora (iframe)", function () { var u = prompt("Indirizzo da incorporare (es. una mappa o un video):", "https://"); if (!u) return null; return mk('<iframe src="' + esc(u) + '" loading="lazy" allowfullscreen style="width:100%;max-width:640px;aspect-ratio:16/9;border:0"></iframe>'); }]
];
async function addNew(item) {
    try {
        var node = await item[1]();
        if (!node) return;
        if (!SC.editMode) SC.setEditMode(true);
        SC.insertAndSelect(node, INS.where, !!item[2]);
    } catch (e) { SC.toast("Errore: " + e.message, "err"); }
}

SC.addTab("insert", "Inserisci", function (root) {
    var target = SC.sel && SC.sel !== document.body ? SC.describe(SC.sel) : "(nessuna selezione: in fondo alla pagina)";
    root.appendChild(ui.row("Posizione", ui.select([["after", "Dopo la selezione"], ["before", "Prima della selezione"], ["inside-end", "Dentro, in fondo"], ["inside-start", "Dentro, all'inizio"]], INS.where, function (v) { INS.where = v; })));
    root.appendChild(ui.row("Rispetto a", h("span", { class: "hint mono", text: target })));
    var grid = h("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:8px 0" });
    NEW_ITEMS.forEach(function (it) { grid.appendChild(ui.btn(it[0], function () { addNew(it); })); });
    root.appendChild(ui.section("Nuovo elemento", grid, true));

    var clip = SC.getClip();
    root.appendChild(ui.section("Copia e incolla", h("div", {},
        h("div", { class: "row" },
            ui.btn("Copia", function () { SC.copySel(false); }), ui.btn("Taglia", function () { SC.copySel(true); }),
            ui.btn("Duplica", function () { SC.duplicateSel(); }), ui.btn("Incolla", function () { SC.pasteClip(); }, "primary")),
        ui.hint(clip ? "Negli appunti: " + clip.label + (clip.from !== SC.pagePath() ? " (da " + clip.from + ")" : "") : "Appunti vuoti."),
        ui.hint("Scorciatoie con un elemento selezionato: Ctrl+C copia, Ctrl+X taglia, Ctrl+V incolla, Ctrl+D duplica. Gli appunti restano disponibili anche aprendo un'altra pagina del sito.")), true));

    var ta = h("textarea", { rows: 5, spellcheck: "false", placeholder: "<section>...</section>" });
    root.appendChild(ui.section("HTML personalizzato", h("div", {}, ta,
        h("div", { class: "row" }, ui.btn("Inserisci HTML", function () {
            var t = document.createElement("template"); t.innerHTML = ta.value.trim();
            var kids = Array.prototype.slice.call(t.content.childNodes).filter(function (n) { return n.nodeType === 1 || (n.nodeType === 3 && n.nodeValue.trim()); });
            if (!kids.length) { SC.toast("HTML vuoto o non valido", "warn"); return; }
            var node = kids.length === 1 && kids[0].nodeType === 1 ? kids[0] : (function () { var d = document.createElement("div"); kids.forEach(function (k) { d.appendChild(k); }); return d; })();
            if (!SC.editMode) SC.setEditMode(true);
            SC.insertAndSelect(node, INS.where);
        }, "primary"))), false));
}, 15);
