/* ------------------------------------------------ pannello "Elemento" (selezione live) */
var commitSoon = debounce(function (l) { SC.commit(l); }, 450);
function changed(label) { SC.updateOverlay(); commitSoon(label); }
SC.changed = changed;

function getJson(el, attr, def) { try { var v = el.getAttribute(attr); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
function setJson(el, attr, obj) { if (obj == null) el.removeAttribute(attr); else el.setAttribute(attr, JSON.stringify(obj)); }
function cs(el) { return getComputedStyle(el); }
function pxNum(v) { var n = parseFloat(v); return isNaN(n) ? 0 : n; }

SC.canvasToUrl = async function (canvas, name, kind) {
    if (SC.server) {
        var blob = await new Promise(function (r) { canvas.toBlob(r, "image/png"); });
        var up = await SC.upload(blob, kind || "images", name || ("img-" + Date.now() + ".png"));
        return SC.rel(up.path);
    }
    return canvas.toDataURL("image/png");
};
/* attributi/classi di lazy-load: se restano, il JS del sito rimette la vecchia immagine */
var LAZY_ATTRS = ["srcset", "sizes", "data-src", "data-srcset", "data-lazy-src", "data-lazy-srcset", "data-original", "data-orig-file",
    "data-large-file", "data-medium-file", "data-lazyload", "data-bg", "data-background", "data-ll-status", "loading"];
var LAZY_CLASSES = ["lazyload", "lazy", "lazyloading", "lazyloaded", "jetpack-lazy-image", "ls-is-cached"];
SC.setImageSrc = function (img, url) {
    LAZY_ATTRS.forEach(function (a) { img.removeAttribute(a); });
    LAZY_CLASSES.forEach(function (c) { img.classList.remove(c); });
    if (!img.getAttribute("class")) img.removeAttribute("class");
    var pic = img.parentElement;
    if (pic && pic.tagName === "PICTURE") pic.querySelectorAll("source").forEach(function (s) { s.removeAttribute("srcset"); s.removeAttribute("data-srcset"); });
    img.setAttribute("src", url);
};
SC.bgUrlOf = function (el) {
    var m = /url\((["']?)(.*?)\1\)/.exec(getComputedStyle(el).backgroundImage || "");
    return m ? m[2] : null;
};
/* che "immagine" rappresenta l'elemento selezionato? img, <picture>, <image> SVG,
   sfondo CSS con url(), oppure un contenitore (link, figure...) con una sola immagine dentro */
SC.imageInfo = function (el) {
    if (!el || el.nodeType !== 1) return null;
    var t = el.tagName.toUpperCase();
    if (t === "IMG") return { type: "img", img: el, label: "immagine" };
    if (t === "PICTURE") { var pi = el.querySelector("img"); if (pi) return { type: "img", img: pi, label: "immagine" }; }
    if (t === "IMAGE" && el.closest("svg")) return { type: "svgimage", img: el, label: "immagine SVG" };
    if (t !== "BODY" && t !== "HTML" && SC.bgUrlOf(el)) return { type: "bg", el: el, label: "immagine di sfondo" };
    if (!SC.hasOwnText(el)) {
        var imgs = el.querySelectorAll("img");
        if (imgs.length === 1) return { type: "inner", img: imgs[0], label: "immagine contenuta" };
    }
    return null;
};
SC.replaceImage = function (info, url) {
    if (info.type === "img" || info.type === "inner") SC.setImageSrc(info.img, url);
    else if (info.type === "svgimage") { info.img.setAttribute("href", url); info.img.removeAttribute("xlink:href"); }
    else if (info.type === "bg") {
        ["data-bg", "data-background", "data-lazyload", "data-src"].forEach(function (a) { info.el.removeAttribute(a); });
        /* regola !important: vince anche se il JS del sito (slider) riscrive lo style inline */
        SC.setRule(info.el, "bgimg", SC.sel_(info.el) + "{background-image:url(\"" + url.replace(/"/g, "%22") + "\")!important}");
    }
};
SC.pickAndReplaceImage = async function (info) {
    var f = await SC.pickFile("image/*");
    if (!f) return false;
    try {
        SC.replaceImage(info, await SC.placeFile(f, "images"));
        SC.commit("Immagine sostituita"); SC.updateOverlay(); SC.toast("Immagine sostituita: " + f.name, "ok");
        return true;
    } catch (e) { SC.toast("Errore: " + e.message, "err"); return false; }
};

/* ---------------------------------------------------------------- outline box */
var REPLACED = /^(IMG|VIDEO|AUDIO|INPUT|SELECT|TEXTAREA|IFRAME|CANVAS|BR|HR|EMBED|OBJECT|svg|SVG)$/;
function applyBoxOutline(el, st) {
    el.style.removeProperty("outline"); el.style.removeProperty("outline-offset");
    if (el.style.getPropertyValue("border-image")) { ["border-image", "border", "box-sizing"].forEach(function (p) { el.style.removeProperty(p); }); } // versione precedente
    SC.delRule(el, "ol");
    if (!st || !st.on) { setJson(el, "data-sc-ol", null); if (el.getAttribute("style") === "") el.removeAttribute("style"); return; }
    if (st.mode === "gradient") {
        var ps = REPLACED.test(el.tagName) ? null : SC.freePseudo(el);
        if (ps && SC.safeToPosition(el)) {
            /* anello gradient su uno pseudo-elemento libero: segue gli angoli arrotondati e non cambia le dimensioni */
            var S = SC.sel_(el), w = st.w, o = st.offset, rad = cs(el).borderTopLeftRadius || "0px";
            var css = cs(el).position === "static" ? S + "{position:relative}\n" : "";
            css += S + ps + "{content:\"\";position:absolute;inset:" + (-(w + o)) + "px;padding:" + w + "px;box-sizing:border-box;border-radius:calc(" + rad + " + " + (w + o) + "px);" +
                "background:" + grad.css(st.grad) + ";-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;" +
                "mask:linear-gradient(#000 0 0) content-box exclude,linear-gradient(#000 0 0);pointer-events:none}";
            SC.setRule(el, "ol", css);
        } else {
            el.style.setProperty("outline", st.w + "px solid " + st.grad.stops[0].c);
            el.style.setProperty("outline-offset", st.offset + "px");
            SC.toast("Contorno gradient non applicabile a questo elemento senza alterarlo: uso il primo colore", "warn");
        }
    } else {
        el.style.setProperty("outline", st.w + "px " + st.style + " " + st.color);
        el.style.setProperty("outline-offset", st.offset + "px");
    }
    setJson(el, "data-sc-ol", st);
}

/* ------------------------------------------------------------------ text fx */
function rebuildTextFx(el) {
    var tg = getJson(el, "data-sc-tg", null), to = getJson(el, "data-sc-to", null);
    var useTG = !!(tg && tg.on), useGO = !!(to && to.on && to.mode === "gradient"), useSO = !!(to && to.on && to.mode === "solid");
    SC.delRule(el, "tg"); SC.delRule(el, "to");
    el.style.removeProperty("-webkit-text-stroke"); el.style.removeProperty("paint-order");
    if (useGO) {
        var bothFree = function () { var a = getComputedStyle(el, "::after").content, b = getComputedStyle(el, "::before").content; return /^(none|normal)?$/.test(a) && /^(none|normal)?$/.test(b); };
        var ok = !REPLACED.test(el.tagName) && SC.safeToPosition(el) && (useTG ? bothFree() : !!SC.freePseudo(el));
        if (!ok) {
            useGO = false; useSO = true;
            to = { on: true, mode: "solid", w: to.w, color: to.grad.stops[0].c, grad: to.grad };
            SC.toast("Outline gradient non applicabile a questo elemento senza alterarlo: uso il primo colore", "warn");
        }
    }
    if (useTG || useGO) el.setAttribute("data-sc-text", el.textContent); else el.removeAttribute("data-sc-text");
    if (useSO) { el.style.setProperty("-webkit-text-stroke", to.w + "px " + to.color); el.style.setProperty("paint-order", "stroke fill"); }
    var S = SC.sel_(el);
    var pos = cs(el).position === "static" ? "position:relative;" : "";
    var hide = "color:transparent!important;-webkit-text-fill-color:transparent!important";
    var layer = "content:attr(data-sc-text);position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;white-space:pre-wrap;-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent";
    if (useGO) {
        var ps = useTG ? "::before" : SC.freePseudo(el);
        var outline = S + ps + "{" + layer + ";z-index:-1;-webkit-text-stroke:" + (to.w * 2) + "px transparent;background-image:" + grad.css(to.grad) + "}";
        if (useTG) {
            SC.setRule(el, "to", S + "{" + pos + "isolation:isolate;" + hide + "}\n" + S + " *{-webkit-text-fill-color:transparent!important}\n" + outline + "\n" +
                S + "::after{" + layer + ";background-image:" + grad.css(tg.grad) + "}");
        } else SC.setRule(el, "to", S + "{" + pos + "isolation:isolate}\n" + outline);
    } else if (useTG) {
        SC.setRule(el, "tg", S + "{background-image:" + grad.css(tg.grad) + "!important;-webkit-background-clip:text!important;background-clip:text!important;" + hide + "}\n" + S + " *{-webkit-text-fill-color:transparent!important}");
    }
}
function applyTextGradient(el, st) { setJson(el, "data-sc-tg", st && st.on ? st : null); rebuildTextFx(el); }
function applyTextOutline(el, st) { setJson(el, "data-sc-to", st && st.on ? st : null); rebuildTextFx(el); }

/* effetti: classi solo per lo stile statico, l'animazione si ACCODA a quelle del sito */
function applyFx(el, name, speed) {
    SC.fxList.forEach(function (f) { el.classList.remove("sc-fx-" + f); });
    el.removeAttribute("data-sc-fx");
    el.style.removeProperty("--sc-fx-s");
    if (el.hasAttribute("data-sc-fxdisp")) { el.style.removeProperty("display"); el.removeAttribute("data-sc-fxdisp"); }
    var spec = null;
    if (name) {
        SC.ensureFx();
        el.classList.add("sc-fx-" + name); el.setAttribute("data-sc-fx", name);
        var a = SC.fxAnim[name];
        if (a) {
            spec = speed ? a.replace(/^(\S+)\s+[\d.]+s/, "$1 " + speed + "s") : a;
            /* translate/rotate/scale non agiscono sugli elementi inline: inline-block solo se serve */
            if (/^(pulse|shake|bounce|spin)$/.test(name) && cs(el).display === "inline") { el.style.display = "inline-block"; el.setAttribute("data-sc-fxdisp", "1"); }
        }
    }
    SC.setAnim(el, "fx", spec);
    if (!el.getAttribute("class")) el.removeAttribute("class");
    if (el.getAttribute("style") === "") el.removeAttribute("style");
}
function applyMarquee(el, st) {
    SC.delRule(el, "mq");
    if (el.hasAttribute("data-sc-mqdisp")) { el.style.removeProperty("display"); el.removeAttribute("data-sc-mqdisp"); }
    if (!st || !st.on) {
        SC.setAnim(el, "mq", null); setJson(el, "data-sc-mq", null);
        if (!document.querySelector("[data-sc-mq]")) SC.css.del("mq-body");
        return;
    }
    var S = SC.sel_(el), c = cs(el), rule;
    if (!SC.safeToTransform(el)) SC.toast("Attenzione: questo elemento contiene parti fisse o ancorate fuori da lui; durante lo scorrimento potrebbero muoversi", "warn");
    if (c.display === "inline" && c.position === "static" && SC.safeToPosition(el)) rule = S + "{position:relative;left:var(--sc-mq)}";
    else {
        if (c.display === "inline") { el.style.display = "inline-block"; el.setAttribute("data-sc-mqdisp", "1"); }
        rule = S + "{translate:var(--sc-mq) 0}";
    }
    SC.setRule(el, "mq", rule);
    SC.setAnim(el, "mq", "sc-mqv " + st.speed + "s linear infinite" + (st.dir === "reverse" ? " reverse" : ""));
    SC.css.set("mq-body", "html,body{overflow-x:clip}");
    setJson(el, "data-sc-mq", st);
}

/* -------------------------------------------------------------- sfondo
   Di base lo sfondo viene cambiato direttamente sull'elemento (nessun effetto sul layout).
   Solo luminosita'/contrasto/zoom/tinta richiedono un livello separato (::before + isolation),
   e lo creiamo solo se non sposta nulla. */
function applyBg(el, st) {
    SC.delRule(el, "bg"); SC.setAnim(el, "bg", null);
    if (!st || st.mode === "none") { setJson(el, "data-sc-bg", null); return; }
    SC.ensureFx();
    var S = SC.sel_(el), isRoot = el === document.body || el === document.documentElement;
    var anim = st.anim, tile = st.tile || 600, d = [];
    if (st.mode === "color") { d.push("background-color:" + st.color); d.push("background-image:none"); }
    else if (st.mode === "gradient") d.push("background-image:" + grad.css(st.grad));
    else if (st.mode === "image" && st.img) d.push("background-image:url(\"" + st.img.replace(/"/g, "%22") + "\")");
    if (st.mode !== "color") {
        if (anim === "panx") { d.push("background-repeat:repeat"); d.push("background-size:" + tile + "px 100%"); }
        else if (anim === "pany") { d.push("background-repeat:repeat"); d.push("background-size:100% " + tile + "px"); }
        else if (anim === "gshift") { d.push("background-size:300% 300%"); }
        else { d.push("background-size:" + (st.size || "cover")); d.push("background-position:center"); d.push("background-repeat:" + (st.repeat || "no-repeat")); }
    }
    d.push("--sc-tile:" + tile + "px");
    var dir = st.dir === "reverse" ? " reverse" : "";
    var spec = anim === "panx" ? "sc-panx " + st.speed + "s linear infinite" + dir
             : anim === "pany" ? "sc-pany " + st.speed + "s linear infinite" + dir
             : anim === "gshift" ? "sc-gshift " + st.speed + "s ease infinite"
             : anim === "zoom" ? "sc-zoom " + st.speed + "s ease-in-out infinite alternate"
             : anim === "hue" ? "sc-hue " + st.speed + "s linear infinite" : null;
    var needLayer = st.bright !== 100 || st.contrast !== 100 || anim === "zoom" || anim === "hue";
    var ps = needLayer ? SC.freePseudo(el) : null;
    if (needLayer && ps && (isRoot || SC.safeToPosition(el))) {
        d.push("--sc-b:" + (st.bright / 100)); d.push("--sc-c:" + (st.contrast / 100));
        if (spec) d.push("animation:" + spec);
        if (anim !== "hue") d.push("filter:brightness(" + (st.bright / 100) + ") contrast(" + (st.contrast / 100) + ")");
        var css = (!isRoot && cs(el).position === "static") ? S + "{position:relative}\n" : "";
        css += S + "{isolation:isolate}\n";
        css += S + ps + "{content:\"\";position:" + (isRoot ? "fixed" : "absolute") + ";inset:0;z-index:-1;pointer-events:none;" + d.join(";") + "}";
        SC.setRule(el, "bg", css);
    } else {
        if (needLayer) SC.toast("Luminosita', contrasto, zoom e tinta qui richiederebbero di alterare l'elemento: sfondo applicato senza questi effetti", "warn");
        SC.setRule(el, "bg", S + "{" + d.map(function (x) { return x + "!important"; }).join(";") + "}");
        if (spec && /sc-(panx|pany|gshift)/.test(spec)) SC.setAnim(el, "bg", spec);
    }
    setJson(el, "data-sc-bg", st);
}

/* ------------------------------------------------------------------- sezioni */
function sLayout(el) {
    var r = el.getBoundingClientRect();
    var b = h("div", {});
    var wI = ui.num(Math.round(r.width), { min: 1, w: "70px" }, function (v) { el.style.width = v + "px"; if (cs(el).display === "inline") el.style.display = "inline-block"; changed("Larghezza"); });
    var hI = ui.num(Math.round(r.height), { min: 1, w: "70px" }, function (v) { el.style.height = v + "px"; if (cs(el).display === "inline") el.style.display = "inline-block"; changed("Altezza"); });
    b.appendChild(ui.row("Dimensioni", "L", wI, "A", hI,
        ui.btn("auto", function () { el.style.removeProperty("width"); el.style.removeProperty("height"); changed("Dimensioni auto"); SC.refreshPane(); }, "sm")));
    var tx = ui.num(parseFloat(el.getAttribute("data-sc-tx")) || 0, { w: "64px" }, function (v) { el.setAttribute("data-sc-tx", v); SC.applyTx(el); changed("Posizione"); });
    var ty = ui.num(parseFloat(el.getAttribute("data-sc-ty")) || 0, { w: "64px" }, function (v) { el.setAttribute("data-sc-ty", v); SC.applyTx(el); changed("Posizione"); });
    b.appendChild(ui.row("Posizione", "X", tx, "Y", ty, h("span", { class: "hint", text: "o trascina la maniglia" })));
    b.appendChild(ui.row("Rotazione", ui.range(parseFloat(el.getAttribute("data-sc-rot")) || 0, { min: -180, max: 180 }, function (v) { el.setAttribute("data-sc-rot", v); SC.applyTx(el); changed("Rotazione"); })));
    b.appendChild(ui.row("Scala %", ui.range(Math.round((parseFloat(el.getAttribute("data-sc-scale")) || 1) * 100), { min: 10, max: 300 }, function (v) { el.setAttribute("data-sc-scale", v / 100); SC.applyTx(el); changed("Scala"); })));
    var fh = ui.btn("Specchia orizz.", function () { el.setAttribute("data-sc-flipx", el.getAttribute("data-sc-flipx") === "1" ? "0" : "1"); SC.applyTx(el); changed("Flip"); }, "sm");
    var fv = ui.btn("Specchia vert.", function () { el.setAttribute("data-sc-flipy", el.getAttribute("data-sc-flipy") === "1" ? "0" : "1"); SC.applyTx(el); changed("Flip"); }, "sm");
    var rs = ui.btn("Reset", function () { ["tx", "ty", "rot", "scale", "flipx", "flipy"].forEach(function (k) { el.removeAttribute("data-sc-" + k); }); SC.applyTx(el); changed("Reset trasformazioni"); SC.refreshPane(); }, "sm danger");
    b.appendChild(ui.row("Flip", fh, fv, rs));
    var op = parseFloat(el.style.opacity); op = isNaN(op) ? 1 : op;
    b.appendChild(ui.row("Opacita %", ui.range(Math.round(op * 100), { min: 0, max: 100 }, function (v) { el.style.opacity = v / 100; changed("Opacita"); })));
    b.appendChild(ui.row("Angoli", ui.range(Math.round(pxNum(cs(el).borderTopLeftRadius)), { min: 0, max: 300 }, function (v) { el.style.borderRadius = v + "px"; changed("Angoli"); }),
        ui.btn("cerchio", function () { el.style.borderRadius = "50%"; changed("Angoli"); }, "sm")));
    var mq = getJson(el, "data-sc-mq", { on: false, speed: 12, dir: "normal" });
    b.appendChild(ui.row("Marquee", ui.check("scorrimento", mq.on, function (v) { mq.on = v; applyMarquee(el, mq); changed("Marquee"); }),
        "s", ui.num(mq.speed, { min: 1, w: "56px" }, function (v) { mq.speed = v; if (mq.on) applyMarquee(el, mq); changed("Marquee"); }),
        ui.select([["normal", "verso sx"], ["reverse", "verso dx"]], mq.dir, function (v) { mq.dir = v; if (mq.on) applyMarquee(el, mq); changed("Marquee"); })));
    return b;
}

function sOutline(el) {
    var st = getJson(el, "data-sc-ol", { on: false, mode: "solid", w: 3, color: "#ff0066", style: "solid", offset: 0, grad: grad.make() });
    if (!st.grad) st.grad = grad.make();
    var b = h("div", {});
    var gbox = h("div", {});
    function apply() { applyBoxOutline(el, st); changed("Contorno"); }
    function drawG() { gbox.innerHTML = ""; if (st.mode === "gradient") gbox.appendChild(grad.editor(st.grad, apply)); }
    b.appendChild(ui.row("Contorno", ui.toggle(st.on, function (v) { st.on = v; apply(); })));
    b.appendChild(ui.row("Tipo", ui.select([["solid", "Colore"], ["gradient", "Gradient"]], st.mode, function (v) { st.mode = v; drawG(); apply(); })));
    b.appendChild(ui.row("Spessore", ui.range(st.w, { min: 1, max: 40 }, function (v) { st.w = v; apply(); })));
    b.appendChild(ui.row("Colore", ui.color(st.color, function (v) { st.color = v; apply(); }),
        ui.select(["solid", "dashed", "dotted", "double", "groove", "ridge"], st.style, function (v) { st.style = v; apply(); })));
    b.appendChild(ui.row("Distanza", ui.range(st.offset, { min: -20, max: 40 }, function (v) { st.offset = v; apply(); })));
    b.appendChild(gbox); drawG();
    b.appendChild(ui.hint("Il contorno gradient usa border-image (non segue gli angoli arrotondati)."));
    return b;
}

function sBackground(el) {
    var st = getJson(el, "data-sc-bg", null) || { mode: "none", color: "#ffffff", grad: grad.make(), img: "", size: "cover", tile: 600, repeat: "no-repeat", bright: 100, contrast: 100, anim: "none", speed: 12, dir: "normal" };
    if (!st.grad) st.grad = grad.make();
    var b = h("div", {});
    var dyn = h("div", {});
    function apply() { applyBg(el, st); changed("Sfondo"); }
    function draw() {
        dyn.innerHTML = "";
        if (st.mode === "none") return;
        if (st.mode === "color") dyn.appendChild(ui.row("Colore", ui.color(st.color, function (v) { st.color = v; apply(); })));
        if (st.mode === "gradient") dyn.appendChild(grad.editor(st.grad, apply));
        if (st.mode === "image") {
            dyn.appendChild(ui.row("Immagine", ui.btn("Scegli dal PC...", async function () {
                var f = await SC.pickFile("image/*"); if (!f) return;
                st.img = await SC.placeFile(f, "images"); apply(); draw();
            }), h("span", { class: "hint mono", text: st.img ? st.img.slice(0, 40) : "nessuna" })));
            dyn.appendChild(ui.row("Adattamento", ui.select(["cover", "contain", "auto", "100% 100%"], st.size, function (v) { st.size = v; apply(); }),
                ui.select(["no-repeat", "repeat", "repeat-x", "repeat-y"], st.repeat, function (v) { st.repeat = v; apply(); })));
        }
        dyn.appendChild(ui.row("Luminosita %", ui.range(st.bright, { min: 0, max: 300 }, function (v) { st.bright = v; apply(); })));
        dyn.appendChild(ui.row("Contrasto %", ui.range(st.contrast, { min: 0, max: 300 }, function (v) { st.contrast = v; apply(); })));
        var anims = [["none", "nessuna"], ["panx", "marquee orizzontale"], ["pany", "marquee verticale"], ["zoom", "zoom pulsante"], ["hue", "cambio tinta"], ["gshift", "gradient che scorre"]];
        dyn.appendChild(ui.row("Animazione", ui.select(anims, st.anim, function (v) { st.anim = v; apply(); })));
        dyn.appendChild(ui.row("Durata s", ui.range(st.speed, { min: 1, max: 120 }, function (v) { st.speed = v; apply(); }),
            ui.select([["normal", "avanti"], ["reverse", "indietro"]], st.dir, function (v) { st.dir = v; apply(); })));
        dyn.appendChild(ui.row("Tile px", ui.num(st.tile, { min: 20, w: "70px" }, function (v) { st.tile = v; apply(); }), h("span", { class: "hint", text: "larghezza ripetizione per il marquee" })));
    }
    b.appendChild(ui.row("Sfondo", ui.select([["none", "(originale)"], ["color", "Colore"], ["gradient", "Gradient (2+ colori)"], ["image", "Immagine"]], st.mode, function (v) { st.mode = v; draw(); apply(); })));
    b.appendChild(dyn); draw();
    b.appendChild(ui.hint("Lo sfondo e' un livello dietro al contenuto: luminosita/contrasto e animazioni non toccano testi e figli."));
    return b;
}

var FONTS = ["", "Arial", "Georgia", "Times New Roman", "Courier New", "Verdana", "Tahoma", "Trebuchet MS", "Impact", "Comic Sans MS", "Segoe UI", "Palatino Linotype", "monospace", "cursive", "fantasy", "serif", "sans-serif"];
function uploadedFonts() { return SC.css.keys().filter(function (k) { return k.indexOf("font-") === 0; }).map(function (k) { return k.slice(5); }); }

function sText(el) {
    var c = cs(el);
    var b = h("div", {});
    b.appendChild(ui.row("", ui.btn("Scrivi / modifica testo", function () { SC.startTextEdit(el); }, "primary"),
        ui.hint("oppure doppio click sul testo")));
    b.appendChild(ui.row("Colore", ui.color(el.style.color || c.color, function (v) { el.style.color = v; changed("Colore testo"); }),
        ui.btn("random", function () { el.style.color = toHex(randGoodColor()); changed("Colore testo"); SC.refreshPane(); }, "sm")));
    b.appendChild(ui.row("Dimensione", ui.range(Math.round(pxNum(c.fontSize)), { min: 6, max: 200 }, function (v) { el.style.fontSize = v + "px"; changed("Dimensione testo"); })));
    var fam = h("select", {});
    var all = FONTS.concat(uploadedFonts());
    all.forEach(function (f) { fam.appendChild(h("option", { value: f, text: f || "(originale)" })); });
    var curFam = (el.style.fontFamily || "").replace(/["']/g, "").split(",")[0].trim();
    fam.value = all.indexOf(curFam) >= 0 ? curFam : "";
    fam.addEventListener("change", function () { if (fam.value) el.style.fontFamily = '"' + fam.value + '", sans-serif'; else el.style.removeProperty("font-family"); changed("Font"); });
    b.appendChild(ui.row("Font", fam, ui.btn("Carica font...", async function () {
        var f = await SC.pickFile(".ttf,.otf,.woff,.woff2"); if (!f) return;
        var name = f.name.replace(/\.[^.]+$/, "").replace(/[^\w\- ]/g, "");
        var url = await SC.placeFile(f, "fonts");
        SC.css.set("font-" + name, "@font-face{font-family:\"" + name + "\";src:url(\"" + url + "\")}");
        el.style.fontFamily = '"' + name + '", sans-serif'; changed("Font caricato"); SC.refreshPane();
    }, "sm")));
    var wt = ui.select([["", "(originale)"], ["300", "light"], ["400", "normale"], ["600", "semibold"], ["700", "bold"], ["900", "black"]], el.style.fontWeight || "", function (v) { if (v) el.style.fontWeight = v; else el.style.removeProperty("font-weight"); changed("Peso"); });
    b.appendChild(ui.row("Stile", wt,
        ui.check("corsivo", el.style.fontStyle === "italic", function (v) { el.style.fontStyle = v ? "italic" : ""; changed("Corsivo"); }),
        ui.check("sottolineato", /underline/.test(el.style.textDecoration), function (v) { var s = el.style.textDecoration.replace(/underline/, "").trim(); el.style.textDecoration = (s + (v ? " underline" : "")).trim(); changed("Sottolineato"); }),
        ui.check("barrato", /line-through/.test(el.style.textDecoration), function (v) { var s = el.style.textDecoration.replace(/line-through/, "").trim(); el.style.textDecoration = (s + (v ? " line-through" : "")).trim(); changed("Barrato"); })));
    b.appendChild(ui.row("Maiuscole", ui.select([["", "(originale)"], ["uppercase", "MAIUSCOLO"], ["lowercase", "minuscolo"], ["capitalize", "Iniziali"]], el.style.textTransform || "", function (v) { if (v) el.style.textTransform = v; else el.style.removeProperty("text-transform"); changed("Maiuscole"); }),
        ui.select([["", "allineam."], ["left", "sx"], ["center", "centro"], ["right", "dx"], ["justify", "giustif."]], el.style.textAlign || "", function (v) { if (v) el.style.textAlign = v; else el.style.removeProperty("text-align"); changed("Allineamento"); })));
    b.appendChild(ui.row("Spaziatura", ui.range(Math.round(pxNum(c.letterSpacing)), { min: -5, max: 40 }, function (v) { el.style.letterSpacing = v + "px"; changed("Spaziatura lettere"); })));
    b.appendChild(ui.row("Interlinea", ui.range(Math.round((pxNum(c.lineHeight) / (pxNum(c.fontSize) || 16)) * 10) / 10 || 1.4, { min: 0.8, max: 4, step: 0.1 }, function (v) { el.style.lineHeight = v; changed("Interlinea"); })));

    /* gradient testo */
    var tg = getJson(el, "data-sc-tg", { on: false, grad: grad.make("#ff3d81", "#3d7bff") });
    var tgBox = h("div", {});
    function tgApply() { applyTextGradient(el, tg); changed("Gradient testo"); }
    function tgDraw() { tgBox.innerHTML = ""; if (tg.on) tgBox.appendChild(grad.editor(tg.grad, tgApply)); }
    b.appendChild(ui.section("Gradient sul testo (2+ colori)", h("div", {}, ui.row("Attivo", ui.toggle(tg.on, function (v) { tg.on = v; tgDraw(); tgApply(); })), tgBox), tg.on));
    tgDraw();

    /* outline testo */
    var to = getJson(el, "data-sc-to", { on: false, mode: "solid", w: 2, color: "#000000", grad: grad.make("#00e5ff", "#ff00aa") });
    if (!to.grad) to.grad = grad.make("#00e5ff", "#ff00aa");
    var toBox = h("div", {});
    function toApply() { applyTextOutline(el, to); changed("Outline testo"); }
    function toDraw() { toBox.innerHTML = ""; if (to.mode === "gradient") toBox.appendChild(grad.editor(to.grad, toApply)); }
    b.appendChild(ui.section("Outline del testo", h("div", {},
        ui.row("Attivo", ui.toggle(to.on, function (v) { to.on = v; toApply(); })),
        ui.row("Tipo", ui.select([["solid", "Colore"], ["gradient", "Gradient"]], to.mode, function (v) { to.mode = v; toDraw(); toApply(); })),
        ui.row("Spessore", ui.range(to.w, { min: 1, max: 20 }, function (v) { to.w = v; toApply(); })),
        ui.row("Colore", ui.color(to.color, function (v) { to.color = v; toApply(); })), toBox), to.on));
    toDraw();

    /* ombra */
    var sh = { x: 2, y: 2, b: 4, c: "#000000" };
    b.appendChild(ui.section("Ombra del testo", h("div", {},
        ui.row("Offset", "X", ui.num(sh.x, { w: "56px" }, function (v) { sh.x = v; setSh(); }), "Y", ui.num(sh.y, { w: "56px" }, function (v) { sh.y = v; setSh(); }), "blur", ui.num(sh.b, { min: 0, w: "56px" }, function (v) { sh.b = v; setSh(); })),
        ui.row("Colore", ui.color(sh.c, function (v) { sh.c = v; setSh(); }), ui.btn("togli", function () { el.style.removeProperty("text-shadow"); changed("Ombra"); }, "sm"))), false));
    function setSh() { el.style.textShadow = sh.x + "px " + sh.y + "px " + sh.b + "px " + sh.c; changed("Ombra"); }

    /* effetti speciali */
    var curFx = el.getAttribute("data-sc-fx") || "";
    var fxSp = parseFloat(el.style.getPropertyValue("--sc-fx-s")) || 0;
    b.appendChild(ui.section("Effetti speciali", h("div", {},
        ui.row("Effetto", ui.select([["", "(nessuno)"]].concat(SC.fxList.map(function (f) { return [f, f]; })), curFx, function (v) { curFx = v; applyFx(el, curFx, fxSp); changed("Effetto"); })),
        ui.row("Durata s", ui.range(fxSp || 2, { min: 0.2, max: 10, step: 0.1 }, function (v) { fxSp = v; if (curFx) applyFx(el, curFx, fxSp); changed("Effetto"); })),
        ui.hint("neon, fire, glow, shadow3d: statici. pulse, shake, flicker, bounce, glitch, spin, rainbow: animati.")), !!curFx));
    return b;
}

function sImage(el, info) {
    var b = h("div", {});
    info = info || SC.imageInfo(el);
    if (!info) return b;
    var img = info.img || null, isImg = !!img && img.tagName === "IMG";
    var src = isImg ? (img.currentSrc || img.getAttribute("src") || "") : info.type === "bg" ? (SC.bgUrlOf(info.el) || "") : (img ? img.getAttribute("href") || img.getAttribute("xlink:href") || "" : "");
    b.appendChild(ui.row("Tipo", h("span", { class: "hint", text: info.label })));
    b.appendChild(ui.row("Sorgente", h("span", { class: "hint mono grow", text: src.length > 64 ? "..." + src.slice(-62) : src })));
    var big = ui.btn("Sostituisci con un'immagine dal PC...", function () { SC.pickAndReplaceImage(info).then(function (ok) { if (ok) SC.refreshPane(); }); }, "primary");
    big.style.cssText = "width:100%;padding:9px;font-size:13px";
    b.appendChild(h("div", { class: "row" }, big));
    if (info.type === "inner") b.appendChild(ui.row("", ui.btn("Seleziona l'immagine contenuta", function () { SC.select(img); }, "sm")));
    if (info.type === "bg") {
        b.appendChild(ui.row("", ui.btn("Ripristina sfondo originale", function () { SC.delRule(info.el, "bgimg"); SC.commit("Sfondo ripristinato"); SC.refreshPane(); }, "sm"),
            ui.btn("Togli immagine di sfondo", function () { SC.setRule(info.el, "bgimg", SC.sel_(info.el) + "{background-image:none!important}"); SC.commit("Sfondo rimosso"); SC.refreshPane(); }, "sm danger")));
    }
    if (isImg) {
        b.appendChild(ui.section("Sostituisci con tinta unita / gradient", sFill(img), false));
        b.appendChild(ui.row("", ui.btn("Disegna sull'immagine (stile Paint)...", function () { SC.openPaint(img); })));
        b.appendChild(ui.row("Alt text", ui.text(img.getAttribute("alt") || "", function (v) { img.setAttribute("alt", v); changed("Alt"); })));
        b.appendChild(ui.row("Adattamento", ui.select(["", "cover", "contain", "fill", "none", "scale-down"], img.style.objectFit || "", function (v) { if (v) img.style.objectFit = v; else img.style.removeProperty("object-fit"); changed("object-fit"); })));
    }
    if (!img) return b;
    /* filtri */
    var F = { brightness: 100, contrast: 100, saturate: 100, "hue-rotate": 0, blur: 0, grayscale: 0, sepia: 0, invert: 0 };
    var cur = img.style.filter || "";
    cur.replace(/([\w-]+)\(([-\d.]+)(%|deg|px)?\)/g, function (_, n, v) { if (n in F) F[n] = parseFloat(v) * ((n === "hue-rotate" || n === "blur") ? 1 : 100); return ""; });
    function applyF() {
        var parts = [];
        Object.keys(F).forEach(function (k) {
            var v = F[k]; var def = (k === "brightness" || k === "contrast" || k === "saturate") ? 100 : 0;
            if (v === def) return;
            parts.push(k + "(" + (k === "hue-rotate" ? v + "deg" : k === "blur" ? v + "px" : (v / 100)) + ")");
        });
        if (parts.length) img.style.filter = parts.join(" "); else img.style.removeProperty("filter");
        changed("Filtri immagine");
    }
    var fb = h("div", {});
    [["brightness", "Luminosita", 0, 300], ["contrast", "Contrasto", 0, 300], ["saturate", "Saturazione", 0, 300], ["hue-rotate", "Tinta", 0, 360], ["blur", "Sfocatura", 0, 30], ["grayscale", "Grigi", 0, 100], ["sepia", "Seppia", 0, 100], ["invert", "Inverti", 0, 100]].forEach(function (f) {
        fb.appendChild(ui.row(f[1], ui.range(F[f[0]], { min: f[2], max: f[3] }, function (v) { F[f[0]] = v; applyF(); })));
    });
    b.appendChild(ui.section("Filtri", fb, false));
    return b;
}

function sFill(img) {
    var st = { mode: "gradient", color: "#ff0066", grad: grad.make(), w: Math.round(img.getBoundingClientRect().width) || img.naturalWidth || 600, hh: Math.round(img.getBoundingClientRect().height) || img.naturalHeight || 400 };
    var b = h("div", {}), gbox = h("div", {});
    function draw() { gbox.innerHTML = ""; if (st.mode === "gradient") gbox.appendChild(grad.editor(st.grad, function () {})); else gbox.appendChild(ui.row("Colore", ui.color(st.color, function (v) { st.color = v; }))); }
    b.appendChild(ui.row("Tipo", ui.select([["solid", "Tinta unita"], ["gradient", "Gradient"]], st.mode, function (v) { st.mode = v; draw(); })));
    b.appendChild(gbox); draw();
    b.appendChild(ui.row("Dimensione", ui.num(st.w, { min: 1, max: 4000, w: "70px" }, function (v) { st.w = v; }), "x", ui.num(st.hh, { min: 1, max: 4000, w: "70px" }, function (v) { st.hh = v; })));
    b.appendChild(ui.row("", ui.btn("Genera e applica", async function () {
        var w = clamp(st.w, 1, 4000), hh = clamp(st.hh, 1, 4000), c;
        if (st.mode === "gradient") c = grad.toCanvas(st.grad, w, hh);
        else { c = document.createElement("canvas"); c.width = w; c.height = hh; var x = c.getContext("2d"); x.fillStyle = st.color; x.fillRect(0, 0, w, hh); }
        try { SC.setImageSrc(img, await SC.canvasToUrl(c, "fill-" + Date.now() + ".png")); changed("Immagine generata"); } catch (e) { SC.toast("Errore: " + e.message, "err"); }
    }, "primary")));
    return b;
}

function sMedia(el) {
    var kind = el.tagName === "VIDEO" ? "video" : "audio";
    var b = h("div", {});
    var sp = parseFloat(el.getAttribute("data-sc-speed")) || el.defaultPlaybackRate || 1;
    b.appendChild(ui.row("Velocita'", ui.range(sp, { min: 0.25, max: 4, step: 0.05 }, function (v) {
        el.setAttribute("data-sc-speed", v); el.defaultPlaybackRate = v; el.playbackRate = v; changed("Velocita'");
    }), ui.btn("1x", function () { el.removeAttribute("data-sc-speed"); el.defaultPlaybackRate = 1; el.playbackRate = 1; changed("Velocita'"); SC.refreshPane(); }, "sm")));
    b.appendChild(ui.hint("Salvata come velocita' predefinita: all'apertura della pagina il " + kind + " parte a questa velocita'."));
    b.appendChild(ui.row("", ui.btn("Sostituisci " + kind + " dal PC...", async function () {
        var f = await SC.pickFile(kind + "/*"); if (!f) return;
        try {
            var url = await SC.placeFile(f, kind === "video" ? "videos" : "audio");
            el.querySelectorAll("source").forEach(function (s) { s.remove(); });
            el.src = url; el.load(); changed(kind + " sostituito"); SC.refreshPane();
        } catch (e) { SC.toast("Errore: " + e.message, "err"); }
    }, "primary"), ui.btn("Elimina", function () { SC.deleteSel(); }, "danger"),
        ui.btn("Play/Pausa", function () { if (el.paused) el.play(); else el.pause(); }, "sm")));
    ["controls", "autoplay", "loop", "muted"].forEach(function (a) {
        b.appendChild(ui.row("", ui.check(a, el.hasAttribute(a), function (v) { if (v) el.setAttribute(a, ""); else el.removeAttribute(a); if (a === "muted") el.muted = v; changed(a); })));
    });
    if (kind === "video") {
        b.appendChild(ui.row("Poster", ui.btn("Scegli copertina...", async function () {
            var f = await SC.pickFile("image/*"); if (!f) return; el.setAttribute("poster", await SC.placeFile(f, "images")); changed("Poster");
        }, "sm")));
    }
    return b;
}

/* ----------------------------------------------------------------- render tab */
function crumbs(el) {
    var path = [], n = el;
    while (n && n.nodeType === 1 && path.length < 8) { path.unshift(n); if (n === document.documentElement) break; n = n.parentElement; }
    var box = h("div", { class: "crumbs" });
    path.forEach(function (p) {
        if (p === document.documentElement) return;
        box.appendChild(h("span", { class: p === el ? "cur" : "", text: SC.describe(p), onclick: function () { SC.select(p); } }));
    });
    return box;
}

SC.addTab("el", "Elemento", function (root) {
    if (!SC.editMode) {
        root.appendChild(h("div", {}, ui.hint("La modalita' modifica e' spenta: il sito funziona normalmente."),
            ui.btn("Attiva modalita' modifica", function () { SC.setEditMode(true); }, "primary")));
        return;
    }
    var el = SC.sel;
    if (!el) {
        root.appendChild(h("div", {},
            ui.hint("Clicca un elemento della pagina per selezionarlo (testo, immagine, video, audio, sfondo...). Dopo la selezione qui compaiono gli strumenti adatti."),
            ui.hint("Doppio click su un testo = scrivi. Maniglia in alto a destra = sposta. Maniglia in basso a destra = ridimensiona. Frecce = nudge 1px. Canc = elimina."),
            ui.row("", ui.btn("Seleziona sfondo pagina (body)", function () { SC.select(document.body); }))));
        return;
    }
    var kind = SC.kindOf(el);
    root.appendChild(crumbs(el));
    var par = el.parentElement, kid = el.firstElementChild, prev = el.previousElementSibling, next = el.nextElementSibling;
    root.appendChild(h("div", { class: "row" },
        ui.btn("Padre", function () { if (par && par !== document.documentElement) SC.select(par); }, "sm"),
        ui.btn("Figlio", function () { if (kid) SC.select(kid); }, "sm"),
        ui.btn("< Prec", function () { if (prev) SC.select(prev); }, "sm"),
        ui.btn("Succ >", function () { if (next) SC.select(next); }, "sm"),
        ui.btn("Duplica", function () { SC.duplicateSel(); }, "sm"),
        ui.btn("Copia", function () { SC.copySel(false); }, "sm"),
        ui.btn("Taglia", function () { SC.copySel(true); }, "sm"),
        ui.btn("Incolla dopo", function () { SC.pasteClip("after"); }, "sm"),
        ui.btn("+ Inserisci", function () { SC.openTab("insert"); }, "sm"),
        ui.btn("Su", function () { if (prev) { prev.before(el); SC.commit("Spostato"); SC.updateOverlay(); } }, "sm"),
        ui.btn("Giu", function () { if (next) { next.after(el); SC.commit("Spostato"); SC.updateOverlay(); } }, "sm"),
        ui.btn("Elimina", function () { SC.deleteSel(); }, "sm danger")));

    var btnEl = el.closest ? el.closest("[data-sc-btn]") : null;
    if (btnEl) root.appendChild(ui.section("Bottone personalizzato", h("div", {},
        ui.row("", ui.btn("Modifica bottone (testo, azione, colori, forma)...", function () { SC.openButtonBuilder(btnEl); }, "primary")),
        ui.hint("Per provarlo esci dalla modalita' Modifica e cliccalo.")), true));
    var imgInfo = (kind === "video" || kind === "audio") ? null : SC.imageInfo(el);
    if (imgInfo) root.appendChild(ui.section(imgInfo.type === "bg" ? "Immagine di sfondo" : "Immagine", sImage(el, imgInfo), true));
    if (kind === "video" || kind === "audio") root.appendChild(ui.section(kind === "video" ? "Video" : "Audio", sMedia(el), true));
    var hasText = kind === "box" && el.textContent.trim().length > 0;
    if (hasText) root.appendChild(ui.section("Testo", sText(el), true));
    root.appendChild(ui.section("Posizione, dimensione, rotazione", sLayout(el), kind === "box" && !hasText));
    if (kind === "box") root.appendChild(ui.section("Sfondo", sBackground(el), false));
    root.appendChild(ui.section("Contorno elemento", sOutline(el), false));
    root.appendChild(ui.hint("Per attributi, link e classi apri la scheda Tag."));
}, 10);
