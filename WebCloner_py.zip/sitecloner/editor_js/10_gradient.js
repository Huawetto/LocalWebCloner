/* ----------------------------------------------------------------- gradient */
var grad = SC.grad = {};
grad.make = function (c1, c2) { return { type: "linear", angle: 90, stops: [{ c: c1 || "#ff3d81", p: 0 }, { c: c2 || "#3d7bff", p: 100 }] }; };
grad.random = function (n) {
    n = n || rndInt(2, 3);
    var st = [];
    for (var i = 0; i < n; i++) st.push({ c: toHex(randGoodColor()), p: Math.round(i * 100 / (n - 1)) });
    return { type: pick(["linear", "linear", "radial", "conic"]), angle: rndInt(0, 360), stops: st };
};
grad.stops = function (g) { return g.stops.slice().sort(function (a, b) { return a.p - b.p; }).map(function (s) { return s.c + " " + s.p + "%"; }).join(","); };
grad.css = function (g) {
    if (g.type === "radial") return "radial-gradient(circle," + grad.stops(g) + ")";
    if (g.type === "conic") return "conic-gradient(from " + g.angle + "deg," + grad.stops(g) + ")";
    return "linear-gradient(" + g.angle + "deg," + grad.stops(g) + ")";
};
grad.parse = function (str) { // meglio sempre tenere lo stato JSON: qui solo fallback
    return null;
};
grad.toCanvas = function (g, w, hh) {
    var c = document.createElement("canvas"); c.width = w; c.height = hh;
    var x = c.getContext("2d"), cx = w / 2, cy = hh / 2, gr;
    if (g.type === "radial") gr = x.createRadialGradient(cx, cy, 0, cx, cy, Math.hypot(w, hh) / 2);
    else if (g.type === "conic" && x.createConicGradient) gr = x.createConicGradient((g.angle - 90) * Math.PI / 180, cx, cy);
    else {
        var A = g.angle * Math.PI / 180, dx = Math.sin(A), dy = -Math.cos(A);
        var half = (Math.abs(w * Math.sin(A)) + Math.abs(hh * Math.cos(A))) / 2;
        gr = x.createLinearGradient(cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half);
    }
    g.stops.slice().sort(function (a, b) { return a.p - b.p; }).forEach(function (s) { gr.addColorStop(clamp(s.p / 100, 0, 1), s.c); });
    x.fillStyle = gr; x.fillRect(0, 0, w, hh);
    return c;
};
/* editor GUI: onChange(g) viene chiamato a ogni modifica; g e' modificato in place */
grad.editor = function (g, onChange) {
    var prev = h("div", { class: "grad-prev" });
    var stopsBox = h("div", {});
    var angleRow;
    function emit() { prev.style.background = grad.css(g); angleRow.style.display = g.type === "radial" ? "none" : ""; onChange(g); }
    function drawStops() {
        stopsBox.innerHTML = "";
        g.stops.forEach(function (s, i) {
            var row = h("div", { class: "stop" },
                ui.color(s.c, function (v) { s.c = v; emit(); }),
                ui.num(s.p, { min: 0, max: 100, w: "58px" }, function (v) { s.p = clamp(v, 0, 100); emit(); }),
                h("span", { text: "%" }),
                g.stops.length > 2 ? ui.btn("x", function () { g.stops.splice(i, 1); drawStops(); emit(); }, "sm danger") : null);
            stopsBox.appendChild(row);
        });
    }
    angleRow = ui.row("Angolo", ui.range(g.angle, { min: 0, max: 360 }, function (v) { g.angle = v; emit(); }));
    var box = h("div", {},
        prev,
        ui.row("Tipo", ui.select([["linear", "Lineare"], ["radial", "Radiale"], ["conic", "Conico"]], g.type, function (v) { g.type = v; emit(); })),
        angleRow,
        stopsBox,
        h("div", { class: "row" },
            ui.btn("+ colore", function () { var last = g.stops[g.stops.length - 1]; g.stops.push({ c: toHex(randGoodColor()), p: clamp(last.p, 0, 100) }); drawStops(); emit(); }, "sm"),
            ui.btn("Random", function () { var r = grad.random(g.stops.length); g.type = r.type; g.angle = r.angle; g.stops = r.stops; box.replaceWith(grad.editor(g, onChange)); onChange(g); }, "sm"),
            ui.btn("Inverti", function () { g.stops.forEach(function (s) { s.p = 100 - s.p; }); drawStops(); emit(); }, "sm")));
    drawStops();
    prev.style.background = grad.css(g);
    angleRow.style.display = g.type === "radial" ? "none" : "";
    return box;
};
