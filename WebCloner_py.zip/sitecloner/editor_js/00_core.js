var TOKEN = "__SC_TOKEN__";
if (window.__SC__) { return; }
var SC = { tabs: [], selListeners: [], history: [], future: [], server: null, sel: null,
           editMode: false, editingEl: null, dirty: false, active: "el" };
window.__SC__ = SC;
SC.hasToken = TOKEN !== "__SC" + "_TOKEN__";

/* ------------------------------------------------------------------ helpers */
function h(tag, props) {
    var el = document.createElement(tag);
    props = props || {};
    for (var k in props) {
        var v = props[k];
        if (v == null || v === false) continue;
        if (k === "class") el.className = v;
        else if (k === "style") { if (typeof v === "string") el.style.cssText = v; else Object.assign(el.style, v); }
        else if (k === "text") el.textContent = v;
        else if (k === "html") el.innerHTML = v;
        else if (k.slice(0, 2) === "on" && typeof v === "function") el.addEventListener(k.slice(2), v);
        else if (k === "value" || k === "checked" || k === "disabled" || k === "selected") el[k] = v;
        else el.setAttribute(k, v === true ? "" : v);
    }
    for (var i = 2; i < arguments.length; i++) {
        var c = arguments[i];
        if (c == null || c === false) continue;
        if (Array.isArray(c)) c.forEach(function (x) { if (x != null && x !== false) el.appendChild(typeof x === "string" ? document.createTextNode(x) : x); });
        else el.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return el;
}
SC.h = h;
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function rnd(a, b) { return a + Math.random() * (b - a); }
function rndInt(a, b) { return Math.floor(rnd(a, b + 1)); }
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function debounce(fn, ms) {
    var t;
    var d = function () { var a = arguments, s = this; clearTimeout(t); t = setTimeout(function () { fn.apply(s, a); }, ms); };
    d.cancel = function () { clearTimeout(t); };
    return d;
}
SC.util = { clamp: clamp, rnd: rnd, rndInt: rndInt, pick: pick, debounce: debounce };

function parseColor(str) {
    var c = document.createElement("canvas"); c.width = c.height = 1;
    var x = c.getContext("2d", { willReadFrequently: true });
    x.clearRect(0, 0, 1, 1);
    x.fillStyle = "#000"; x.fillStyle = str || "#000";
    x.fillRect(0, 0, 1, 1);
    var d = x.getImageData(0, 0, 1, 1).data;
    return { r: d[0], g: d[1], b: d[2], a: d[3] / 255 };
}
function toHex(str) {
    var p = parseColor(str);
    function t(n) { return ("0" + n.toString(16)).slice(-2); }
    return "#" + t(p.r) + t(p.g) + t(p.b);
}
function hsl(hh, s, l) { return "hsl(" + Math.round(hh) + "," + Math.round(s) + "%," + Math.round(l) + "%)"; }
function randColor() { return hsl(rnd(0, 360), rnd(60, 95), rnd(35, 65)); }
function randGoodColor() { // niente giallo, bianco o nero scuro
    var hh; do { hh = rnd(0, 360); } while (hh > 42 && hh < 72);
    return hsl(hh, rnd(70, 95), rnd(38, 62));
}
SC.color = { parse: parseColor, hex: toHex, rand: randColor, randGood: randGoodColor, hsl: hsl };

/* ------------------------------------------------------------ server / API */
SC.api = async function (name, o) {
    o = o || {};
    var url = "/__sc__/" + name;
    if (o.query) url += "?" + Object.keys(o.query).map(function (k) { return k + "=" + encodeURIComponent(o.query[k]); }).join("&");
    var init = { method: o.json !== undefined || o.body !== undefined ? "POST" : (o.method || "GET"), headers: { "X-SC-Token": TOKEN } };
    if (o.json !== undefined) { init.body = JSON.stringify(o.json); init.headers["Content-Type"] = "application/json"; }
    else if (o.body !== undefined) { init.body = o.body; init.headers["Content-Type"] = "application/octet-stream"; }
    var r = await fetch(url, init);
    var data = null;
    try { data = await r.json(); } catch (e) { data = { error: "Risposta non valida" }; }
    if (!r.ok) { var err = new Error(data.error || ("HTTP " + r.status)); err.data = data; throw err; }
    return data;
};
SC.ping = async function () {
    if (location.protocol === "file:" || !SC.hasToken) { SC.server = null; return null; }
    try { SC.server = await SC.api("ping"); } catch (e) { SC.server = null; }
    return SC.server;
};
SC.needServer = function (what) {
    if (SC.server) return true;
    SC.toast((what || "Questa funzione") + " richiede il server di editing: avvia  python crawl.py --serve <cartella>  e apri il sito da http://127.0.0.1:PORTA/", "err");
    return false;
};
SC.pagePath = function () {
    var p = decodeURIComponent(location.pathname);
    return /\/$/.test(p) ? p + "index.html" : p;
};
/* cartella del sito = primo segmento del percorso, ma SOLO se e' una cartella: con la pagina alla
   radice del server (/index.html) il primo segmento e' il file stesso, e usarlo come cartella
   faceva fallire ogni upload ("il file esiste gia'", WinError 183) */
SC.siteRoot = function () {
    var seg = SC.pagePath().split("/").filter(Boolean);
    return seg.length >= 2 ? "/" + seg[0] : "";
};

/* relativo fra due path URL assoluti (stile "../x/y.png") */
SC.rel = function (to, from) {
    from = from || SC.pagePath();
    var f = from.split("/"); f.pop();
    var t = to.split("/");
    var i = 0;
    while (i < f.length && i < t.length - 1 && f[i] === t[i]) i++;
    var up = f.length - i, out = [];
    for (var k = 0; k < up; k++) out.push("..");
    return out.concat(t.slice(i)).map(function (s) { return s === ".." ? s : encodeURIComponent(s).replace(/%2F/g, "/"); }).join("/");
};
SC.abs = function (rel, from) { // risolve un url relativo alla pagina -> path assoluto
    try { return decodeURIComponent(new URL(rel, location.origin + (from || location.pathname)).pathname); } catch (e) { return rel; }
};

SC.readDataURL = function (blob) {
    return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(r.result); }; r.onerror = rej; r.readAsDataURL(blob); });
};
SC.upload = async function (blob, kind, name, dirOverride) {
    if (!SC.server) throw new Error("server non attivo");
    var dir = dirOverride || (SC.siteRoot() + "/_uploads/" + (kind || "files"));
    return SC.api("upload", { query: { dir: dir, name: name || blob.name || "file.bin" }, body: blob });
};
/* salva un file scelto dall'utente: con server -> file sul disco (URL relativo), senza -> data URL */
SC.placeFile = async function (file, kind) {
    if (SC.server) {
        var up = await SC.upload(file, kind, file.name);
        return SC.rel(up.path);
    }
    return SC.readDataURL(file);
};
SC.pickFile = function (accept, multiple) {
    return new Promise(function (resolve) {
        var i = document.createElement("input");
        i.type = "file"; if (accept) i.accept = accept; if (multiple) i.multiple = true;
        i.style.display = "none";
        i.setAttribute("data-sc-ui", "1");
        i.addEventListener("change", function () { resolve(multiple ? Array.prototype.slice.call(i.files) : (i.files[0] || null)); i.remove(); });
        i.addEventListener("cancel", function () { resolve(multiple ? [] : null); i.remove(); });
        // dentro lo shadow dell'editor: i listener che bloccano i click della pagina
        // (modalita' modifica) lo riconoscono come interfaccia e non annullano il selettore
        (SC.shadow || document.documentElement).appendChild(i);
        i.click();
    });
};

/* ------------------------------------------------------ CSS runtime persistito */
function cssMgr(doc) {
    var ID = "sc-runtime-styles";
    function node(create) {
        var s = doc.getElementById(ID);
        if (!s && create) { s = doc.createElement("style"); s.id = ID; (doc.head || doc.documentElement).appendChild(s); }
        return s;
    }
    function parse() {
        var s = node(false), map = {};
        if (!s) return map;
        var re = /\/\*sc:([^*]+?)\*\/([\s\S]*?)\/\*\/sc\*\//g, m, t = s.textContent;
        while ((m = re.exec(t))) map[m[1]] = m[2];
        return map;
    }
    function write(map) {
        var keys = Object.keys(map), s = node(keys.length > 0);
        if (!s) return;
        if (!keys.length) { s.remove(); return; }
        s.textContent = keys.map(function (k) { return "/*sc:" + k + "*/" + map[k] + "/*/sc*/"; }).join("\n");
    }
    return {
        get: function (k) { return parse()[k]; },
        has: function (k) { return k in parse(); },
        set: function (k, css) { var m = parse(); m[k] = css; write(m); },
        del: function (k) { var m = parse(); if (k in m) { delete m[k]; write(m); } },
        delMatch: function (re) { var m = parse(), ch = false; Object.keys(m).forEach(function (k) { if (re.test(k)) { delete m[k]; ch = true; } }); if (ch) write(m); },
        keys: function () { return Object.keys(parse()); }
    };
}
SC.cssMgr = cssMgr;
SC.css = cssMgr(document);

/* Regole d'oro: niente override di transform/animation/display/position del sito.
   - le animazioni usano le proprieta' individuali translate/rotate/scale (si sommano a transform)
   - gli effetti globali animano variabili registrate (@property) su <html>, gli elementi le leggono
   - le animazioni sui singoli elementi vengono accodate a quelle del sito (SC.setAnim) */
var FX_BASE = [
    "@property --sc-mq{syntax:'<length-percentage>';inherits:true;initial-value:0px}",
    "@property --sc-rot{syntax:'<angle>';inherits:true;initial-value:0deg}",
    "@property --sc-gx{syntax:'<length>';inherits:true;initial-value:0px}",
    "@keyframes sc-mqv{from{--sc-mq:100vw}to{--sc-mq:-100%}}",
    "@keyframes sc-rotv{to{--sc-rot:360deg}}",
    "@keyframes sc-gxv{0%{--sc-gx:2px}25%{--sc-gx:-2px}50%{--sc-gx:3px}75%{--sc-gx:-1px}100%{--sc-gx:2px}}",
    "@keyframes sc-panx{from{background-position-x:0}to{background-position-x:var(--sc-tile,600px)}}",
    "@keyframes sc-pany{from{background-position-y:0}to{background-position-y:var(--sc-tile,600px)}}",
    "@keyframes sc-gshift{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}",
    "@keyframes sc-zoom{0%{scale:1;clip-path:inset(0)}25%{scale:1.0625;clip-path:inset(2.941%)}50%{scale:1.125;clip-path:inset(5.556%)}75%{scale:1.1875;clip-path:inset(7.895%)}100%{scale:1.25;clip-path:inset(10%)}}",
    "@keyframes sc-hue{from{filter:brightness(var(--sc-b,1)) contrast(var(--sc-c,1)) hue-rotate(0deg)}to{filter:brightness(var(--sc-b,1)) contrast(var(--sc-c,1)) hue-rotate(360deg)}}",
    "@keyframes sc-pulse{0%,100%{scale:1}50%{scale:1.08}}",
    "@keyframes sc-shake{0%,100%{translate:0;rotate:0deg}25%{translate:-3px 0;rotate:-1deg}75%{translate:3px 0;rotate:1deg}}",
    "@keyframes sc-flicker{0%,19%,21%,23%,25%,54%,56%,100%{opacity:1}20%,24%,55%{opacity:.35}}",
    "@keyframes sc-bounce{0%,100%{translate:0 0}50%{translate:0 -8px}}",
    "@keyframes sc-rainbow{0%{background-position:0% 50%}100%{background-position:200% 50%}}",
    "@keyframes sc-glitch{0%{text-shadow:2px 0 red,-2px 0 cyan}20%{text-shadow:-2px 0 red,2px 0 cyan}40%{text-shadow:2px 2px red,-2px -2px cyan}60%{text-shadow:-2px 0 red,2px 0 cyan}100%{text-shadow:2px 0 red,-2px 0 cyan}}",
    "@keyframes sc-spin{to{rotate:360deg}}",
    ".sc-fx-neon{color:#fff!important;text-shadow:0 0 4px #fff,0 0 10px #0ff,0 0 20px #0ff,0 0 40px #0ff!important}",
    ".sc-fx-glow{text-shadow:0 0 8px currentColor,0 0 18px currentColor!important}",
    ".sc-fx-shadow3d{text-shadow:1px 1px 0 #999,2px 2px 0 #888,3px 3px 0 #777,4px 4px 0 #666,5px 5px 6px rgba(0,0,0,.5)!important}",
    ".sc-fx-fire{color:#fff!important;text-shadow:0 0 4px #fff,0 -2px 8px #ff0,0 -6px 14px #fd0,0 -10px 22px #f80,0 -16px 30px #f20!important}",
    ".sc-fx-rainbow{background-image:linear-gradient(90deg,#f00,#fa0,#0c0,#0cf,#60f,#f0c,#f00)!important;background-size:200% 100%!important;-webkit-background-clip:text!important;background-clip:text!important;color:transparent!important;-webkit-text-fill-color:transparent!important}",
    "[data-sc-rt-mirror]{scale:-1 1}",
    "[data-sc-rt-amq]{translate:var(--sc-mq) 0}",
    "[data-sc-rt-mq=\"b\"]{translate:var(--sc-mq) 0}",
    "[data-sc-rt-mq=\"i\"]{position:relative;left:var(--sc-mq)}"
].join("\n");
/* animazione (shorthand) di ogni effetto animato; null = effetto statico */
SC.fxAnim = { pulse: "sc-pulse 1.2s ease-in-out infinite", shake: "sc-shake .4s linear infinite", flicker: "sc-flicker 2s linear infinite",
              bounce: "sc-bounce .9s ease-in-out infinite", glitch: "sc-glitch .6s steps(2) infinite", spin: "sc-spin 3s linear infinite",
              rainbow: "sc-rainbow 3s linear infinite" };
/* Accoda le nostre animazioni a quelle gia' presenti sull'elemento (mai sostituirle). key: fx | mq | bg */
SC.setAnim = function (el, key, spec) {
    if (spec) el.setAttribute("data-sc-anim-" + key, spec); else el.removeAttribute("data-sc-anim-" + key);
    var base;
    if (el.hasAttribute("data-sc-anim0")) base = el.getAttribute("data-sc-anim0");
    else {
        el.style.removeProperty("animation");
        var cs = getComputedStyle(el);
        base = cs.animationName && cs.animationName !== "none" ? cs.animation : "";
    }
    var ours = ["fx", "mq", "bg"].map(function (k) { return el.getAttribute("data-sc-anim-" + k); }).filter(Boolean);
    el.style.removeProperty("animation");
    if (!ours.length) { el.removeAttribute("data-sc-anim0"); if (el.getAttribute("style") === "") el.removeAttribute("style"); return; }
    el.setAttribute("data-sc-anim0", base);
    el.style.setProperty("animation", [base].concat(ours).filter(Boolean).join(", "));
};
/* true se dare position:relative / transform all'elemento non sposta niente:
   gia' posizionato, oppure nessun discendente fisso/assoluto che oggi si appoggia a un antenato esterno */
SC.safeToPosition = function (el) {
    var cs = getComputedStyle(el);
    if (cs.position !== "static") return true;
    var all = el.getElementsByTagName("*");
    for (var i = 0; i < all.length && i < 4000; i++) {
        var p = getComputedStyle(all[i]).position;
        if (p === "fixed") return false;
        if (p === "absolute" && all[i].offsetParent && !el.contains(all[i].offsetParent)) return false;
    }
    return true;
};
/* come sopra, e in piu' nessun discendente fisso: un antenato con transform/translate
   farebbe scorrere via gli elementi position:fixed contenuti */
SC.safeToTransform = function (el) {
    var all = el.getElementsByTagName("*");
    for (var i = 0; i < all.length && i < 4000; i++) if (getComputedStyle(all[i]).position === "fixed") return false;
    return SC.safeToPosition(el);
};
/* pseudo-elemento libero (::after o ::before) che il sito non usa, oppure null */
SC.freePseudo = function (el) {
    function free(p) { var c = getComputedStyle(el, p).content; return !c || c === "none" || c === "normal"; }
    if (free("::after")) return "::after";
    if (free("::before")) return "::before";
    return null;
};
SC.fxList = ["neon", "glow", "shadow3d", "fire", "pulse", "shake", "flicker", "bounce", "glitch", "spin", "rainbow"];
SC.ensureFx = function (doc) { var m = cssMgr(doc || document); if (!m.has("fx-base")) m.set("fx-base", FX_BASE); };
/* toglie il blocco keyframes/effetti se nessuna regola lo usa piu' */
SC.gcFx = function (doc) {
    doc = doc || document;
    var m = cssMgr(doc);
    if (!m.has("fx-base")) return;
    var used = m.keys().some(function (k) { return k !== "fx-base" && /animation|sc-fx-|var\(--sc-|data-sc-rt/.test(m.get(k)); });
    if (!used && doc.querySelector('[class*="sc-fx-"],[data-sc-anim-fx],[data-sc-anim-mq],[data-sc-anim-bg]')) used = true;
    if (!used) m.del("fx-base");
};

/* id stabile per gli elementi toccati dall'editor (usato dai selettori CSS generati) */
SC.nextId = 1;
SC.initIds = function () {
    document.querySelectorAll("[data-sc-id]").forEach(function (e) { var n = parseInt(e.getAttribute("data-sc-id"), 10); if (n >= SC.nextId) SC.nextId = n + 1; });
};
SC.ensureId = function (el) {
    var id = el.getAttribute("data-sc-id");
    if (!id) { id = String(SC.nextId++); el.setAttribute("data-sc-id", id); }
    return id;
};
SC.sel_ = function (el) { return '[data-sc-id="' + SC.ensureId(el) + '"]'; };
SC.ruleKey = function (el, suffix) { return "e" + SC.ensureId(el) + "-" + suffix; };
SC.setRule = function (el, suffix, cssBody) { SC.ensureFx(); SC.css.set(SC.ruleKey(el, suffix), cssBody); };
SC.delRule = function (el, suffix) { SC.css.del(SC.ruleKey(el, suffix)); };

/* ------------------------------------------------------------- serializzazione */
/* Runtime salvato dentro le pagine: fa cio' che richiede il layout reale del browser
   (velocita' media, specchio e marquee calcolati elemento per elemento). Autosufficiente:
   viene serializzato con toString(), quindi non deve usare nulla fuori da se'. */
function scRuntime(doc) {
    var de = doc.documentElement, body = doc.body;
    if (!body) return;
    var act = (de.getAttribute("data-sc-patches") || "").split(/[\s,]+/);
    function on(id) { return act.indexOf(id) >= 0; }
    function clear(name) { doc.querySelectorAll("[data-sc-rt-" + name + "]").forEach(function (e) { e.removeAttribute("data-sc-rt-" + name); }); }
    function skip(e) { return /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|LINK|META|BR)$/.test(e.tagName) || !!e.closest("[data-sc-ui]") || !!e.closest("svg"); }
    function ownText(e) { for (var n = e.firstChild; n; n = n.nextSibling) if (n.nodeType === 3 && /\S/.test(n.nodeValue)) return true; return false; }
    function hasFixed(e) { var a = e.getElementsByTagName("*"); for (var i = 0; i < a.length && i < 5000; i++) if (getComputedStyle(a[i]).position === "fixed") return true; return false; }
    function safe(e) {
        if (getComputedStyle(e).position !== "static") return true;
        var a = e.getElementsByTagName("*");
        for (var i = 0; i < a.length && i < 5000; i++) {
            var p = getComputedStyle(a[i]).position;
            if (p === "fixed") return false;
            if (p === "absolute" && a[i].offsetParent && !e.contains(a[i].offsetParent)) return false;
        }
        return true;
    }
    doc.querySelectorAll("[data-sc-speed]").forEach(function (m) {
        var s = parseFloat(m.getAttribute("data-sc-speed")) || 1;
        m.defaultPlaybackRate = s; m.playbackRate = s;
        if (!m.__scSpeed) { m.__scSpeed = 1; m.addEventListener("loadedmetadata", function () { m.playbackRate = parseFloat(m.getAttribute("data-sc-speed")) || 1; }); }
    });
    /* marca i blocchi piu' esterni che si possono trasformare senza rompere nulla:
       niente discendenti fissi (un antenato trasformato li farebbe scorrere via) e nessun figlio
       assoluto appoggiato a un antenato esterno. Gli elementi fissi vengono marcati singolarmente. */
    function tagBlocks(attr) {
        var go = function (e) {
            if (skip(e)) return;
            var cs = getComputedStyle(e);
            if (cs.display === "none") return;
            if (cs.position === "fixed") { e.setAttribute(attr, "1"); return; }
            if (cs.display !== "inline" && cs.display !== "contents" && !hasFixed(e) && safe(e)) { e.setAttribute(attr, "1"); return; }
            for (var c = e.firstElementChild; c; c = c.nextElementSibling) go(c);
        };
        for (var c = body.firstElementChild; c; c = c.nextElementSibling) go(c);
    }
    /* bottoni: popup (<dialog>), avviso e chiusura. Delegato su document, registrato una volta. */
    if (!doc.__scRtClick) {
        doc.__scRtClick = true;
        doc.addEventListener("click", function (e) {
            var t = e.target;
            if (t && t.tagName === "DIALOG" && t.classList.contains("sc-popup")) { if (t.close) t.close(); else t.removeAttribute("open"); return; }
            t = t && t.closest ? t.closest("[data-sc-popup],[data-sc-alert],[data-sc-close]") : null;
            if (!t) return;
            if (t.hasAttribute("data-sc-alert")) { e.preventDefault(); alert(t.getAttribute("data-sc-alert")); return; }
            if (t.hasAttribute("data-sc-popup")) {
                e.preventDefault();
                var d = doc.getElementById(t.getAttribute("data-sc-popup"));
                if (d) { if (d.showModal) d.showModal(); else d.setAttribute("open", ""); }
                return;
            }
            var dl = t.closest("dialog");
            if (dl) { if (dl.close) dl.close(); else dl.removeAttribute("open"); }
        });
    }
    clear("mirror");
    if (on("mirror")) tagBlocks("data-sc-rt-mirror");
    clear("amq");
    if (on("allmq")) tagBlocks("data-sc-rt-amq");
    clear("mq");
    if (on("txtmq")) {
        var all = body.getElementsByTagName("*");
        for (var i = 0; i < all.length; i++) {
            var e = all[i];
            if (skip(e) || !ownText(e)) continue;
            if (e.parentElement && e.parentElement.closest("[data-sc-rt-mq]")) continue;
            var cs2 = getComputedStyle(e);
            if (cs2.display === "none" || cs2.display === "contents") continue;
            if (cs2.display === "inline") { if (cs2.position === "static" && safe(e)) e.setAttribute("data-sc-rt-mq", "i"); }
            else if (!hasFixed(e) && safe(e)) e.setAttribute("data-sc-rt-mq", "b");
        }
    }
}
SC.runtime = function (doc) { try { scRuntime(doc || document); } catch (e) { console.error(e); } };
SC.runtimeJs = "(function(){var f=" + scRuntime.toString() + ";function go(){try{f(document);}catch(e){}}" +
    "if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',go);else go();window.addEventListener('load',go);})();";
SC.runtimeNeeded = function (root) {
    if (root.querySelector("[data-sc-speed],[data-sc-popup],[data-sc-alert]")) return true;
    var p = (root.getAttribute("data-sc-patches") || "").split(/[\s,]+/);
    return p.indexOf("mirror") >= 0 || p.indexOf("txtmq") >= 0 || p.indexOf("allmq") >= 0;
};
SC.serializeDoc = function (doc) {
    var root = doc.documentElement.cloneNode(true);
    root.querySelectorAll("[data-sc-ui], #sc-editor-style").forEach(function (n) { n.remove(); });
    root.classList.remove("sc-on", "sc-bar", "sc-barb", "sc-panel-left");
    if (!root.getAttribute("class")) root.removeAttribute("class");
    root.querySelectorAll("[data-sc-editing]").forEach(function (n) { n.removeAttribute("contenteditable"); n.removeAttribute("data-sc-editing"); });
    root.querySelectorAll("dialog.sc-popup[open]").forEach(function (d) { d.removeAttribute("open"); });
    /* i marcatori calcolati a runtime non si salvano: li ricalcola il runtime all'apertura */
    root.querySelectorAll("[data-sc-rt-mirror],[data-sc-rt-mq],[data-sc-rt-amq]").forEach(function (n) { n.removeAttribute("data-sc-rt-mirror"); n.removeAttribute("data-sc-rt-mq"); n.removeAttribute("data-sc-rt-amq"); });
    var rt = root.querySelector("script#sc-runtime");
    if (SC.runtimeNeeded(root)) {
        if (!rt) { rt = doc.createElement("script"); rt.id = "sc-runtime"; (root.querySelector("body") || root).appendChild(rt); }
        rt.textContent = SC.runtimeJs;
    } else if (rt) rt.remove();
    var dt = doc.doctype ? new XMLSerializer().serializeToString(doc.doctype) : "<!DOCTYPE html>";
    return dt + "\n" + root.outerHTML;
};
SC.serialize = function () { return SC.serializeDoc(document); };
SC.cleanHtml = function () { // versione senza toolbar, per l'export pulito
    var html = SC.serialize();
    var d = new DOMParser().parseFromString(html, "text/html");
    d.querySelectorAll("script[data-sitecloner-editor]").forEach(function (n) { n.remove(); });
    return SC.serializeDoc(d);
};

/* --------------------------------------------------------------- undo / redo */
SC.snapshot = function () {
    var de = document.documentElement, s = document.getElementById("sc-runtime-styles");
    return { body: document.body.innerHTML, css: s ? s.textContent : null,
             style: de.getAttribute("style"), patches: de.getAttribute("data-sc-patches"), fu: de.getAttribute("data-sc-fu") };
};
SC.applySnapshot = function (s) {
    SC.stopTextEdit(true);
    document.body.innerHTML = s.body;
    var de = document.documentElement;
    function at(n, v) { if (v == null) de.removeAttribute(n); else de.setAttribute(n, v); }
    at("style", s.style); at("data-sc-patches", s.patches); at("data-sc-fu", s.fu);
    var st = document.getElementById("sc-runtime-styles");
    if (s.css == null) { if (st) st.remove(); }
    else { if (!st) { st = document.createElement("style"); st.id = "sc-runtime-styles"; document.head.appendChild(st); } st.textContent = s.css; }
    SC.deselect();
};
SC.sameSnap = function (a, b) { return a && b && a.body === b.body && a.css === b.css && a.style === b.style && a.patches === b.patches && a.fu === b.fu; };
SC.initHistory = function () { SC.history = [SC.snapshot()]; SC.future = []; SC.refreshHistoryUI(); };
SC.commit = function (label) {
    SC.gcFx();
    var s = SC.snapshot();
    if (SC.sameSnap(s, SC.history[SC.history.length - 1])) return;
    s.label = label || "";
    SC.history.push(s);
    if (SC.history.length > 40) SC.history.shift();
    SC.future = [];
    SC.markDirty();
    SC.refreshHistoryUI();
    SC.updateOverlay();
};
SC.undo = function () {
    if (SC.history.length < 2) return;
    SC.future.push(SC.history.pop());
    SC.applySnapshot(SC.history[SC.history.length - 1]);
    SC.markDirty(); SC.refreshHistoryUI();
};
SC.redo = function () {
    if (!SC.future.length) return;
    var s = SC.future.pop();
    SC.history.push(s);
    SC.applySnapshot(s);
    SC.markDirty(); SC.refreshHistoryUI();
};

/* ------------------------------------------------ salvataggio e bozza locale */
var AUTOSAVE_KEY = "sc2::" + location.pathname;
SC.markDirty = function () {
    SC.dirty = true;
    SC.updateTitleState();
    SC.autosave();
};
SC.autosave = debounce(function () {
    try { localStorage.setItem(AUTOSAVE_KEY, SC.serialize()); } catch (e) { /* quota */ }
}, 1200);
SC.clearAutosave = function () {
    if (SC.autosave.cancel) SC.autosave.cancel(); // una bozza ancora in coda non deve riapparire dopo il salvataggio
    try { localStorage.removeItem(AUTOSAVE_KEY); } catch (e) {}
};
SC.save = async function (quiet) {
    SC.stopTextEdit();
    var html = SC.serialize();
    if (SC.server) {
        try {
            var r = await SC.api("save-page", { json: { path: SC.pagePath(), html: html } });
            SC.dirty = false; SC.clearAutosave(); SC.updateTitleState();
            if (r.backup === false) SC.toast("Pagina salvata, ma non e' stato possibile creare il backup", "warn");
            else if (!quiet) SC.toast("Pagina salvata su disco (" + Math.round(r.bytes / 1024) + " KB) - backup creato", "ok");
        } catch (e) { SC.toast("Salvataggio fallito: " + e.message, "err"); }
        return;
    }
    SC.download(html);
};
SC.download = function (html) {
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([html], { type: "text/html" }));
    a.download = decodeURIComponent(location.pathname.split("/").pop() || "pagina.html");
    document.body.appendChild(a); a.click(); a.remove();
    SC.toast("Server non attivo: scaricata una copia della pagina, sovrascrivi a mano l'originale", "warn");
};

/* applica a tutte le pagine .html del sito (la corrente in-place, le altre via server) */
/* Applica fn a TUTTE le pagine .html del sito: le altre via server (4 alla volta), la corrente
   dal vivo; poi salva anche la corrente. fn(doc) puo' restituire un numero (es. sostituzioni). */
SC.siteWide = async function (fn, label) {
    if (!SC.needServer("Applicare a tutto il sito")) return false;
    if (SC.busy) { SC.toast("Un'operazione su tutto il sito e' gia' in corso", "warn"); return false; }
    var list;
    try { list = (await SC.api("files", { query: { ext: "html,htm,xhtml" } })).files; }
    catch (e) { SC.toast(e.message, "err"); return false; }
    var cur = SC.pagePath();
    var others = list.filter(function (f) { return f.path !== cur; });
    var done = 0, ok = 0, total = 0, errors = [];
    SC.busy = true;
    var prevStatus = SC.statusEl ? SC.statusEl.textContent : "";
    function progress() { SC.setStatus((label || "Operazione") + ": " + done + "/" + others.length + " pagine..."); }
    async function one(f) {
        try {
            var txt = (await SC.api("file", { query: { path: f.path } })).content;
            var d = new DOMParser().parseFromString(txt, "text/html");
            d.__scPath = f.path;
            var n = fn(d);
            if (typeof n === "number") total += n;
            SC.gcFx(d);
            var r = await SC.api("save-page", { json: { path: f.path, html: SC.serializeDoc(d) } });
            if (r.backup === false) errors.push(f.path + ": salvata, ma backup non riuscito");
            ok++;
        } catch (e) { errors.push(f.path + ": " + e.message); }
        done++; progress();
    }
    progress();
    try {
        var queue = others.slice();
        var workers = [];
        for (var w = 0; w < Math.min(4, queue.length); w++) {
            workers.push((async function () { while (queue.length) await one(queue.shift()); })());
        }
        await Promise.all(workers);
        var nCur = fn(document);
        if (typeof nCur === "number") total += nCur;
        SC.commit(label || "Applicato al sito");
        await SC.save(true);
    } finally {
        SC.busy = false;
        SC.setStatus(prevStatus);
    }
    var msg = (label || "Operazione") + ": " + (ok + 1) + " pagine aggiornate e salvate" + (total ? " (" + total + " sostituzioni)" : "");
    if (errors.length) {
        msg += " - " + errors.length + " con problemi: " + errors.slice(0, 2).join(" | ") + (errors.length > 2 ? " ..." : "");
        console.warn("[SiteEditor] pagine con problemi:", errors);
    }
    SC.toast(msg, errors.length ? "warn" : "ok");
    return true;
};

/* ----------------------------------------------------------------- DOM utils */
SC.isUI = function (n) { return !!(n && n.closest && n.closest("[data-sc-ui]")); };
SC.textNodes = function (doc, filter) {
    var out = [], body = doc.body;
    if (!body) return out;
    var w = doc.createTreeWalker(body, NodeFilter.SHOW_TEXT, null);
    var n;
    while ((n = w.nextNode())) {
        var p = n.parentElement;
        if (!p) continue;
        if (/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|TEMPLATE|OPTION)$/.test(p.tagName)) continue;
        if (p.closest("[data-sc-ui]")) continue;
        if (p.closest("svg, math")) continue; // niente <span> HTML dentro SVG/MathML: sarebbe markup non valido
        if (!n.nodeValue.trim()) continue;
        if (filter && !filter(n)) continue;
        out.push(n);
    }
    return out;
};
SC.describe = function (el) {
    if (!el) return "";
    var s = el.tagName.toLowerCase();
    if (el.id) s += "#" + el.id;
    var c = (typeof el.className === "string" ? el.className : "").trim().split(/\s+/).filter(function (x) { return x && x.indexOf("sc-") !== 0; }).slice(0, 2);
    if (c.length) s += "." + c.join(".");
    return s;
};
SC.kindOf = function (el) {
    var t = el.tagName;
    if (t === "IMG" || t === "PICTURE" || t === "SVG" || t === "svg") return "image";
    if (t === "VIDEO") return "video";
    if (t === "AUDIO") return "audio";
    return "box";
};
SC.hasOwnText = function (el) {
    for (var i = 0; i < el.childNodes.length; i++) if (el.childNodes[i].nodeType === 3 && el.childNodes[i].nodeValue.trim()) return true;
    return false;
};
