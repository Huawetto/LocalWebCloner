/* ------------------------------------------------------------ costruttore di bottoni
   Azioni: pagina locale (scelta dall'elenco delle pagine del sito), link esterno,
   popup (<dialog> nativo con titolo, testo e bottoni propri), avviso semplice (alert).
   Il comportamento di popup/avviso e' nel runtime salvato nella pagina: funziona anche
   senza toolbar. La configurazione resta nel bottone (data-sc-btn) per poterlo rimodificare. */
var BTN_DEFAULT = {
    text: "Clicca qui", icon: "", iconPos: "left",
    action: "page", page: "", url: "https://", newTab: false, alertText: "Messaggio",
    style: { fontSize: 16, fontWeight: "600", font: "", uppercase: false, color: "#ffffff",
             bgMode: "solid", bg: "#2271b1", grad: null, borderW: 0, borderColor: "#1a5a8f", borderStyle: "solid",
             shape: "rounded", radius: 8, padX: 22, padY: 12, width: "auto", align: "", shadow: "soft",
             hoverBg: "", hoverColor: "", hoverEffect: "lift" },
    popup: { id: "", title: "Titolo del popup", body: "Scrivi qui il testo del popup.", bg: "#ffffff", color: "#222222",
             radius: 12, width: 480, buttons: [{ label: "Chiudi", action: "close", page: "", url: "", newTab: false, bg: "#2271b1", color: "#ffffff" }] }
};
function clone(o) { return JSON.parse(JSON.stringify(o)); }
function mergeCfg(c) {
    var d = clone(BTN_DEFAULT);
    if (c) {
        Object.keys(c).forEach(function (k) { if (k !== "style" && k !== "popup") d[k] = c[k]; });
        Object.keys(c.style || {}).forEach(function (k) { d.style[k] = c.style[k]; });
        Object.keys(c.popup || {}).forEach(function (k) { d.popup[k] = c.popup[k]; });
    }
    if (!d.style.grad) d.style.grad = grad.make("#2271b1", "#7b2ff7");
    return d;
}
var SHAPES = { rect: "0", rounded: null, pill: "999px", circle: "50%" };
SC.btnStyle = function (s) {
    var css = ["font:inherit", "appearance:none", "-webkit-appearance:none", "cursor:pointer", "text-align:center", "text-decoration:none",
               "line-height:1.2", "transition:background .2s ease,color .2s ease,translate .2s ease,scale .2s ease,filter .2s ease,box-shadow .2s ease",
               "font-size:" + s.fontSize + "px", "font-weight:" + s.fontWeight, "color:" + s.color, "padding:" + s.padY + "px " + s.padX + "px"];
    if (s.font) css.push("font-family:" + s.font);
    if (s.uppercase) css.push("text-transform:uppercase", "letter-spacing:.5px");
    if (s.shape === "circle") css.push("display:inline-flex", "align-items:center", "justify-content:center", "aspect-ratio:1/1", "padding:" + Math.max(s.padX, s.padY) + "px");
    else if (s.width === "full") css.push("display:block", "width:100%", "box-sizing:border-box");
    else if (s.align === "center") css.push("display:block", "width:fit-content", "margin-left:auto", "margin-right:auto");
    else if (s.align === "right") css.push("display:block", "width:fit-content", "margin-left:auto");
    else css.push("display:inline-block");
    css.push("background:" + (s.bgMode === "gradient" && s.grad ? grad.css(s.grad) : s.bgMode === "none" ? "transparent" : s.bg));
    css.push(s.borderW > 0 ? "border:" + s.borderW + "px " + s.borderStyle + " " + s.borderColor : "border:0");
    css.push("border-radius:" + (SHAPES[s.shape] == null ? s.radius + "px" : SHAPES[s.shape]));
    var glowColor = s.bgMode === "gradient" && s.grad ? s.grad.stops[0].c : s.bg;
    var sh = { none: "none", soft: "0 2px 6px rgba(0,0,0,.2)", strong: "0 6px 18px rgba(0,0,0,.35)", glow: "0 0 16px " + glowColor };
    css.push("box-shadow:" + (sh[s.shadow] || "none"));
    return css.join(";");
};
SC.btnHover = function (s) {
    var d = [];
    if (s.hoverBg) d.push("background:" + s.hoverBg + "!important");
    if (s.hoverColor) d.push("color:" + s.hoverColor + "!important");
    if (s.hoverEffect === "lift") d.push("translate:0 -2px");
    if (s.hoverEffect === "grow") d.push("scale:1.06");
    if (s.hoverEffect === "darken" || (!s.hoverBg && s.hoverEffect === "lift")) d.push("filter:brightness(.92)");
    return d.join(";");
};

function popupBtnHtmlStyle(b) {
    return "font:inherit;cursor:pointer;border:0;border-radius:6px;padding:9px 16px;text-decoration:none;display:inline-block;background:" + b.bg + ";color:" + b.color;
}
/* crea o aggiorna il <dialog> del popup */
SC.buildPopup = function (cfg) {
    var p = cfg.popup;
    if (!p.id) p.id = "sc-pop-" + Math.random().toString(36).slice(2, 9);
    var d = document.getElementById(p.id);
    if (!d) { d = document.createElement("dialog"); d.id = p.id; document.body.appendChild(d); }
    d.className = "sc-popup";
    d.removeAttribute("open");
    d.setAttribute("aria-labelledby", p.id + "-t");
    d.setAttribute("style", "border:0;padding:24px;max-width:min(" + p.width + "px,92vw);width:100%;box-sizing:border-box;border-radius:" + p.radius + "px;background:" + p.bg + ";color:" + p.color + ";box-shadow:0 12px 40px rgba(0,0,0,.35)");
    d.innerHTML = "";
    var t = document.createElement("h2"); t.id = p.id + "-t"; t.textContent = p.title; t.setAttribute("style", "margin:0 0 12px;font-size:1.4em;color:inherit");
    d.appendChild(t);
    String(p.body || "").split(/\n{2,}/).forEach(function (para) {
        var pe = document.createElement("p"); pe.setAttribute("style", "margin:0 0 12px;color:inherit;white-space:pre-line"); pe.textContent = para; d.appendChild(pe);
    });
    var row = document.createElement("div"); row.setAttribute("style", "display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end;margin-top:16px");
    (p.buttons || []).forEach(function (b) {
        var n;
        if (b.action === "page" || b.action === "url") {
            n = document.createElement("a");
            n.setAttribute("href", b.action === "page" ? (b.page ? SC.rel(b.page) : "#") : (b.url || "#"));
            if (b.newTab) { n.setAttribute("target", "_blank"); n.setAttribute("rel", "noopener"); }
        } else { n = document.createElement("button"); n.setAttribute("type", "button"); n.setAttribute("data-sc-close", ""); }
        n.textContent = b.label;
        n.setAttribute("style", popupBtnHtmlStyle(b));
        row.appendChild(n);
    });
    d.appendChild(row);
    SC.css.set("popup-base", ".sc-popup::backdrop{background:rgba(0,0,0,.55)}.sc-popup a,.sc-popup button{transition:filter .2s}.sc-popup a:hover,.sc-popup button:hover{filter:brightness(.9)}");
    return d;
};
function removePopupIfOrphan(id) {
    if (!id || document.querySelector('[data-sc-popup="' + id + '"]')) return;
    var d = document.getElementById(id);
    if (d && d.classList.contains("sc-popup")) d.remove();
    if (!document.querySelector(".sc-popup")) SC.css.del("popup-base");
}

/* crea o aggiorna il bottone nella pagina */
SC.buildButton = function (cfg, el) {
    var tag = (cfg.action === "page" || cfg.action === "url") ? "a" : "button";
    var oldPopup = el ? el.getAttribute("data-sc-popup") : null;
    if (!el || el.tagName.toLowerCase() !== tag) {
        var n = document.createElement(tag);
        if (el) {
            if (el.getAttribute("data-sc-id")) n.setAttribute("data-sc-id", el.getAttribute("data-sc-id"));
            if (el.id) n.id = el.id;
            el.replaceWith(n);
        }
        el = n;
    }
    ["href", "target", "rel", "type", "data-sc-popup", "data-sc-alert", "aria-haspopup"].forEach(function (a) { el.removeAttribute(a); });
    if (tag === "a") {
        el.setAttribute("href", cfg.action === "page" ? (cfg.page ? SC.rel(cfg.page) : "#") : (cfg.url || "#"));
        if (cfg.newTab) { el.setAttribute("target", "_blank"); el.setAttribute("rel", "noopener"); }
    } else {
        el.setAttribute("type", "button");
        if (cfg.action === "popup") { SC.buildPopup(cfg); el.setAttribute("data-sc-popup", cfg.popup.id); el.setAttribute("aria-haspopup", "dialog"); }
        if (cfg.action === "alert") el.setAttribute("data-sc-alert", cfg.alertText || "");
    }
    el.textContent = "";
    var label = document.createElement("span"); label.textContent = cfg.text;
    if (cfg.icon) {
        var ic = document.createElement("span"); ic.textContent = cfg.icon; ic.setAttribute("aria-hidden", "true");
        ic.setAttribute("style", cfg.iconPos === "right" ? "margin-left:.5em" : "margin-right:.5em");
        if (cfg.iconPos === "right") { el.appendChild(label); el.appendChild(ic); } else { el.appendChild(ic); el.appendChild(label); }
    } else el.appendChild(label);
    el.classList.add("sc-btn");
    el.setAttribute("style", SC.btnStyle(cfg.style));
    el.setAttribute("data-sc-btn", JSON.stringify(cfg));
    var S = SC.sel_(el);
    SC.setRule(el, "btnh", S + ":hover{" + SC.btnHover(cfg.style) + "}\n" + S + ":focus-visible{outline:2px solid currentColor;outline-offset:3px}");
    if (oldPopup && oldPopup !== el.getAttribute("data-sc-popup")) removePopupIfOrphan(oldPopup);
    SC.runtime(document);
    return el;
};

/* l'eliminazione di un bottone toglie anche il suo popup, se nessun altro lo usa */
var _origDelete = SC.deleteSel;
SC.deleteSel = function () {
    var el = SC.sel, pops = [];
    if (el) { if (el.getAttribute("data-sc-popup")) pops.push(el.getAttribute("data-sc-popup")); el.querySelectorAll("[data-sc-popup]").forEach(function (n) { pops.push(n.getAttribute("data-sc-popup")); }); }
    _origDelete();
    pops.forEach(removePopupIfOrphan);
};

/* ------------------------------------------------------------------ interfaccia */
SC.openButtonBuilder = async function (existing) {
    var cfg = mergeCfg(existing ? (function () { try { return JSON.parse(existing.getAttribute("data-sc-btn")); } catch (e) { return null; } })() : null);
    var pages = [];
    if (SC.server) { try { pages = (await SC.api("files", { query: { ext: "html,htm" } })).files.map(function (f) { return f.path; }).sort(); } catch (e) {} }
    if (!cfg.page && pages.length) cfg.page = pages[0];

    var preview = h("div", { style: "padding:28px 16px;background:#f4f5f7;border-radius:8px;text-align:center;min-height:120px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px" });
    var pvStyle = h("style", {});
    var form = h("div", { style: "flex:1;min-width:300px;overflow:auto;padding-right:8px" });
    function render() {
        preview.innerHTML = "";
        var tag = (cfg.action === "page" || cfg.action === "url") ? "a" : "button";
        var b = document.createElement(tag);
        b.className = "pv";
        if (cfg.icon && cfg.iconPos !== "right") b.appendChild(h("span", { text: cfg.icon, style: "margin-right:.5em" }));
        b.appendChild(h("span", { text: cfg.text }));
        if (cfg.icon && cfg.iconPos === "right") b.appendChild(h("span", { text: cfg.icon, style: "margin-left:.5em" }));
        b.setAttribute("style", SC.btnStyle(cfg.style) + ";font-family:" + (cfg.style.font || "system-ui,Segoe UI,Arial,sans-serif"));
        b.addEventListener("click", function (e) { e.preventDefault(); if (cfg.action === "popup") SC.toast("Anteprima: si aprirebbe il popup \"" + cfg.popup.title + "\"", "ok"); else if (cfg.action === "alert") SC.toast("Anteprima avviso: " + cfg.alertText, "ok"); else SC.toast("Anteprima: porterebbe a " + (cfg.action === "page" ? cfg.page : cfg.url), "ok"); });
        var wrap = h("div", { style: "width:100%" }, b);
        preview.appendChild(wrap);
        preview.appendChild(h("div", { class: "hint", style: "color:#666", text: "Anteprima (passa col mouse per vedere l'effetto hover)" }));
        pvStyle.textContent = ".pv:hover{" + SC.btnHover(cfg.style) + "}";
    }
    function field() { return ui.row.apply(null, arguments); } // tutti i controlli della riga, non solo il primo
    var s = cfg.style;
    function drawForm() {
        form.innerHTML = "";
        /* azione */
        var act = h("div", {});
        act.appendChild(field("Al click", ui.select([["page", "Apri una pagina del sito"], ["url", "Apri un link esterno"], ["popup", "Mostra un popup"], ["alert", "Mostra un avviso semplice"]], cfg.action, function (v) { cfg.action = v; drawForm(); render(); })));
        if (cfg.action === "page") {
            if (pages.length) {
                var filt = ui.text("", function (v) { Array.prototype.forEach.call(sel.options, function (o) { o.hidden = v && o.value.toLowerCase().indexOf(v.toLowerCase()) < 0; }); }, "filtra pagine...");
                var sel = ui.select(pages.map(function (p) { return [p, p.length > 70 ? "..." + p.slice(-68) : p]; }), cfg.page, function (v) { cfg.page = v; render(); });
                sel.size = Math.min(8, pages.length); sel.style.width = "100%";
                act.appendChild(field("Cerca", filt));
                act.appendChild(h("div", { class: "row" }, sel));
            } else act.appendChild(field("Pagina", ui.text(cfg.page, function (v) { cfg.page = v; }, "/www.sito.it/pagina/index.html")));
            act.appendChild(field("", ui.check("apri in una nuova scheda", cfg.newTab, function (v) { cfg.newTab = v; })));
        }
        if (cfg.action === "url") {
            act.appendChild(field("Indirizzo", ui.text(cfg.url, function (v) { cfg.url = v; render(); }, "https://...")));
            act.appendChild(field("", ui.check("apri in una nuova scheda", cfg.newTab, function (v) { cfg.newTab = v; })));
        }
        if (cfg.action === "alert") act.appendChild(field("Messaggio", ui.text(cfg.alertText, function (v) { cfg.alertText = v; })));
        if (cfg.action === "popup") {
            var p = cfg.popup;
            act.appendChild(field("Titolo", ui.text(p.title, function (v) { p.title = v; })));
            var body = h("textarea", { rows: 4 }); body.value = p.body; body.addEventListener("input", function () { p.body = body.value; });
            act.appendChild(h("div", {}, h("div", { class: "hint", text: "Testo (riga vuota = nuovo paragrafo)" }), body));
            act.appendChild(field("Colori", "sfondo", ui.color(p.bg, function (v) { p.bg = v; }), "testo", ui.color(p.color, function (v) { p.color = v; })));
            act.appendChild(field("Larghezza", ui.range(p.width, { min: 240, max: 900, step: 10 }, function (v) { p.width = v; })));
            act.appendChild(field("Angoli", ui.range(p.radius, { min: 0, max: 40 }, function (v) { p.radius = v; })));
            var bl = h("div", {});
            p.buttons.forEach(function (b, i) {
                var box = h("div", { style: "border:1px solid #2f363d;border-radius:5px;padding:6px;margin:6px 0" });
                box.appendChild(field("Bottone " + (i + 1), ui.text(b.label, function (v) { b.label = v; }), p.buttons.length > 1 ? ui.btn("x", function () { p.buttons.splice(i, 1); drawForm(); }, "sm danger") : null));
                box.appendChild(field("Azione", ui.select([["close", "Chiude il popup"], ["page", "Pagina del sito"], ["url", "Link esterno"]], b.action, function (v) { b.action = v; drawForm(); })));
                if (b.action === "page") box.appendChild(field("Pagina", pages.length ? ui.select(pages.map(function (x) { return [x, x.length > 50 ? "..." + x.slice(-48) : x]; }), b.page || pages[0], function (v) { b.page = v; }) : ui.text(b.page, function (v) { b.page = v; })));
                if (b.action === "page" && !b.page && pages.length) b.page = pages[0];
                if (b.action === "url") box.appendChild(field("Indirizzo", ui.text(b.url, function (v) { b.url = v; }, "https://...")));
                if (b.action !== "close") box.appendChild(field("", ui.check("nuova scheda", b.newTab, function (v) { b.newTab = v; })));
                box.appendChild(field("Colori", "sfondo", ui.color(b.bg, function (v) { b.bg = v; }), "testo", ui.color(b.color, function (v) { b.color = v; })));
                bl.appendChild(box);
            });
            bl.appendChild(ui.btn("+ bottone nel popup", function () { p.buttons.push({ label: "OK", action: "close", page: "", url: "", newTab: false, bg: "#444444", color: "#ffffff" }); drawForm(); }, "sm"));
            act.appendChild(ui.section("Bottoni del popup", bl, true));
        }
        form.appendChild(ui.section("Azione", act, true));

        /* testo */
        var tx = h("div", {});
        tx.appendChild(field("Testo", ui.text(cfg.text, function (v) { cfg.text = v; render(); })));
        tx.appendChild(field("Icona", ui.text(cfg.icon, function (v) { cfg.icon = v; render(); }, "es. -> oppure un'emoji"), ui.select([["left", "a sinistra"], ["right", "a destra"]], cfg.iconPos, function (v) { cfg.iconPos = v; render(); })));
        tx.appendChild(field("Dimensione", ui.range(s.fontSize, { min: 10, max: 48 }, function (v) { s.fontSize = v; render(); })));
        tx.appendChild(field("Peso", ui.select([["400", "normale"], ["600", "semi-grassetto"], ["700", "grassetto"], ["900", "nero"]], s.fontWeight, function (v) { s.fontWeight = v; render(); }),
            ui.check("MAIUSCOLO", s.uppercase, function (v) { s.uppercase = v; render(); })));
        tx.appendChild(field("Font", ui.select([["", "come il sito"], ["Arial, sans-serif", "Arial"], ["Georgia, serif", "Georgia"], ["'Trebuchet MS', sans-serif", "Trebuchet"], ["Verdana, sans-serif", "Verdana"], ["'Courier New', monospace", "Courier"], ["Impact, sans-serif", "Impact"], ["'Comic Sans MS', cursive", "Comic Sans"]], s.font, function (v) { s.font = v; render(); })));
        tx.appendChild(field("Colore testo", ui.color(s.color, function (v) { s.color = v; render(); })));
        form.appendChild(ui.section("Testo", tx, true));

        /* colori */
        var co = h("div", {}), gbox = h("div", {});
        co.appendChild(field("Sfondo", ui.select([["solid", "Colore"], ["gradient", "Gradient"], ["none", "Trasparente"]], s.bgMode, function (v) { s.bgMode = v; drawG(); render(); })));
        var solidRow = field("Colore", ui.color(s.bg, function (v) { s.bg = v; render(); }));
        co.appendChild(solidRow); co.appendChild(gbox);
        function drawG() { gbox.innerHTML = ""; solidRow.style.display = s.bgMode === "solid" ? "" : "none"; if (s.bgMode === "gradient") gbox.appendChild(grad.editor(s.grad, render)); }
        drawG();
        co.appendChild(field("Al passaggio", "sfondo", ui.color(s.hoverBg || s.bg, function (v) { s.hoverBg = v; render(); }), "testo", ui.color(s.hoverColor || s.color, function (v) { s.hoverColor = v; render(); }),
            ui.btn("auto", function () { s.hoverBg = ""; s.hoverColor = ""; drawForm(); render(); }, "sm")));
        form.appendChild(ui.section("Colori", co, true));

        /* forma */
        var fo = h("div", {});
        fo.appendChild(field("Forma", ui.select([["rect", "Rettangolo"], ["rounded", "Arrotondato"], ["pill", "Pillola"], ["circle", "Cerchio"]], s.shape, function (v) { s.shape = v; render(); })));
        fo.appendChild(field("Raggio", ui.range(s.radius, { min: 0, max: 40 }, function (v) { s.radius = v; render(); })));
        fo.appendChild(field("Spazio interno", "orizz.", ui.num(s.padX, { min: 0, max: 80, w: "56px" }, function (v) { s.padX = v; render(); }), "vert.", ui.num(s.padY, { min: 0, max: 60, w: "56px" }, function (v) { s.padY = v; render(); })));
        fo.appendChild(field("Larghezza", ui.select([["auto", "adatta al testo"], ["full", "tutta la riga"]], s.width, function (v) { s.width = v; render(); }),
            ui.select([["", "allineam. normale"], ["center", "centrato"], ["right", "a destra"]], s.align, function (v) { s.align = v; render(); })));
        fo.appendChild(field("Bordo", ui.num(s.borderW, { min: 0, max: 12, w: "50px" }, function (v) { s.borderW = v; render(); }), "px", ui.color(s.borderColor, function (v) { s.borderColor = v; render(); }),
            ui.select(["solid", "dashed", "dotted", "double"], s.borderStyle, function (v) { s.borderStyle = v; render(); })));
        fo.appendChild(field("Ombra", ui.select([["none", "nessuna"], ["soft", "leggera"], ["strong", "forte"], ["glow", "bagliore"]], s.shadow, function (v) { s.shadow = v; render(); })));
        fo.appendChild(field("Effetto hover", ui.select([["none", "nessuno"], ["lift", "si alza"], ["grow", "si ingrandisce"], ["darken", "si scurisce"]], s.hoverEffect, function (v) { s.hoverEffect = v; render(); })));
        form.appendChild(ui.section("Forma ed effetti", fo, true));
    }
    drawForm(); render();

    var close = function () { modal.remove(); };
    var apply = ui.btn(existing ? "Aggiorna bottone" : "Inserisci bottone", function () {
        if (cfg.action === "page" && !cfg.page) { SC.toast("Scegli una pagina", "warn"); return; }
        if (cfg.action === "url" && !/^(https?:|mailto:|tel:|#|\/)/i.test(cfg.url)) { SC.toast("Indirizzo non valido (deve iniziare con https://, mailto:, tel:, # o /)", "warn"); return; }
        if (!SC.editMode) SC.setEditMode(true);
        if (existing && existing.isConnected) {
            var el = SC.buildButton(cfg, existing);
            SC.commit("Bottone aggiornato"); SC.select(el);
        } else {
            var node = SC.buildButton(cfg, null);
            SC.insertAndSelect(node, INS.where);
        }
        close();
        SC.toast("Bottone " + (existing ? "aggiornato" : "inserito") + ": esci da 'Modifica' per provarlo", "ok");
    }, "primary");
    var modal = h("div", { class: "modal", "data-sc-ui": "1" }, h("div", { class: "box", style: "width:min(980px,96vw);height:min(86vh,820px)" },
        h("div", { class: "hd" }, h("b", { text: existing ? "Modifica bottone" : "Nuovo bottone" }), h("span", { style: "flex:1" }), ui.btn("Annulla", close), apply),
        h("div", { class: "bd", style: "display:flex;gap:16px;flex-wrap:wrap" }, form,
            h("div", { style: "flex:0 0 340px;max-width:100%" }, pvStyle, preview,
                ui.hint("Il bottone segue lo stile scelto qui; il popup usa una finestra di dialogo standard del browser e funziona anche senza la toolbar.")))));
    SC.shadow.appendChild(modal);
};
