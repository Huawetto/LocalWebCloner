/* ------------------------------------------------------- Tag editor + collegamenti */
var LINK_ATTRS = ["href", "src", "srcset", "action", "poster", "data", "data-src", "formaction", "cite", "background"];
var tagChanged = function (l) { SC.commit(l); SC.updateOverlay(); };

function localPages() {
    if (!SC.server) return Promise.resolve([]);
    return SC.api("files", { query: { ext: "html,htm" } }).then(function (r) { return r.files; }).catch(function () { return []; });
}

function linkRows(el, root) {
    var items = [];
    var nodes = [el].concat(Array.prototype.slice.call(el.querySelectorAll("*")).slice(0, 400));
    nodes.forEach(function (n) {
        LINK_ATTRS.forEach(function (a) { if (n.hasAttribute(a)) items.push({ n: n, a: a }); });
    });
    var box = h("div", {});
    if (!items.length) { box.appendChild(ui.hint("Nessun collegamento (href/src/action...) nell'elemento selezionato.")); return box; }
    if (items.length >= 150) box.appendChild(ui.hint("Mostrati i primi 150 collegamenti."));
    var pagesPromise = localPages();
    items.slice(0, 150).forEach(function (it) {
        var n = it.n, a = it.a;
        var inp = ui.text(n.getAttribute(a), function (v) { n.setAttribute(a, v); tagChanged("Collegamento " + a); });
        var row = h("div", { style: "border-bottom:1px solid #2a3138;padding:4px 0" },
            h("div", { class: "hint" }, h("b", { text: SC.describe(n) }), " " + a),
            h("div", { class: "row" }, inp));
        var ctr = h("div", { class: "row" });
        if (a === "href" && n.tagName === "A") {
            ctr.appendChild(ui.select([["", "target: stessa scheda"], ["_blank", "nuova scheda"]], n.getAttribute("target") || "", function (v) { if (v) n.setAttribute("target", v); else n.removeAttribute("target"); tagChanged("target"); }));
        }
        var sel = h("select", {}, h("option", { value: "", text: "-> pagina locale..." }));
        sel.addEventListener("change", function () {
            if (!sel.value) return;
            var rel = SC.rel(sel.value);
            n.setAttribute(a, rel); inp.value = rel; tagChanged("Collegamento a pagina locale"); sel.value = "";
        });
        pagesPromise.then(function (pages) { pages.forEach(function (p) { sel.appendChild(h("option", { value: p.path, text: p.path.slice(0, 70) })); }); });
        if (SC.server) ctr.appendChild(sel);
        ctr.appendChild(ui.btn("Apri", function () { try { window.open(new URL(n.getAttribute(a).split(/\s+/)[0], location.href).href, "_blank"); } catch (e) {} }, "sm"));
        row.appendChild(ctr);
        box.appendChild(row);
    });
    return box;
}

SC.addTab("tags", "Tag", function (root) {
    var el = SC.sel;
    if (!el) { root.appendChild(ui.hint("Seleziona un elemento (modalita' modifica attiva) per vedere e modificare i suoi tag, attributi e collegamenti.")); return; }
    root.appendChild(crumbs(el));

    /* nome tag */
    root.appendChild(ui.section("Tag", h("div", {},
        ui.row("Tag", ui.text(el.tagName.toLowerCase(), function () {}, "div"),
            ui.btn("Cambia tag", function (e) {
                var name = (e.target.previousSibling.value || "").trim().toLowerCase();
                if (!/^[a-z][a-z0-9-]*$/.test(name) || name === el.tagName.toLowerCase()) return;
                var n = document.createElement(name);
                Array.prototype.forEach.call(el.attributes, function (at) { try { n.setAttribute(at.name, at.value); } catch (er) {} });
                while (el.firstChild) n.appendChild(el.firstChild);
                el.replaceWith(n); SC.commit("Tag cambiato"); SC.select(n);
            }, "sm")),
        ui.row("ID", ui.text(el.id, function (v) { if (v) el.id = v; else el.removeAttribute("id"); tagChanged("id"); }))), true));

    /* classi */
    var cb = h("div", {});
    function drawClasses() {
        cb.innerHTML = "";
        var cls = (typeof el.className === "string" ? el.className : "").split(/\s+/).filter(Boolean);
        cls.forEach(function (c) {
            cb.appendChild(h("span", { class: "chip" }, c, h("b", { text: "x", onclick: function () { el.classList.remove(c); if (!el.getAttribute("class")) el.removeAttribute("class"); tagChanged("Classe rimossa"); drawClasses(); } })));
        });
        var ni = h("input", { type: "text", placeholder: "nuova classe + Invio" });
        ni.addEventListener("keydown", function (e) { if (e.key === "Enter" && ni.value.trim()) { ni.value.trim().split(/\s+/).forEach(function (c) { el.classList.add(c); }); tagChanged("Classe aggiunta"); drawClasses(); } });
        cb.appendChild(ni);
    }
    drawClasses();
    root.appendChild(ui.section("Classi", cb, true));

    /* attributi */
    var ab = h("div", {});
    function drawAttrs() {
        ab.innerHTML = "";
        Array.prototype.slice.call(el.attributes).forEach(function (at) {
            if (at.name === "class" || at.name === "id" || at.name.indexOf("data-sc-") === 0 || at.name === "contenteditable" && el.hasAttribute("data-sc-editing")) return;
            var v = ui.text(at.value, function (val) { el.setAttribute(at.name, val); tagChanged("Attributo " + at.name); });
            ab.appendChild(h("div", { class: "row" }, h("span", { class: "mono", style: "flex:0 0 100px", text: at.name }), v,
                ui.btn("x", function () { el.removeAttribute(at.name); tagChanged("Attributo rimosso"); drawAttrs(); }, "sm danger")));
        });
        var nn = h("input", { type: "text", placeholder: "nome", style: "width:100px" }), nv = h("input", { type: "text", placeholder: "valore", class: "grow" });
        ab.appendChild(h("div", { class: "row" }, nn, nv, ui.btn("+ aggiungi", function () {
            var n = nn.value.trim(); if (!/^[^\s"'<>\/=]+$/.test(n)) { SC.toast("Nome attributo non valido", "err"); return; }
            el.setAttribute(n, nv.value); tagChanged("Attributo aggiunto"); drawAttrs();
        }, "sm")));
        ab.appendChild(ui.hint("Gli attributi interni dell'editor (data-sc-*) sono nascosti."));
    }
    drawAttrs();
    root.appendChild(ui.section("Attributi", ab, true));

    /* collegamenti */
    root.appendChild(ui.section("Collegamenti ipertestuali e risorse (href, src...)", linkRows(el), true));
    if (el.tagName !== "A" && !el.closest("a") && el.textContent.trim()) {
        root.appendChild(ui.row("", ui.btn("Trasforma in link...", function () {
            var u = prompt("URL o percorso del collegamento:", "#"); if (u == null) return;
            var a = document.createElement("a"); a.setAttribute("href", u);
            el.parentNode.insertBefore(a, el); a.appendChild(el);
            SC.commit("Link aggiunto"); SC.select(a);
        }, "sm")));
    }

    /* html interno */
    var ta = h("textarea", { rows: 8, spellcheck: "false" });
    ta.value = el.innerHTML;
    root.appendChild(ui.section("HTML interno", h("div", {}, ta,
        h("div", { class: "row" }, ui.btn("Applica HTML", function () { el.innerHTML = ta.value; SC.commit("HTML modificato"); SC.updateOverlay(); }, "primary"),
            ui.btn("Copia outerHTML", function () { navigator.clipboard && navigator.clipboard.writeText(el.outerHTML); SC.toast("Copiato", "ok"); }, "sm"))), false));
}, 20);
