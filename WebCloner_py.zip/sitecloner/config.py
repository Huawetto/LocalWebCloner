"""
config.py
=========
Costanti, regex compilate, configurazione HTTP/UA e parametri di tuning del crawler.
Tutti i valori "magici" sono qui. Modificarli senza toccare la logica di crawling.
"""

from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Tuple, FrozenSet


# ---------------------------------------------------------------------------
# Configurazione del crawler (immutabile, costruita una volta sola)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CrawlerConfig:
    """Configurazione runtime del crawler. Passata esplicitamente, niente globali."""
    start_url: str
    output_dir: str
    max_depth: int = 3
    max_pages: int = 0                  # 0 = illimitato
    max_workers: int = 16               # thread paralleli per download/scan
    rewrite_workers: int = 0            # thread per riscrittura (0 = max_workers)
    request_timeout: int = 20
    rate_limit_delay: float = 0.0       # secondi fra richieste PER DOMAIN
    same_domain_only: bool = True
    include_subdomains: bool = True
    follow_external_assets: bool = True
    rewrite_links: bool = True
    parse_css_assets: bool = True
    parse_inline_styles: bool = True
    parse_js_urls: bool = True          # estrae URL statici dai file JS
    parse_sitemap: bool = True          # parsa sitemap.xml per scoprire URL
    download_fonts: bool = True
    download_media: bool = True
    download_documents: bool = True
    max_asset_size_mb: float = 0.0      # 0 = nessun limite; altrimenti HEAD pre-check
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/136.0.0.0 Safari/537.36"
    )
    accept_language: str = "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7"
    verify_tls: bool = True
    respect_robots: bool = False
    extract_metadata: bool = True
    skip_login_pages: bool = True        # salta pagine di login (non possono funzionare offline)
    skip_cms_endpoints: bool = True      # ignora wp-json, xmlrpc, oembed, feed, wp-admin...
    add_editor_toolbar: bool = False     # inietta la toolbar di editing GUI locale in ogni pagina
    log_level: str = "INFO"
    log_file: str | None = None
    ignored_url_patterns: Tuple[str, ...] = field(default_factory=tuple)
    # Circuit-breaker
    cb_error_threshold: int = 5         # errori consecutivi per aprire il CB
    cb_reset_timeout: float = 60.0      # secondi prima di half-open
    # Priorità queue: le pagine HTML hanno priorità più alta degli asset
    use_priority_queue: bool = True


# ---------------------------------------------------------------------------
# Estensioni classificate
# ---------------------------------------------------------------------------

HTML_EXTENSIONS: FrozenSet[str] = frozenset({
    ".html", ".htm", ".xhtml", ".php", ".asp", ".aspx", ".jsp", ".cfm", "",
})
CSS_EXTENSIONS: FrozenSet[str] = frozenset({".css"})
JS_EXTENSIONS: FrozenSet[str] = frozenset({".js", ".mjs", ".cjs"})
IMAGE_EXTENSIONS: FrozenSet[str] = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp", ".ico", ".avif",
    ".apng", ".tif", ".tiff",
})
FONT_EXTENSIONS: FrozenSet[str] = frozenset({
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
})
MEDIA_EXTENSIONS: FrozenSet[str] = frozenset({
    ".mp4", ".webm", ".ogv", ".mov", ".m4v",
    ".mp3", ".wav", ".ogg", ".m4a", ".flac",
})
DOCUMENT_EXTENSIONS: FrozenSet[str] = frozenset({
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".zip", ".rar", ".7z", ".tar", ".gz", ".csv", ".txt",
    ".json", ".xml", ".rss", ".atom", ".yaml", ".yml",
})
ASSET_EXTENSIONS: FrozenSet[str] = (
    CSS_EXTENSIONS | JS_EXTENSIONS | IMAGE_EXTENSIONS |
    FONT_EXTENSIONS | MEDIA_EXTENSIONS | DOCUMENT_EXTENSIONS
)


# ---------------------------------------------------------------------------
# Tag/attributi HTML da cui estrarre URL
# ---------------------------------------------------------------------------

HTML_URL_ATTRS: Tuple[Tuple[str, str], ...] = (
    ("a", "href"),
    ("area", "href"),
    ("link", "href"),
    ("base", "href"),
    ("script", "src"),
    ("img", "src"),
    ("img", "data-src"),
    ("img", "data-lazy-src"),
    ("img", "data-original"),
    ("img", "srcset"),
    ("source", "src"),
    ("source", "srcset"),
    ("source", "data-srcset"),
    ("picture", "srcset"),
    ("video", "src"),
    ("video", "poster"),
    ("audio", "src"),
    ("track", "src"),
    ("iframe", "src"),
    ("embed", "src"),
    ("object", "data"),
    ("form", "action"),
    ("input", "src"),
    ("meta", "content"),
    ("use", "href"),
    ("use", "xlink:href"),
    ("image", "href"),
    ("image", "xlink:href"),
)

SRCSET_ATTRS: FrozenSet[str] = frozenset({"srcset", "data-srcset", "imagesrcset"})

META_URL_KEYS: FrozenSet[str] = frozenset({
    "og:image", "og:image:url", "og:image:secure_url", "og:video", "og:audio",
    "twitter:image", "twitter:image:src", "twitter:player",
    "msapplication-tileimage", "thumbnail",
})


# ---------------------------------------------------------------------------
# Regex compilate
# ---------------------------------------------------------------------------

CSS_URL_RE = re.compile(
    r"""url\(\s*(?:(['"]) (?P<u1>.*?)\1|(?P<u2>[^)\s]+))\s*\)""",
    re.IGNORECASE | re.VERBOSE,
)

CSS_IMPORT_RE = re.compile(
    r"""@import\s+(?:url\()?\s*(?:(['"]) (?P<u1>.*?)\1|(?P<u2>[^)\s;]+))\s*\)?\s*(?:[^;]*)?;?""",
    re.IGNORECASE | re.VERBOSE,
)

# Estrazione URL statici da JS: stringhe che sembrano path/URL
# Cattura: '/api/something', "https://cdn.example.com/file.js", src: '/img/logo.png'
JS_URL_RE = re.compile(
    r"""(?:["'`])(?P<url>(?:https?://[^"'`\s]{8,}|/[a-zA-Z0-9_\-/][^"'`\s]{3,}))(?:["'`])""",
)

# Sitemap XML: tag <loc>URL</loc>
SITEMAP_LOC_RE = re.compile(r"<loc>\s*(https?://[^<\s]+)\s*</loc>", re.IGNORECASE)

EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")
PHONE_RE = re.compile(
    r"(?:\+?\d{1,3}[\s\-.])?(?:\(?\d{2,4}\)?[\s\-.])?[0-9]{3,4}[\s\-.]?[0-9]{3,4}[\s\-.]?[0-9]{0,4}"
)

SOCIAL_DOMAINS: FrozenSet[str] = frozenset({
    "facebook.com", "twitter.com", "x.com", "instagram.com", "linkedin.com",
    "youtube.com", "youtu.be", "tiktok.com", "pinterest.com", "reddit.com",
    "github.com", "telegram.org", "t.me", "whatsapp.com", "discord.com",
    "discord.gg", "vimeo.com", "snapchat.com", "threads.net", "mastodon.social",
})

IGNORED_SCHEMES: FrozenSet[str] = frozenset({
    "mailto", "tel", "javascript", "data", "about", "ftp", "ws", "wss",
    "chrome", "chrome-extension", "intent", "geo", "sms", "blob",
})

TRACKING_PARAMS: FrozenSet[str] = frozenset({
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "utm_id", "utm_name", "gclid", "fbclid", "msclkid", "mc_cid", "mc_eid",
    "yclid", "_ga", "_gl", "ref", "ref_src", "ref_url", "session", "sessionid",
    "phpsessid", "jsessionid",
})

MAX_PATH_LENGTH = 240
MAX_FILENAME_LENGTH = 180

# Priorità queue (più basso = più urgente)
PRIORITY_PAGE = 0    # Pagine HTML: processate per prime (scoprono più URL)
PRIORITY_CSS = 1     # CSS: processati subito dopo (asset critici)
PRIORITY_ASSET = 2   # Tutto il resto
