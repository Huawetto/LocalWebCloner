"""
crawler.py
==========
Orchestratore principale. Miglioramenti rispetto all'originale:

1. PriorityQueue: HTML (0) > CSS (1) > asset (2) — scopre URL più velocemente
2. Deduplica per content-hash effettivamente usata in _process_task
3. Fase di riscrittura multi-threaded (ThreadPoolExecutor)
4. Parsing sitemap.xml per seed aggiuntivi
5. Parsing URL statici da JS (regex conservativa)
6. HEAD pre-check per asset grandi (configurabile con max_asset_size_mb)
7. Rate-limit per-domain (fix in http_client) — nessuna modifica qui
8. Circuit-breaker integrato in http_client — nessuna modifica qui
9. Contatore _pending_html con weak-ref per evitare OOM su siti enormi
   (la soup viene rilasciata subito se rewrite_links=False)
"""

from __future__ import annotations
import os
import time
import queue
import hashlib
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import List, Set, Optional, Tuple
from urllib.parse import urlparse

import requests

from .config import (
    CrawlerConfig,
    SITEMAP_LOC_RE,
    JS_URL_RE,
    PRIORITY_PAGE,
    PRIORITY_CSS,
    PRIORITY_ASSET,
)
from .http_client import HttpClient
from .registry import UrlRegistry, UrlState
from .parsers import (
    extract_from_html,
    extract_from_css,
    HtmlExtractionResult,
)
from .rewriter import LinkRewriter
from .storage import Storage
from .editor_toolbar import TOOLBAR_JS
from .utils import (
    classify_url,
    ResourceKind,
    url_to_local_path,
    same_site,
    normalize_url,
    is_html_url,
    is_asset_url,
    looks_like_login_page,
    relative_path,
    sniff_binary,
    is_cms_internal_url,
)


log = logging.getLogger("sitecloner.crawler")


# ---------------------------------------------------------------------------
# Task in queue
# ---------------------------------------------------------------------------

@dataclass(frozen=True, order=True)
class CrawlTask:
    priority: int   # campo usato per ordinamento in PriorityQueue
    url: str
    depth: int
    is_page: bool

    @classmethod
    def page(cls, url: str, depth: int) -> "CrawlTask":
        return cls(priority=PRIORITY_PAGE, url=url, depth=depth, is_page=True)

    @classmethod
    def css(cls, url: str, depth: int) -> "CrawlTask":
        return cls(priority=PRIORITY_CSS, url=url, depth=depth, is_page=False)

    @classmethod
    def asset(cls, url: str, depth: int) -> "CrawlTask":
        return cls(priority=PRIORITY_ASSET, url=url, depth=depth, is_page=False)


# Sentinel per shutdown ordinato dei worker
_SHUTDOWN = CrawlTask(priority=999, url="__SHUTDOWN__", depth=-1, is_page=False)


# ---------------------------------------------------------------------------
# Container per fase di riscrittura
# ---------------------------------------------------------------------------

@dataclass
class PendingHtmlPage:
    final_url: str
    local_path: str
    extraction: HtmlExtractionResult


@dataclass
class PendingCssFile:
    final_url: str
    local_path: str
    text: str


# ---------------------------------------------------------------------------
# Crawler
# ---------------------------------------------------------------------------

class Crawler:
    """Orchestratore principale del cloning."""

    def __init__(self, cfg: CrawlerConfig) -> None:
        self.cfg = cfg
        self.http = HttpClient(cfg)
        self.registry = UrlRegistry()
        self.storage = Storage(cfg.output_dir)

        # Priority queue: tuple (priority, CrawlTask) — PriorityQueue è thread-safe
        if cfg.use_priority_queue:
            self.task_queue: queue.PriorityQueue = queue.PriorityQueue()
        else:
            # Compatibilità: usa FIFO normale
            self.task_queue = queue.Queue()  # type: ignore[assignment]

        self.start_netloc = urlparse(cfg.start_url).netloc.lower()

        # Fase di riscrittura
        self._pending_html: List[PendingHtmlPage] = []
        self._pending_css: List[PendingCssFile] = []
        self._pending_lock = threading.Lock()

        # Metadati aggregati
        self.emails: Set[str] = set()
        self.phones: Set[str] = set()
        self.social_links: Set[str] = set()
        self._meta_lock = threading.Lock()

        self._stop_event = threading.Event()
        self._start_url: Optional[str] = None
        self._start_retries = 0

        self._pages_downloaded = 0
        self._pages_counter_lock = threading.Lock()

        # Max asset size per HEAD pre-check
        self._max_asset_bytes = int(cfg.max_asset_size_mb * 1024 * 1024)

    # ------------------------------------------------------------------
    # API pubblica
    # ------------------------------------------------------------------

    def run(self) -> dict:
        start_time = time.time()
        start_url = normalize_url(self.cfg.start_url, self.cfg.start_url)
        if not start_url:
            raise ValueError(f"URL di partenza non valido: {self.cfg.start_url}")

        log.info("=" * 78)
        log.info("Avvio cloning di %s -> %s", start_url, self.cfg.output_dir)
        log.info(
            "Profondità max: %d | Workers: %d | Max pagine: %s | PriorityQueue: %s",
            self.cfg.max_depth, self.cfg.max_workers,
            self.cfg.max_pages or "illimitato",
            self.cfg.use_priority_queue,
        )
        log.info("=" * 78)

        self._start_url = start_url
        self._start_retries = 0
        self._bootstrap_extra_urls(start_url)

        if self.registry.mark_discovered(start_url):
            self._put(CrawlTask.page(start_url, 0))

        workers: List[threading.Thread] = []
        for i in range(self.cfg.max_workers):
            t = threading.Thread(
                target=self._worker_loop,
                args=(i,),
                name=f"worker-{i}",
                daemon=True,
            )
            t.start()
            workers.append(t)

        hb_stop = threading.Event()

        def _heartbeat() -> None:
            while not hb_stop.wait(10):
                st, seen = self.registry.snapshot()
                log.info(
                    "[...] in corso: %d in coda | %d richieste attive | visti %d | ok %d | errori %d | pagine HTML %d "
                    "(se e' fermo il sito risponde lentamente: timeout %ds per richiesta)",
                    self.task_queue.qsize(), max(0, st.get("in_progress", 0) - st.get("done", 0) - st.get("failed", 0)),
                    seen, st.get("done", 0), st.get("failed", 0), self._pages_downloaded, self.cfg.request_timeout,
                )

        threading.Thread(target=_heartbeat, name="heartbeat", daemon=True).start()

        try:
            self.task_queue.join()
        except KeyboardInterrupt:
            log.warning("Interruzione richiesta dall'utente. Shutdown...")
            self._stop_event.set()
        finally:
            hb_stop.set()

        for _ in workers:
            self._put(_SHUTDOWN)
        for t in workers:
            t.join(timeout=5)

        if self.cfg.rewrite_links:
            log.info("Riscrittura link (multi-threaded)...")
            self._rewrite_phase_parallel()

        self._save_metadata_files()
        self.http.close()

        elapsed = time.time() - start_time
        stats, total_urls = self.registry.snapshot()
        stats["elapsed_seconds"] = round(elapsed, 2)
        stats["total_urls_seen"] = total_urls
        stats["html_pages"] = self._pages_downloaded
        log.info("=" * 78)
        log.info(
            "Completato in %.2fs. URL visti: %d | OK: %d | Errori: %d | Skip: %d | %.2f MB",
            elapsed, total_urls,
            stats.get("done", 0), stats.get("failed", 0), stats.get("skipped", 0),
            stats.get("bytes_downloaded", 0) / (1024 * 1024),
        )
        log.info("=" * 78)
        return stats

    def _retry_start_page(self, task: CrawlTask) -> bool:
        """
        La pagina iniziale e' l'unica da cui parte tutto: se il sito ha un
        singhiozzo (timeout, 502...) la riproviamo fino a 4 volte con pausa
        crescente invece di abbandonare l'intero clone.
        """
        if task.url != self._start_url or self._start_retries >= 4 or self._stop_event.is_set():
            return False
        self._start_retries += 1
        wait = 5 * self._start_retries
        log.warning("Pagina iniziale non raggiunta: nuovo tentativo %d/4 fra %ds", self._start_retries, wait)
        self._stop_event.wait(wait)
        self.registry.release(task.url)
        self._put(task)
        return True

    def _put(self, task: CrawlTask) -> None:
        """Inserisce nella queue nella forma corretta (priorità o plain)."""
        if self.cfg.use_priority_queue:
            self.task_queue.put((task.priority, task))
        else:
            self.task_queue.put(task)

    def _get(self) -> CrawlTask:
        """Preleva dalla queue in modo uniforme."""
        item = self.task_queue.get()
        if self.cfg.use_priority_queue:
            _, task = item
            return task
        return item

    # ------------------------------------------------------------------
    # Worker loop
    # ------------------------------------------------------------------

    def _worker_loop(self, worker_id: int) -> None:
        log.debug("Worker %d avviato", worker_id)
        while not self._stop_event.is_set():
            try:
                task = self._get()
            except Exception:
                break

            try:
                if task is _SHUTDOWN or task.url == "__SHUTDOWN__":
                    break
                self._process_task(task)
            except Exception as exc:
                log.exception("Worker %d: errore non gestito su %s: %s", worker_id, task.url, exc)
                self.registry.mark_failed(task.url)
            finally:
                if task is not _SHUTDOWN and task.url != "__SHUTDOWN__":
                    self.task_queue.task_done()

        log.debug("Worker %d terminato", worker_id)

    # ------------------------------------------------------------------
    # Elaborazione singolo task
    # ------------------------------------------------------------------

    def _process_task(self, task: CrawlTask) -> None:
        if not self.registry.try_acquire(task.url):
            return

        if not self.http.can_fetch(task.url):
            log.info("robots.txt blocca: %s", task.url)
            self.registry.mark_skipped(task.url)
            return

        if task.is_page and self.cfg.max_pages > 0:
            with self._pages_counter_lock:
                if self._pages_downloaded >= self.cfg.max_pages:
                    self.registry.mark_skipped(task.url)
                    return

        # HEAD pre-check per asset grandi
        kind_hint = classify_url(task.url)
        if (
            not task.is_page
            and self._max_asset_bytes > 0
            and kind_hint in (ResourceKind.MEDIA, ResourceKind.DOCUMENT)
        ):
            if self.http.should_skip_large_asset(task.url, self._max_asset_bytes):
                self.registry.mark_skipped(task.url)
                return

        try:
            response = self.http.get(task.url, stream=False)
        except requests.RequestException as exc:
            log.warning("[GET ERR] %s: %s", task.url, exc.__class__.__name__)
            if self._retry_start_page(task):
                return
            self.registry.mark_failed(task.url)
            return

        if response.status_code >= 500 and self._retry_start_page(task):
            log.warning("[%d] pagina iniziale non disponibile, riprovo...", response.status_code)
            return

        final_url = normalize_url(response.url, response.url) or task.url
        if final_url != task.url:
            self.registry.set_final_url(task.url, final_url)
            if not self.registry.mark_discovered(final_url):
                self.registry.mark_done(task.url)
                return
            self.registry.try_acquire(final_url)

        if response.status_code >= 400:
            log.warning("[%d] %s", response.status_code, final_url)
            self.registry.mark_failed(final_url)
            if final_url != task.url:
                self.registry.mark_failed(task.url)
            return

        content_type = response.headers.get("Content-Type", "")
        kind = classify_url(final_url, content_type)

        # Rete di sicurezza: un URL accodato come "asset" (bypass dei limiti
        # di dominio/profondità/max_pages) che il server serve come HTML va
        # comunque sottoposto alle stesse regole delle pagine, altrimenti può
        # sfuggire al controllo di classify_url-per-estensione e innescare un
        # crawl illimitato di un sito esterno (vedi commento in
        # _enqueue_extracted).
        if kind == ResourceKind.HTML and not task.is_page:
            if self.cfg.same_domain_only and not same_site(
                final_url, self.cfg.start_url, self.cfg.include_subdomains
            ):
                self.registry.mark_skipped(final_url)
                return
            if self.cfg.max_pages > 0:
                with self._pages_counter_lock:
                    if self._pages_downloaded >= self.cfg.max_pages:
                        self.registry.mark_skipped(final_url)
                        return

        body = response.content
        size = len(body)

        # File binari spacciati per pagine (content-type o estensione
        # fuorvianti, es. download.php che serve un JPEG): non vanno mai al
        # parser HTML, e prendono l'estensione reale per aprirsi offline.
        sniffed_ext = ""
        if kind in (ResourceKind.HTML, ResourceKind.OTHER):
            sb = sniff_binary(body)
            if sb:
                kind, sniffed_ext = sb
                log.debug("[SNIFF] %s non e' HTML: trattato come %s", final_url, kind)

        # Pagine di login: nessun clone statico ha un backend in grado di
        # elaborare il submit (niente PHP/sessioni/database scaricati), quindi
        # il form non potrà mai autenticare offline. Le rileviamo a livello di
        # contenuto (non di URL: molti siti rinominano lo slug di login per
        # sicurezza) e le escludiamo dal clone: eventuali link che puntano a
        # una pagina esclusa vengono comunque riscritti come URL assoluti dal
        # LinkRewriter (fallback già esistente per le pagine non scaricate),
        # quindi cliccandoli l'utente verrà mandato al login reale online.
        if kind == ResourceKind.HTML and self.cfg.skip_login_pages and looks_like_login_page(body):
            log.info("[LOGIN-SKIP] %s (pagina di login, non funzionante offline)", final_url)
            self.registry.mark_skipped(final_url)
            if final_url != task.url:
                self.registry.mark_skipped(task.url)
            return

        # ----------------------------------------------------------------
        # Deduplica per content-hash (FIX: nell'originale seen_hash()
        # non veniva mai usata in _process_task)
        # ----------------------------------------------------------------
        content_hash = hashlib.sha1(body).hexdigest()
        if self.registry.seen_hash(content_hash):
            # Contenuto già salvato: aggiorna solo il mapping path
            # (potrebbe essere lo stesso file servito su URL diversi)
            existing_path = self.registry.get_path_by_hash(content_hash)
            local_path = url_to_local_path(final_url, self.cfg.output_dir, self.start_netloc, kind)
            if sniffed_ext and not local_path.lower().endswith(sniffed_ext):
                local_path += sniffed_ext
            self.registry.set_local_path(final_url, local_path)
            if final_url != task.url:
                self.registry.set_local_path(task.url, local_path)
            # Crea symlink o copia leggera (evita duplicare file grandi)
            if existing_path and existing_path != local_path:
                self.storage.link_or_copy(existing_path, local_path)
            self.registry.mark_done(final_url, bytes_size=0)  # 0: non ricontato
            log.debug("[DEDUP] %s (hash già visto)", final_url)
            return

        local_path = url_to_local_path(final_url, self.cfg.output_dir, self.start_netloc, kind)
        if sniffed_ext and not local_path.lower().endswith(sniffed_ext):
            local_path += sniffed_ext
        self.registry.set_local_path(final_url, local_path)
        if final_url != task.url:
            self.registry.set_local_path(task.url, local_path)

        if kind == ResourceKind.HTML:
            self._handle_html(final_url, body, local_path, task.depth)
            with self._pages_counter_lock:
                self._pages_downloaded += 1

        elif kind == ResourceKind.CSS:
            self._handle_css(final_url, body, local_path)

        elif kind == ResourceKind.JS and self.cfg.parse_js_urls:
            self._handle_js(final_url, body, local_path, task.depth)

        else:
            # Sitemap XML: parsa i <loc> per scoprire URL del sito
            if self.cfg.parse_sitemap and (
                "sitemap" in final_url.lower() or
                content_type.startswith("application/xml") or
                content_type.startswith("text/xml")
            ):
                self._parse_sitemap(body, final_url)

            if not self._should_save_kind(kind):
                self.registry.mark_skipped(final_url)
                return
            ok = self.storage.write_bytes(local_path, body)
            if ok:
                self.registry.mark_done(final_url, bytes_size=size)
                self.registry.add_hash(content_hash, local_path)
                log.info("[%s] %s (%d B)", kind.upper()[:5], final_url, size)
            else:
                self.registry.mark_failed(final_url)

    # ------------------------------------------------------------------
    # Handler specifici
    # ------------------------------------------------------------------

    def _handle_html(self, final_url: str, body: bytes, local_path: str, depth: int) -> None:
        try:
            extraction = extract_from_html(
                body,
                final_url,
                parse_inline_styles=self.cfg.parse_inline_styles,
                extract_metadata=self.cfg.extract_metadata,
            )
        except Exception as exc:
            log.error("Parsing HTML fallito per %s: %s", final_url, exc)
            self.storage.write_bytes(local_path, body)
            self.registry.mark_done(final_url, bytes_size=len(body))
            return

        if self.cfg.extract_metadata:
            with self._meta_lock:
                self.emails.update(extraction.emails)
                self.phones.update(extraction.phones)
                self.social_links.update(extraction.social_links)

        for eu in extraction.urls:
            self._enqueue_extracted(eu.url, depth)

        self.storage.write_bytes(local_path, body)
        self.registry.mark_done(final_url, bytes_size=len(body))
        content_hash = hashlib.sha1(body).hexdigest()
        self.registry.add_hash(content_hash, local_path)

        with self._pending_lock:
            self._pending_html.append(PendingHtmlPage(
                final_url=final_url,
                local_path=local_path,
                extraction=extraction,
            ))
        log.info("[HTML ] depth=%d %s (%d B)", depth, final_url, len(body))

    def _handle_css(self, final_url: str, body: bytes, local_path: str) -> None:
        try:
            css_text = body.decode("utf-8")
        except UnicodeDecodeError:
            try:
                css_text = body.decode("latin-1")
            except Exception:
                css_text = body.decode("utf-8", errors="replace")

        css_result = extract_from_css(css_text, final_url) if self.cfg.parse_css_assets else None

        self.storage.write_bytes(local_path, body)
        self.registry.mark_done(final_url, bytes_size=len(body))
        content_hash = hashlib.sha1(body).hexdigest()
        self.registry.add_hash(content_hash, local_path)
        log.info("[CSS  ] %s (%d B)", final_url, len(body))

        if css_result:
            for _raw, abs_url in css_result.urls:
                self._enqueue_extracted(abs_url, depth=0, force_asset=True)

            with self._pending_lock:
                self._pending_css.append(PendingCssFile(
                    final_url=final_url,
                    local_path=local_path,
                    text=css_text,
                ))

    def _handle_js(self, final_url: str, body: bytes, local_path: str, depth: int) -> None:
        """
        Salva il file JS ed estrae URL statici con una regex conservativa.
        Cattura solo URL che sembrano path di risorsa validi (non stringhe arbitrarie).
        """
        ok = self.storage.write_bytes(local_path, body)
        if ok:
            self.registry.mark_done(final_url, bytes_size=len(body))
            content_hash = hashlib.sha1(body).hexdigest()
            self.registry.add_hash(content_hash, local_path)
            log.info("[JS   ] %s (%d B)", final_url, len(body))
        else:
            self.registry.mark_failed(final_url)
            return

        if not self.cfg.parse_js_urls:
            return

        try:
            js_text = body.decode("utf-8", errors="replace")
        except Exception:
            return

        found = 0
        for m in JS_URL_RE.finditer(js_text):
            raw_url = m.group("url")
            if not raw_url:
                continue
            abs_url = normalize_url(raw_url, final_url)
            if abs_url:
                self._enqueue_extracted(abs_url, depth=depth, force_asset=True)
                found += 1
        if found:
            log.debug("[JS-URL] trovati %d URL statici in %s", found, final_url)

    def _parse_sitemap(self, body: bytes, base_url: str) -> None:
        """Parsa un sitemap XML (o sitemap index) ed accoda tutti gli <loc>."""
        try:
            text = body.decode("utf-8", errors="replace")
        except Exception:
            return
        found = 0
        for m in SITEMAP_LOC_RE.finditer(text):
            loc = m.group(1).strip()
            abs_url = normalize_url(loc, base_url)
            if abs_url:
                # I <loc> di un sitemap index puntano ad altri sitemap
                if "sitemap" in abs_url.lower() and abs_url.endswith(".xml"):
                    self._enqueue_extracted(abs_url, depth=0, force_asset=True)
                else:
                    self._enqueue_extracted(abs_url, depth=1, force_asset=False)
                found += 1
        if found:
            log.info("[SITEMAP] %d URL da %s", found, base_url)

    # ------------------------------------------------------------------
    # Logica di accodamento
    # ------------------------------------------------------------------

    def _enqueue_extracted(self, url: str, depth: int, force_asset: bool = False) -> None:
        if not url:
            return

        for pat in self.cfg.ignored_url_patterns:
            if pat and pat in url:
                return

        if self.cfg.skip_cms_endpoints and is_cms_internal_url(url):
            self.registry.mark_skipped(url)
            return

        if self.registry.is_known(url):
            return

        as_page = (not force_asset) and is_html_url(url) and not is_asset_url(url)
        internal = same_site(url, self.cfg.start_url, self.cfg.include_subdomains)

        if as_page:
            if not internal and self.cfg.same_domain_only:
                self.registry.mark_skipped(url)
                return
            if depth >= self.cfg.max_depth:
                self.registry.mark_skipped(url)
                return
            if not self.registry.mark_discovered(url):
                return
            self._put(CrawlTask.page(url, depth + 1))
        else:
            # FIX: un URL con estensione non riconosciuta come asset statico
            # (non css/js/immagine/font/media/documento) NON è detto che sia
            # davvero un asset: potrebbe essere una pagina HTML il cui path
            # termina per coincidenza in qualcosa che sembra un'estensione
            # (es. ".../licenses/.../deed.fr" su creativecommons.org, dove
            # "fr" è un codice lingua, non un'estensione). Se la trattiamo
            # come asset puro bypassa sia il limite di profondità sia quello
            # di dominio (entrambi applicati solo nel ramo "as_page" sopra),
            # e se il server risponde con Content-Type HTML il crawler finisce
            # per seguire un intero sito esterno senza alcun limite (riprodotto
            # dal vivo: un badge di licenza CC nel footer ha fatto scaricare
            # centinaia di pagine da creativecommons.org). Per gli URL che non
            # arrivano da un contesto di asset confermato (force_asset, cioè
            # CSS/JS/sitemap) applichiamo quindi le stesse regole di
            # dominio/profondità delle pagine normali.
            is_confirmed_asset = is_asset_url(url)
            if not is_confirmed_asset and not force_asset:
                if not internal and self.cfg.same_domain_only:
                    self.registry.mark_skipped(url)
                    return
                if depth >= self.cfg.max_depth:
                    self.registry.mark_skipped(url)
                    return
            elif not internal and not self.cfg.follow_external_assets:
                self.registry.mark_skipped(url)
                return

            if not self.registry.mark_discovered(url):
                return
            # CSS accodato con priorità più alta degli altri asset
            kind = classify_url(url)
            if kind == ResourceKind.CSS:
                self._put(CrawlTask.css(url, depth))
            else:
                self._put(CrawlTask.asset(url, depth))

    def _should_save_kind(self, kind: str) -> bool:
        if kind == ResourceKind.FONT and not self.cfg.download_fonts:
            return False
        if kind == ResourceKind.MEDIA and not self.cfg.download_media:
            return False
        if kind == ResourceKind.DOCUMENT and not self.cfg.download_documents:
            return False
        return True

    # ------------------------------------------------------------------
    # Bootstrap
    # ------------------------------------------------------------------

    def _bootstrap_extra_urls(self, start_url: str) -> None:
        parsed = urlparse(start_url)
        base = f"{parsed.scheme}://{parsed.netloc}"
        for path in ("/robots.txt", "/sitemap.xml", "/sitemap_index.xml"):
            self._enqueue_extracted(base + path, depth=0, force_asset=True)
        self._enqueue_extracted(base + "/favicon.ico", depth=0, force_asset=True)

    # ------------------------------------------------------------------
    # Riscrittura multi-threaded
    # ------------------------------------------------------------------

    def _rewrite_phase_parallel(self) -> None:
        """
        Riscrittura parallela con ThreadPoolExecutor.
        Originale: loop sequenziale su tutti i pending.
        Miglioramento: N worker concorrenti (I/O-bound su disco).
        """
        reconciled = self.registry.reconcile_redirects()
        if reconciled:
            log.info("Riconciliati %d redirect verso pagine già scaricate/scartate", reconciled)

        mappings = self.registry.all_mappings()
        rewriter = LinkRewriter(mappings)
        n_workers = self.cfg.rewrite_workers or self.cfg.max_workers

        html_pages = list(self._pending_html)
        css_files = list(self._pending_css)

        toolbar_js_path = None
        if self.cfg.add_editor_toolbar and html_pages:
            toolbar_js_path = os.path.join(self.cfg.output_dir, "_sitecloner_editor", "toolbar.js")
            self.storage.write_text(toolbar_js_path, TOOLBAR_JS)

        def _rewrite_html_page(page: PendingHtmlPage) -> Optional[str]:
            try:
                new_html = rewriter.rewrite_html(
                    page.extraction.soup,
                    page.final_url,
                    page.local_path,
                )
                if toolbar_js_path:
                    new_html = self._inject_editor_toolbar(new_html, page.local_path, toolbar_js_path)
                self.storage.write_text(page.local_path, new_html)
                return None
            except Exception as exc:
                return f"HTML {page.final_url}: {exc}"

        def _rewrite_css_file(css: PendingCssFile) -> Optional[str]:
            try:
                new_css = rewriter.rewrite_css(css.text, css.final_url, css.local_path)
                self.storage.write_text(css.local_path, new_css)
                return None
            except Exception as exc:
                return f"CSS {css.final_url}: {exc}"

        errors = 0
        with ThreadPoolExecutor(max_workers=n_workers, thread_name_prefix="rewrite") as pool:
            futures_html = {pool.submit(_rewrite_html_page, p): p for p in html_pages}
            futures_css = {pool.submit(_rewrite_css_file, c): c for c in css_files}
            all_futures = {**futures_html, **futures_css}

            for fut in as_completed(all_futures):
                err = fut.result()
                if err:
                    log.error("Riscrittura fallita: %s", err)
                    errors += 1

        log.info(
            "Riscrittura completata: %d HTML + %d CSS (errori: %d)",
            len(html_pages), len(css_files), errors,
        )

        try:
            self.storage.save_url_mapping(mappings)
        except Exception as exc:
            log.error("Salvataggio mapping fallito: %s", exc)

    # ------------------------------------------------------------------
    # Toolbar di editing locale (opzionale)
    # ------------------------------------------------------------------

    @staticmethod
    def _inject_editor_toolbar(html: str, local_path: str, toolbar_js_path: str) -> str:
        """
        Inserisce <script src="...toolbar.js"> prima di </body>. Fatto sulla
        stringa HTML già serializzata (non sul soup) per non farlo passare
        dal LinkRewriter: il path relativo è già corretto così com'è, e il
        rewriter lo riscriverebbe come URL assoluto non trovandolo nella
        mappa degli URL scaricati (è un asset locale nuovo, non scaricato
        da nessun sito).
        """
        rel = relative_path(local_path, toolbar_js_path)
        # charset="utf-8" esplicito: altrimenti, servito da file:// o da un
        # server statico generico senza header Content-Type corretto, il
        # browser può indovinare un charset sbagliato e mostrare le lettere
        # accentate/emoji della toolbar come testo corrotto.
        tag = (
            f'<script src="{rel}" charset="utf-8" defer="defer" '
            f'data-sitecloner-editor="1"></script>'
        )
        if "</body>" in html:
            return html.replace("</body>", tag + "</body>", 1)
        return html + tag

    # ------------------------------------------------------------------
    # Metadati su file
    # ------------------------------------------------------------------

    def _save_metadata_files(self) -> None:
        if not self.cfg.extract_metadata:
            return
        if self.emails:
            self.storage.save_text_list(list(self.emails), "00_emails.txt")
            log.info("Salvate %d email", len(self.emails))
        if self.phones:
            self.storage.save_text_list(list(self.phones), "00_phones.txt")
            log.info("Salvati %d numeri di telefono", len(self.phones))
        if self.social_links:
            self.storage.save_text_list(list(self.social_links), "00_social_links.txt")
            log.info("Salvati %d link social", len(self.social_links))
