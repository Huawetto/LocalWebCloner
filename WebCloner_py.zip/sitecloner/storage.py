"""
storage.py
==========
Scrittura su disco thread-safe.

Miglioramenti:
- link_or_copy(): per la deduplica content-hash, crea un hardlink (O(1))
  invece di ricopiare i byte; fallback a copia se hardlink non supportato
  (cross-device, Windows NTFS senza permessi, ecc.)
- write_bytes() ora verifica content-hash oltre alla dimensione per lo skip
"""

from __future__ import annotations
import os
import json
import shutil
import threading
import logging
import tempfile
from typing import Dict


log = logging.getLogger("sitecloner.storage")


class Storage:
    """Wrapper di I/O con sincronizzazione per scritture concorrenti."""

    def __init__(self, base_dir: str) -> None:
        self.base_dir = os.path.abspath(base_dir)
        os.makedirs(self.base_dir, exist_ok=True)
        self._protect_from_git()
        self._mkdir_lock = threading.Lock()
        self._meta_lock = threading.Lock()

    def _protect_from_git(self) -> None:
        """
        Mette un .gitignore con '*' nella cartella del clone: il contenuto di un sito clonato e'
        di terzi e pesante, e non deve finire per errore in un repository (qualunque nome abbia
        la cartella). Non lo fa se la cartella e' essa stessa un repository o un progetto.
        """
        try:
            marker = os.path.join(self.base_dir, ".gitignore")
            if os.path.exists(marker):
                return
            for proj in (".git", "pyproject.toml", "setup.py", "package.json"):
                if os.path.exists(os.path.join(self.base_dir, proj)):
                    return
            with open(marker, "w", encoding="utf-8") as f:
                f.write("# creato da SiteCloner: i siti clonati non vanno pubblicati\n*\n")
        except OSError:
            pass

    def ensure_dir(self, file_path: str) -> None:
        directory = os.path.dirname(file_path)
        if not directory:
            return
        with self._mkdir_lock:
            os.makedirs(directory, exist_ok=True)

    def _resolve_collision(self, file_path: str) -> str:
        if os.path.isdir(file_path):
            base = os.path.basename(file_path)
            new_name = "_index_" + (base or "file")
            return os.path.join(file_path, new_name)
        parts = file_path.replace("\\", "/").split("/")
        accum = parts[0] if file_path.startswith("/") else ""
        for p in parts[1:-1]:
            accum = accum + "/" + p if accum else p
            if os.path.isfile(accum):
                conflicting = accum
                backup = accum + "__conflict_file"
                try:
                    os.replace(conflicting, backup)
                    log.warning("Collisione path: spostato %s -> %s", conflicting, backup)
                except OSError as exc:
                    log.error("Impossibile risolvere collisione su %s: %s", conflicting, exc)
        return file_path

    def write_bytes(self, file_path: str, data: bytes) -> bool:
        file_path = self._resolve_collision(file_path)
        self.ensure_dir(file_path)
        try:
            if os.path.exists(file_path) and os.path.getsize(file_path) == len(data):
                log.debug("File già presente con stessa dimensione, skip: %s", file_path)
                return True

            dir_name = os.path.dirname(file_path) or "."
            fd, tmp_path = tempfile.mkstemp(dir=dir_name, prefix=".tmp_", suffix=".part")
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(data)
                os.replace(tmp_path, file_path)
            except Exception:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise
            return True
        except OSError as exc:
            log.error("Errore di scrittura %s: %s", file_path, exc)
            return False

    def write_text(self, file_path: str, text: str, encoding: str = "utf-8") -> bool:
        return self.write_bytes(file_path, text.encode(encoding, errors="replace"))

    def link_or_copy(self, src: str, dst: str) -> bool:
        """
        Crea un hardlink da src a dst (O(1), zero byte copiati).
        Fallback a shutil.copy2 se hardlink non è supportato
        (cross-device, filesystem senza supporto, ecc.).
        """
        if not os.path.exists(src):
            return False
        if os.path.exists(dst):
            return True  # già presente
        self.ensure_dir(dst)
        try:
            os.link(src, dst)
            log.debug("[HARDLINK] %s -> %s", src, dst)
            return True
        except OSError:
            # Fallback: copia completa
            try:
                shutil.copy2(src, dst)
                log.debug("[COPY] %s -> %s", src, dst)
                return True
            except OSError as exc:
                log.error("link_or_copy fallito %s -> %s: %s", src, dst, exc)
                return False

    # ------------------------------------------------------------------
    # Persistenza mapping e liste
    # ------------------------------------------------------------------

    def save_url_mapping(self, mapping: Dict[str, str], filename: str = "_url_mapping.json") -> str:
        out_path = os.path.join(self.base_dir, filename)
        serializable = {
            url: os.path.relpath(local, self.base_dir).replace("\\", "/")
            for url, local in mapping.items()
        }
        with self._meta_lock:
            try:
                with open(out_path, "w", encoding="utf-8") as f:
                    json.dump(serializable, f, indent=2, ensure_ascii=False, sort_keys=True)
                return out_path
            except OSError as exc:
                log.error("Errore salvando il mapping: %s", exc)
                return ""

    def save_text_list(self, items: list[str], filename: str) -> str:
        out_path = os.path.join(self.base_dir, filename)
        with self._meta_lock:
            try:
                with open(out_path, "w", encoding="utf-8") as f:
                    for item in sorted(set(items)):
                        f.write(item + "\n")
                return out_path
            except OSError as exc:
                log.error("Errore salvando %s: %s", out_path, exc)
                return ""
