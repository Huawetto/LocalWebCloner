"""
sitecloner
==========
Cloning completo di siti web per fruizione offline.
"""

from .config import CrawlerConfig
from .crawler import Crawler
from .logging_setup import setup_logging

__all__ = ["CrawlerConfig", "Crawler", "setup_logging"]
__version__ = "2.1.0"
