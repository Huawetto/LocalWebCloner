"""
http_client.py
==============
Wrapper attorno a requests.Session con:
- retry esponenziale su errori transitori (429/5xx)
- pooling connection + keep-alive
- rate-limit PER-DOMAIN (non globale): non serializza i worker su un unico lock
- circuit-breaker per-domain: dopo N errori consecutivi il domain viene sospeso
- HEAD pre-check configurabile per asset pesanti
- User-Agent professionale
- supporto robots.txt opzionale con cache asincrona
- gestione redirect e timeout
"""

from __future__ import annotations
import time
import threading
import logging
from collections import defaultdict
from typing import Optional, Dict, Set
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import CrawlerConfig


log = logging.getLogger("sitecloner.http")


# ---------------------------------------------------------------------------
# Rate-limiter PER-DOMAIN (fix critico: la versione originale serializza tutti
# i worker su un unico lock, annullando il parallelismo)
# ---------------------------------------------------------------------------

class PerDomainRateLimiter:
    """
    Limita il throughput per singolo domain a `delay` secondi fra request
    consecutive sullo stesso host. Worker su host diversi non si bloccano.
    """

    def __init__(self, delay: float = 0.0) -> None:
        self._delay = max(0.0, float(delay))
        self._locks: Dict[str, threading.Lock] = {}
        self._last_call: Dict[str, float] = {}
        self._meta_lock = threading.Lock()

    def _get_lock(self, domain: str) -> threading.Lock:
        with self._meta_lock:
            if domain not in self._locks:
                self._locks[domain] = threading.Lock()
                self._last_call[domain] = 0.0
            return self._locks[domain]

    def wait(self, url: str) -> None:
        if self._delay <= 0:
            return
        domain = urlparse(url).netloc.lower()
        lock = self._get_lock(domain)
        with lock:
            now = time.monotonic()
            elapsed = now - self._last_call[domain]
            sleep_for = self._delay - elapsed
            if sleep_for > 0:
                time.sleep(sleep_for)
            self._last_call[domain] = time.monotonic()


# ---------------------------------------------------------------------------
# Circuit breaker per-domain
# ---------------------------------------------------------------------------

class DomainCircuitBreaker:
    """
    Apre il circuito per un dominio dopo `threshold` errori consecutivi.
    Si richiude dopo `reset_timeout` secondi (half-open: riprova una request).
    """

    def __init__(self, threshold: int = 5, reset_timeout: float = 60.0) -> None:
        self._threshold = threshold
        self._reset_timeout = reset_timeout
        self._lock = threading.Lock()
        self._errors: Dict[str, int] = defaultdict(int)
        self._opened_at: Dict[str, float] = {}
        self._open: Set[str] = set()

    def _domain(self, url: str) -> str:
        return urlparse(url).netloc.lower()

    def is_open(self, url: str) -> bool:
        d = self._domain(url)
        with self._lock:
            if d not in self._open:
                return False
            # Half-open check
            if time.monotonic() - self._opened_at.get(d, 0) > self._reset_timeout:
                log.info("[CB] Half-open: riprovando %s", d)
                self._open.discard(d)
                self._errors[d] = 0
                return False
            return True

    def record_success(self, url: str) -> None:
        d = self._domain(url)
        with self._lock:
            self._errors[d] = 0
            self._open.discard(d)

    def record_failure(self, url: str) -> None:
        d = self._domain(url)
        with self._lock:
            self._errors[d] += 1
            if self._errors[d] >= self._threshold and d not in self._open:
                self._open.add(d)
                self._opened_at[d] = time.monotonic()
                log.warning("[CB] Circuito aperto per %s (errori: %d)", d, self._errors[d])


# ---------------------------------------------------------------------------
# HttpClient
# ---------------------------------------------------------------------------

class _CappedRetry(Retry):
    """
    Retry che non dorme piu' di MAX_RETRY_AFTER secondi anche se il server
    risponde 429/503 con un Retry-After enorme (es. 3600): senza tetto il
    crawler restava fermo per ore senza scrivere nulla.
    """
    MAX_RETRY_AFTER = 20.0

    def get_retry_after(self, response):
        value = super().get_retry_after(response)
        if value and value > self.MAX_RETRY_AFTER:
            log.warning("Retry-After %.0fs ridotto a %.0fs per %s", value, self.MAX_RETRY_AFTER,
                        getattr(response, "geturl", lambda: "?")())
            return self.MAX_RETRY_AFTER
        return value


class HttpClient:
    """
    Client HTTP thread-safe. Una singola sessione è condivisa fra i worker.
    Aggiunge rate-limit per-domain, circuit-breaker, e prefetch robots.txt
    in background (non blocca il primo worker su un domain nuovo).
    """

    def __init__(self, cfg: CrawlerConfig) -> None:
        self.cfg = cfg
        self.rate_limiter = PerDomainRateLimiter(cfg.rate_limit_delay)
        self.circuit_breaker = DomainCircuitBreaker(
            threshold=cfg.cb_error_threshold,
            reset_timeout=cfg.cb_reset_timeout,
        )
        self.session = self._build_session(cfg)
        self._robots: Dict[str, Optional[RobotFileParser]] = {}
        self._robots_lock = threading.Lock()
        self._robots_fetching: Set[str] = set()  # evita fetch duplicati in parallelo

    @staticmethod
    def _accept_encoding() -> str:
        """Dichiara 'br' solo se la libreria brotli e' installata: altrimenti requests non sa
        decodificare la risposta e il parser HTML riceve byte compressi (encoding error a raffica)."""
        try:
            import brotli  # noqa: F401
            return "gzip, deflate, br"
        except ImportError:
            try:
                import brotlicffi  # noqa: F401
                return "gzip, deflate, br"
            except ImportError:
                return "gzip, deflate"

    @staticmethod
    def _build_session(cfg: CrawlerConfig) -> requests.Session:
        s = requests.Session()
        s.headers.update({
            "User-Agent": cfg.user_agent,
            "Accept": (
                "text/html,application/xhtml+xml,application/xml;q=0.9,"
                "image/avif,image/webp,image/apng,*/*;q=0.8"
            ),
            "Accept-Language": cfg.accept_language,
            "Accept-Encoding": HttpClient._accept_encoding(),
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
        })

        retry = _CappedRetry(
            total=4,
            connect=2,
            read=1,
            status=3,
            backoff_factor=0.6,
            status_forcelist=(408, 429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET", "HEAD"}),
            respect_retry_after_header=True,
            raise_on_status=False,
        )
        pool = max(16, cfg.max_workers * 2)
        adapter = HTTPAdapter(
            max_retries=retry,
            pool_connections=pool,
            pool_maxsize=pool,
            pool_block=False,
        )
        s.mount("http://", adapter)
        s.mount("https://", adapter)
        s.verify = cfg.verify_tls
        return s

    # ------------------------------------------------------------------
    # robots.txt — caricamento NON-BLOCCANTE con double-checked locking
    # ------------------------------------------------------------------

    def _get_robots(self, url: str) -> Optional[RobotFileParser]:
        parsed = urlparse(url)
        if not parsed.netloc:
            return None
        key = f"{parsed.scheme}://{parsed.netloc}"

        # Fast-path senza lock
        if key in self._robots:
            return self._robots[key]

        with self._robots_lock:
            # Double-check dopo aver preso il lock
            if key in self._robots:
                return self._robots[key]
            # Evita fetch concorrenti per lo stesso domain
            if key in self._robots_fetching:
                # Un altro thread sta già scaricando: permetti la request
                # senza aspettare (fail-open)
                return None
            self._robots_fetching.add(key)

        # Scarica fuori dal lock per non bloccare altri thread su altri domain
        rp: Optional[RobotFileParser] = None
        robots_url = f"{key}/robots.txt"
        try:
            resp = self.session.get(robots_url, timeout=max(5, self.cfg.request_timeout // 2))
            if resp.status_code == 200:
                rp = RobotFileParser()
                rp.parse(resp.text.splitlines())
        except Exception as exc:
            log.debug("robots.txt non leggibile per %s: %s", key, exc)

        with self._robots_lock:
            self._robots[key] = rp
            self._robots_fetching.discard(key)
        return rp

    def can_fetch(self, url: str) -> bool:
        if not self.cfg.respect_robots:
            return True
        rp = self._get_robots(url)
        if rp is None:
            return True
        try:
            return rp.can_fetch(self.cfg.user_agent, url)
        except Exception:
            return True

    # ------------------------------------------------------------------
    # Richieste
    # ------------------------------------------------------------------

    def _wait_circuit(self, url: str) -> None:
        """
        Con il circuito aperto (troppi errori di fila: il sito e' in difficolta')
        il worker ASPETTA la riapertura invece di far fallire subito l'URL:
        prima, un singolo scatto del breaker faceva scartare in blocco
        centinaia di file ancora in coda.
        """
        deadline = time.monotonic() + self.cfg.cb_reset_timeout + 10
        while self.circuit_breaker.is_open(url):
            if time.monotonic() > deadline:
                raise requests.exceptions.ConnectionError(
                    f"Circuit breaker aperto per {urlparse(url).netloc}"
                )
            time.sleep(1.0)

    def get(
        self,
        url: str,
        *,
        stream: bool = False,
        timeout: Optional[int] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> requests.Response:
        self._wait_circuit(url)
        self.rate_limiter.wait(url)
        headers = dict(extra_headers) if extra_headers else None
        try:
            resp = self.session.get(
                url,
                stream=stream,
                timeout=timeout or self.cfg.request_timeout,
                headers=headers,
                allow_redirects=True,
            )
            if resp.status_code < 500:
                self.circuit_breaker.record_success(url)
            else:
                self.circuit_breaker.record_failure(url)
            return resp
        except requests.RequestException:
            self.circuit_breaker.record_failure(url)
            raise

    def head(self, url: str, timeout: Optional[int] = None) -> requests.Response:
        self._wait_circuit(url)
        self.rate_limiter.wait(url)
        try:
            resp = self.session.head(
                url,
                timeout=timeout or self.cfg.request_timeout,
                allow_redirects=True,
            )
            self.circuit_breaker.record_success(url)
            return resp
        except requests.RequestException:
            self.circuit_breaker.record_failure(url)
            raise

    def should_skip_large_asset(self, url: str, max_bytes: int) -> bool:
        """
        HEAD pre-check per asset potenzialmente grandi.
        Ritorna True se Content-Length > max_bytes, evitando download inutili.
        """
        if max_bytes <= 0:
            return False
        try:
            resp = self.head(url, timeout=5)
            cl = int(resp.headers.get("Content-Length", 0))
            if cl > max_bytes:
                log.info("[SKIP-SIZE] %s (%d MB > limit)", url, cl // (1024 * 1024))
                return True
        except Exception:
            pass  # in caso di errore, scarica comunque
        return False

    def close(self) -> None:
        try:
            self.session.close()
        except Exception:
            pass
