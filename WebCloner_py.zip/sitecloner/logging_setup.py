"""
logging_setup.py
================
Configurazione logging colorato (console) + file opzionale.
"""

from __future__ import annotations
import logging
import sys
import os


class _ColorFormatter(logging.Formatter):
    """Formatter colorato per console (ANSI). No-op se la console non supporta."""
    COLORS = {
        "DEBUG":    "\033[36m",      # cyan
        "INFO":     "\033[32m",      # green
        "WARNING":  "\033[33m",      # yellow
        "ERROR":    "\033[31m",      # red
        "CRITICAL": "\033[1;31m",    # bold red
    }
    RESET = "\033[0m"

    def __init__(self, use_color: bool = True) -> None:
        super().__init__(
            fmt="%(asctime)s [%(levelname)-7s] %(message)s",
            datefmt="%H:%M:%S",
        )
        self.use_color = use_color and self._supports_color()

    @staticmethod
    def _supports_color() -> bool:
        # Colori abilitati se siamo su un terminale interattivo
        if not sys.stderr.isatty():
            return False
        if os.name == "nt":
            # Windows 10+ supporta ANSI nei terminali moderni
            try:
                import colorama
                colorama.just_fix_windows_console()
                return True
            except Exception:
                return False
        return True

    def format(self, record: logging.LogRecord) -> str:
        msg = super().format(record)
        if self.use_color:
            color = self.COLORS.get(record.levelname, "")
            if color:
                msg = f"{color}{msg}{self.RESET}"
        return msg


def setup_logging(level: str = "INFO", log_file: str | None = None) -> None:
    """Configura il logger root della libreria 'sitecloner'."""
    root = logging.getLogger("sitecloner")
    root.handlers.clear()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Console handler
    ch = logging.StreamHandler(sys.stderr)
    ch.setFormatter(_ColorFormatter(use_color=True))
    root.addHandler(ch)

    # File handler opzionale
    if log_file:
        try:
            fh = logging.FileHandler(log_file, encoding="utf-8")
            fh.setFormatter(logging.Formatter(
                "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
            ))
            root.addHandler(fh)
        except OSError as exc:
            root.warning("Impossibile aprire il file di log %s: %s", log_file, exc)

    # Riduci verbosità delle librerie HTTP
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
