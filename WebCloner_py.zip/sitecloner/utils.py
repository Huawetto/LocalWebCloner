"""
utils.py
========
Utility pure: normalizzazione URL, classificazione risorse,
mapping URL -> percorso locale, sanitizzazione filename, calcolo path relativi.
Nessuna dipendenza da rete o I/O sui contenuti.
"""

from __future__ import annotations
import os
import re
import hashlib
import posixpath
from typing import Optional, Tuple
from urllib.parse import urlparse, urljoin, urlunparse, unquote, quote, parse_qsl, urlencode, ParseResult

from .config import (
    HTML_EXTENSIONS,
    CSS_EXTENSIONS,
    JS_EXTENSIONS,
    IMAGE_EXTENSIONS,
    FONT_EXTENSIONS,
    MEDIA_EXTENSIONS,
    DOCUMENT_EXTENSIONS,
    ASSET_EXTENSIONS,
    TRACKING_PARAMS,
    IGNORED_SCHEMES,
    MAX_PATH_LENGTH,
    MAX_FILENAME_LENGTH,
)


# ---------------------------------------------------------------------------
# Classificazione risorse
# ---------------------------------------------------------------------------

class ResourceKind:
    """Tassonomia dei tipi di risorsa gestiti dal cloner."""
    HTML = "html"
    CSS = "css"
    JS = "js"
    IMAGE = "image"
    FONT = "font"
    MEDIA = "media"
    DOCUMENT = "document"
    OTHER = "other"


def _ext_of(url_or_path: str) -> str:
    """Restituisce l'estensione lowercase (con punto) dal path dell'URL o dal nome file."""
    parsed = urlparse(url_or_path) if "://" in url_or_path else None
    path = parsed.path if parsed else url_or_path
    # posixpath gestisce sempre con '/' (path-URL), os.path no su Windows
    _, ext = posixpath.splitext(path)
    return ext.lower()


def classify_url(url: str, content_type: Optional[str] = None) -> str:
    """
    Classifica un URL come HTML/CSS/JS/IMAGE/FONT/MEDIA/DOCUMENT/OTHER.
    Usa prima il content-type (se fornito) e poi l'estensione del path.
    """
    if content_type:
        ct = content_type.split(";", 1)[0].strip().lower()
        if ct in ("text/html", "application/xhtml+xml"):
            return ResourceKind.HTML
        if ct == "text/css":
            return ResourceKind.CSS
        if ct in ("text/javascript", "application/javascript", "application/x-javascript"):
            return ResourceKind.JS
        if ct.startswith("image/"):
            return ResourceKind.IMAGE
        if ct.startswith("font/") or ct in (
            "application/font-woff", "application/font-woff2",
            "application/vnd.ms-fontobject", "application/x-font-ttf",
            "application/x-font-otf",
        ):
            return ResourceKind.FONT
        if ct.startswith(("video/", "audio/")):
            return ResourceKind.MEDIA

    ext = _ext_of(url)
    # Un tipo "application/*" (octet-stream, force-download, pdf...) non e'
    # una pagina: un URL tipo download.php?id=3 che serve un file binario non
    # deve essere trattato come HTML solo per l'estensione.
    if content_type:
        ct = content_type.split(";", 1)[0].strip().lower()
        if ct.startswith("application/") and ct != "application/xhtml+xml" and ext in HTML_EXTENSIONS:
            return ResourceKind.OTHER
    if ext in CSS_EXTENSIONS:
        return ResourceKind.CSS
    if ext in JS_EXTENSIONS:
        return ResourceKind.JS
    if ext in IMAGE_EXTENSIONS:
        return ResourceKind.IMAGE
    if ext in FONT_EXTENSIONS:
        return ResourceKind.FONT
    if ext in MEDIA_EXTENSIONS:
        return ResourceKind.MEDIA
    if ext in DOCUMENT_EXTENSIONS:
        return ResourceKind.DOCUMENT
    if ext in HTML_EXTENSIONS:
        return ResourceKind.HTML
    return ResourceKind.OTHER


_MAGIC = (
    (b"\xff\xd8\xff", ResourceKind.IMAGE, ".jpg"),
    (b"\x89PNG\r\n\x1a\n", ResourceKind.IMAGE, ".png"),
    (b"GIF87a", ResourceKind.IMAGE, ".gif"),
    (b"GIF89a", ResourceKind.IMAGE, ".gif"),
    (b"BM", ResourceKind.IMAGE, ".bmp"),
    (b"%PDF", ResourceKind.DOCUMENT, ".pdf"),
    (b"PK\x03\x04", ResourceKind.DOCUMENT, ".zip"),
    (b"Rar!", ResourceKind.DOCUMENT, ".rar"),
    (b"7z\xbc\xaf\x27\x1c", ResourceKind.DOCUMENT, ".7z"),
    (b"\x1f\x8b", ResourceKind.DOCUMENT, ".gz"),
    (b"\xd0\xcf\x11\xe0", ResourceKind.DOCUMENT, ".doc"),
    (b"ID3", ResourceKind.MEDIA, ".mp3"),
    (b"OggS", ResourceKind.MEDIA, ".ogg"),
    (b"\x1aE\xdf\xa3", ResourceKind.MEDIA, ".webm"),
)


def sniff_binary(body: bytes):
    """
    Se `body` e' chiaramente un file binario (e non testo/HTML) ritorna
    (ResourceKind, estensione); altrimenti None. Serve a non dare in pasto
    a un parser HTML immagini/PDF/zip serviti con content-type o estensione
    fuorvianti (lxml altrimenti stampa a raffica "encoding error ...").
    """
    head = body[:2048]
    if not head:
        return None
    for magic, kind, ext in _MAGIC:
        if head.startswith(magic):
            if magic == b"BM" and b"<" in head[:64]:
                continue
            return kind, ext
    if head[:4] == b"RIFF" and len(head) >= 12:
        sub = head[8:12]
        if sub == b"WEBP":
            return ResourceKind.IMAGE, ".webp"
        if sub == b"WAVE":
            return ResourceKind.MEDIA, ".wav"
        return ResourceKind.MEDIA, ".avi"
    if len(head) >= 12 and head[4:8] == b"ftyp":
        return ResourceKind.MEDIA, ".mp4"
    if b"\x00" in head and not head.startswith((b"\xff\xfe", b"\xfe\xff")):
        return ResourceKind.OTHER, ".bin"
    return None


_CMS_INTERNAL_RE = re.compile(
    r"/wp-json(?:/|$|\?)|[?&]rest_route=|/xmlrpc\.php|/oembed/|/wp-admin/|/wp-login\.php"
    r"|/feed/?(?:$|\?)|/comments/feed|[?&]replytocom=|[?&]action=(?:lostpassword|register|logout)",
    re.IGNORECASE,
)


def is_cms_internal_url(url: str) -> bool:
    """
    Endpoint tecnici dei CMS (WordPress: REST API, xmlrpc, oEmbed, wp-admin,
    feed RSS...). Sono inutili in un clone offline e spesso sono PHP lenti
    che restano appesi: bloccavano tutti i worker per minuti.
    """
    return bool(_CMS_INTERNAL_RE.search(url))


def is_asset_url(url: str) -> bool:
    """True se l'URL è chiaramente una risorsa statica (non una pagina HTML)."""
    return _ext_of(url) in ASSET_EXTENSIONS


def is_html_url(url: str) -> bool:
    """True se l'URL sembra una pagina HTML navigabile."""
    ext = _ext_of(url)
    return ext in HTML_EXTENSIONS or ext == ""


# ---------------------------------------------------------------------------
# Rilevamento pagine di login
# ---------------------------------------------------------------------------
# Un clone statico non ha alcun backend (PHP, database, sessioni) in grado
# di elaborare un submit: qualunque form di login, su qualsiasi CMS, non
# potrà MAI autenticare con successo offline (il POST finisce contro un
# file statico o un semplice server che risponde "Metodo non supportato").
# Rileviamo questi form a livello di contenuto (non di URL, perché molti
# siti rinominano lo slug di login per sicurezza, es. "/secretlogin/"
# invece di "/wp-login.php") così possiamo escluderli dal clone invece di
# scaricare una pagina che può solo fallire.
#
# NOTA: non basta cercare name="loginform"/id="loginform" nel documento:
# alcuni temi riusano lo stesso nome anche per un piccolo widget "accesso
# rapido" incorporato nella HOMEPAGE (pagina di contenuto, non dedicata al
# login) — escluderla per intero sarebbe un falso positivo enorme.
_BODY_LOGIN_CLASS_RE = re.compile(
    rb'<body\b[^>]*\bclass=["\'][^"\']*\blogin\b[^"\']*["\']', re.IGNORECASE
)
_PASSWORD_INPUT_RE = re.compile(rb'type=["\']password["\']', re.IGNORECASE)
_POST_FORM_RE = re.compile(rb'<form\b[^>]*method=["\']post["\']', re.IGNORECASE | re.DOTALL)
_TITLE_LOGIN_HINT_RE = re.compile(
    rb'<title>[^<]{0,80}\b(login|log in|sign in|accedi|accesso)\b', re.IGNORECASE
)
_ANCHOR_RE = re.compile(rb'<a\b', re.IGNORECASE)


def looks_like_login_page(body: bytes) -> bool:
    """
    Euristica content-based: True se `body` (HTML grezzo) è una pagina
    DEDICATA al login/autenticazione (non una pagina di contenuto che si
    limita a incorporare un widget di accesso), e quindi non può funzionare
    in un clone statico.
    """
    if not body:
        return False
    # Segnale forte e specifico: WordPress imposta class="login ..." SOLO
    # sul template reale di wp-login.php.
    if _BODY_LOGIN_CLASS_RE.search(body):
        return True
    if not (_PASSWORD_INPUT_RE.search(body) and _POST_FORM_RE.search(body)):
        return False
    # Fallback generico per CMS diversi da WordPress: richiediamo anche un
    # titolo esplicito da pagina di login E pochi link in uscita, per non
    # scartare pagine di contenuto che incorporano solo un piccolo widget.
    if not _TITLE_LOGIN_HINT_RE.search(body):
        return False
    return len(_ANCHOR_RE.findall(body)) <= 15


# ---------------------------------------------------------------------------
# Validazione & normalizzazione URL
# ---------------------------------------------------------------------------

def is_valid_url(url: str) -> bool:
    """Filtra schemi non gestiti (mailto, tel, data, javascript, ecc.)."""
    if not url or not isinstance(url, str):
        return False
    url = url.strip()
    if not url:
        return False
    # data:, javascript:, mailto:, tel:, ...
    if ":" in url[:12]:
        scheme = url.split(":", 1)[0].lower()
        if scheme in IGNORED_SCHEMES:
            return False
    return True


def normalize_url(url: str, base_url: str) -> Optional[str]:
    """
    Risolve relativi, rimuove fragment, strippa tracking params, lowercase del netloc.
    Ritorna None se l'URL non è valido o non gestibile.
    """
    if not is_valid_url(url):
        return None
    try:
        # Strip fragment e join con base
        absolute = urljoin(base_url, url.split("#", 1)[0].strip())
        parsed = urlparse(absolute)

        if parsed.scheme not in ("http", "https"):
            return None
        if not parsed.netloc:
            return None

        # Rimuove tracking params, conserva il resto preservando l'ordine
        if parsed.query:
            kept = [(k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=True)
                    if k.lower() not in TRACKING_PARAMS]
            new_query = urlencode(kept, doseq=True)
        else:
            new_query = ""

        # Normalizza netloc (lowercase) e path (decode percent + rimozione doppi slash)
        netloc = parsed.netloc.lower()
        path = parsed.path or "/"
        # Normalizza percorsi tipo /a/./b/../c -> /a/c (solo se path non vuoto)
        try:
            normalized_path = posixpath.normpath(path)
            # posixpath.normpath rimuove lo slash finale: preserviamo l'intento originale
            if path.endswith("/") and not normalized_path.endswith("/"):
                normalized_path += "/"
            if normalized_path == ".":
                normalized_path = "/"
        except Exception:
            normalized_path = path

        rebuilt = ParseResult(
            scheme=parsed.scheme,
            netloc=netloc,
            path=normalized_path,
            params="",
            query=new_query,
            fragment="",
        )
        return urlunparse(rebuilt)
    except Exception:
        return None


def same_site(url_a: str, url_b: str, include_subdomains: bool = True) -> bool:
    """True se due URL appartengono allo stesso sito (dominio o sottodominio)."""
    try:
        a = urlparse(url_a).netloc.lower()
        b = urlparse(url_b).netloc.lower()
    except Exception:
        return False
    if not a or not b:
        return False
    if a == b:
        return True
    if include_subdomains:
        # Confronto sui registrable: euristica semplice basata sui due ultimi label
        a_parts = a.split(".")
        b_parts = b.split(".")
        if len(a_parts) >= 2 and len(b_parts) >= 2:
            return a_parts[-2:] == b_parts[-2:]
    return False


# ---------------------------------------------------------------------------
# Sanitizzazione filename / path
# ---------------------------------------------------------------------------

_INVALID_FS_CHARS = re.compile(r'[<>:"|?*\x00-\x1f]')
_WINDOWS_RESERVED = re.compile(
    r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\..*)?$", re.IGNORECASE
)


def sanitize_filename(name: str) -> str:
    """Pulisce un singolo segmento di path da caratteri invalidi su FS comuni."""
    if not name:
        return "_"
    name = unquote(name)
    # Rimpiazza caratteri invalidi
    name = _INVALID_FS_CHARS.sub("_", name)
    # Trim spazi/punti finali (Windows non li ammette)
    name = name.rstrip(" .")
    # Nomi riservati Windows
    if _WINDOWS_RESERVED.match(name):
        name = "_" + name
    if not name:
        name = "_"
    # Tronca preservando l'estensione se presente
    if len(name) > MAX_FILENAME_LENGTH:
        base, ext = posixpath.splitext(name)
        keep = MAX_FILENAME_LENGTH - len(ext) - 9  # 9 per hash + separatore
        h = hashlib.md5(name.encode("utf-8", "ignore")).hexdigest()[:8]
        name = f"{base[:keep]}_{h}{ext}"
    return name


def _ensure_extension(filename: str, kind: str) -> str:
    """Garantisce che il file abbia un'estensione coerente col tipo di risorsa."""
    if "." in filename:
        return filename
    defaults = {
        ResourceKind.HTML: ".html",
        ResourceKind.CSS: ".css",
        ResourceKind.JS: ".js",
        ResourceKind.IMAGE: ".bin",
        ResourceKind.FONT: ".bin",
        ResourceKind.MEDIA: ".bin",
        ResourceKind.DOCUMENT: ".bin",
        ResourceKind.OTHER: ".bin",
    }
    return filename + defaults.get(kind, ".bin")


def url_to_local_path(url: str, base_dir: str, base_netloc: str, kind: Optional[str] = None) -> str:
    """
    Mappa un URL in un percorso locale deterministico sotto base_dir.

    Struttura:
        base_dir/<netloc>/<path>...
        - directory URL "/" o "/foo/" -> /index.html
        - query string -> suffix -q<hash8> sul filename
        - estensione mancante -> dedotta da `kind`

    Tutto sotto <netloc> per supportare asset cross-domain mantenendo coerenza.
    """
    parsed = urlparse(url)
    netloc = parsed.netloc.lower() or base_netloc
    raw_path = parsed.path or "/"

    # Decompone path in segmenti
    segments = [seg for seg in raw_path.split("/") if seg]

    # Path che termina con "/" -> directory: salviamo index.html
    is_dir = raw_path.endswith("/") or not segments
    if is_dir:
        segments.append("index.html")

    # Sanitizza ogni segmento
    sanitized = [sanitize_filename(seg) for seg in segments]

    # Sull'ultimo segmento aggancia query e estensione default
    last = sanitized[-1] if sanitized else "index.html"
    if parsed.query:
        q_hash = hashlib.md5(parsed.query.encode("utf-8", "ignore")).hexdigest()[:8]
        base, ext = posixpath.splitext(last)
        last = f"{base}__q{q_hash}{ext}"
    if kind:
        last = _ensure_extension(last, kind)
    sanitized[-1] = last

    # Cartella del netloc (sanitizzata anch'essa)
    safe_netloc = sanitize_filename(netloc)

    # Costruzione path finale
    local_path = os.path.join(base_dir, safe_netloc, *sanitized)

    # Hard cap sulla lunghezza totale: se sfora, comprime con hash
    if len(local_path) > MAX_PATH_LENGTH:
        h = hashlib.md5(url.encode("utf-8", "ignore")).hexdigest()[:12]
        _, ext = posixpath.splitext(local_path)
        local_path = os.path.join(base_dir, safe_netloc, "_long", f"{h}{ext}")

    return local_path


def relative_path(from_file: str, to_file: str) -> str:
    """
    Calcola il path relativo POSIX (con '/') da `from_file` a `to_file`.
    Entrambi i path sono file (non directory). Usato per riscrivere href/src.
    """
    from_dir = os.path.dirname(os.path.abspath(from_file))
    to_abs = os.path.abspath(to_file)
    try:
        rel = os.path.relpath(to_abs, start=from_dir)
    except ValueError:
        # Drive diversi su Windows: fallback ad assoluto
        return to_abs.replace("\\", "/")
    return rel.replace(os.sep, "/")


def url_fingerprint(url: str) -> str:
    """Hash stabile dell'URL canonicalizzato (per cache, log, mapping)."""
    return hashlib.sha1(url.encode("utf-8", "ignore")).hexdigest()


def parse_srcset(srcset_value: str) -> list[str]:
    """
    Parsa un valore srcset/imagesrcset estraendo solo gli URL.
    Esempio: "a.jpg 1x, b.jpg 2x, c.jpg 3x" -> ["a.jpg", "b.jpg", "c.jpg"]
    """
    urls = []
    if not srcset_value:
        return urls
    # split per virgola ma solo fuori dalle parentesi (per data-URI ecc.)
    for candidate in re.split(r",(?![^(]*\))", srcset_value):
        candidate = candidate.strip()
        if not candidate:
            continue
        # primo token = URL, il resto = descriptor (1x, 100w, ...)
        url = candidate.split()[0]
        if url:
            urls.append(url)
    return urls
