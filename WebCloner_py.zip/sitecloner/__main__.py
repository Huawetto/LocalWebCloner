#!/usr/bin/env python3
"""
sitecloner CLI — versione migliorata
=====================================
Aggiunge:
  --priority-queue / --no-priority-queue
  --max-asset-mb         HEAD pre-check per asset grandi
  --no-parse-js          disabilita estrazione URL da JS
  --no-parse-sitemap     disabilita parsing sitemap XML
  --cb-threshold         soglia errori per circuit-breaker
  --rewrite-workers      thread per fase di riscrittura
"""

from __future__ import annotations
import argparse
import os
import sys
from urllib.parse import urlparse

from .config import CrawlerConfig
from .crawler import Crawler
from .logging_setup import setup_logging


def _parse_args(argv=None):
    p = argparse.ArgumentParser(
        prog="sitecloner",
        description="Clona integralmente un sito web (HTML + CSS + JS + asset) per uso offline.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("url", nargs="?", help="URL di partenza (es. https://example.com)")
    p.add_argument("-o", "--output", default=None)
    p.add_argument("-d", "--depth", type=int, default=3)
    p.add_argument("-w", "--workers", type=int, default=16)
    p.add_argument("--max-pages", type=int, default=0)
    p.add_argument("--timeout", type=int, default=20)
    p.add_argument("--rate", type=float, default=0.0,
                   help="Rate-limit in secondi PER DOMAIN (non globale)")
    p.add_argument("--no-rewrite", action="store_true")
    p.add_argument("--no-external-assets", action="store_true")
    p.add_argument("--exclude-subdomains", action="store_true")
    p.add_argument("--no-fonts", action="store_true")
    p.add_argument("--no-media", action="store_true")
    p.add_argument("--no-documents", action="store_true")
    p.add_argument("--respect-robots", action="store_true")
    p.add_argument("--no-verify-tls", action="store_true")
    p.add_argument("--user-agent", default=None)
    p.add_argument("--ignore", action="append", default=[])
    p.add_argument("--log-level", default="INFO",
                   choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    p.add_argument("--log-file", default=None)
    p.add_argument("--no-metadata", action="store_true")
    p.add_argument("--keep-login-pages", action="store_true",
                   help="Non escludere le pagine di login (di default vengono saltate: "
                        "un clone statico non può mai farci accedere davvero)")
    p.add_argument("--keep-cms-endpoints", action="store_true",
                   help="Non ignorare gli endpoint tecnici dei CMS (wp-json, xmlrpc.php, oembed, feed, wp-admin)")
    p.add_argument("--serve", metavar="CARTELLA", nargs="?", const=".", default=None,
                   help="Non clonare: avvia il server di editing locale su una cartella gia' clonata "
                        "(salvataggio su disco, verifica script, upload). Senza valore usa la cartella "
                        "in cui lanci il comando")
    p.add_argument("--add-toolbar", action="store_true",
                   help="Con --serve: aggiunge la toolbar alle pagine di un clone gia' scaricato (senza riscaricare)")
    p.add_argument("--remove-toolbar", action="store_true",
                   help="Con --serve: toglie la toolbar dalle pagine e termina")
    p.add_argument("--port", type=int, default=8000, help="Porta del server di editing (con --serve)")
    p.add_argument("--open-path", default=None,
                   help="Con --serve: percorso da aprire nel browser, es. /www.sito.it/index.html")
    tb_grp = p.add_mutually_exclusive_group()
    tb_grp.add_argument("--editor-toolbar", dest="editor_toolbar", action="store_true", default=None,
                         help="Aggiungi la toolbar di editing GUI locale a ogni pagina "
                              "(salta la domanda interattiva)")
    tb_grp.add_argument("--no-editor-toolbar", dest="editor_toolbar", action="store_false",
                         help="Non aggiungere la toolbar di editing (salta la domanda interattiva)")
    # --- Nuove opzioni ---
    p.add_argument("--no-priority-queue", action="store_true",
                   help="Disabilita la priority queue (usa FIFO come l'originale)")
    p.add_argument("--max-asset-mb", type=float, default=0.0,
                   help="Skip asset > N MB (HEAD pre-check). 0 = nessun limite")
    p.add_argument("--no-parse-js", action="store_true",
                   help="Non estrarre URL statici da file JS")
    p.add_argument("--no-parse-sitemap", action="store_true",
                   help="Non parsare sitemap.xml per scoprire URL")
    p.add_argument("--cb-threshold", type=int, default=5,
                   help="Errori consecutivi prima di aprire il circuit-breaker per un domain")
    p.add_argument("--cb-reset", type=float, default=60.0,
                   help="Secondi prima di tentare di chiudere il circuit-breaker (half-open)")
    p.add_argument("--rewrite-workers", type=int, default=0,
                   help="Thread per la fase di riscrittura (0 = usa --workers)")
    return p.parse_args(argv)


def _interactive_prompt():
    print("=" * 78)
    print("  SiteCloner — Cloning completo di siti web per uso offline")
    print("=" * 78)
    while True:
        url = input("URL di partenza: ").strip()
        if url:
            break
        print("URL obbligatorio.")
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    netloc = urlparse(url).netloc.replace(".", "_") or "site"
    default_out = f"./mirror_{netloc}"
    out = input(f"Directory di output [{default_out}]: ").strip() or default_out
    try:
        depth = int(input("Profondità massima [3]: ").strip() or "3")
    except ValueError:
        depth = 3
    try:
        workers = int(input("Workers paralleli [16]: ").strip() or "16")
    except ValueError:
        workers = 16
    editor_toolbar = _ask_editor_toolbar()
    return url, out, depth, workers, editor_toolbar


def _ask(prompt: str, default: str = "") -> str:
    """input() che non va in errore se non c'e' un terminale da cui leggere (pipe, script, IDE)."""
    try:
        return input(prompt).strip()
    except EOFError:
        print()
        return default


def _ask_editor_toolbar() -> bool:
    """
    Chiede se iniettare in ogni pagina clonata la toolbar di editing GUI
    locale (si risponde con un solo carattere: 0 = no, 1 = sì).
    """
    ans = _ask("Vuoi aggiungere la toolbar delle modifiche?: (0 = no, 1 = si): ")
    return ans == "1"


def main(argv=None):
    args = _parse_args(argv)

    if args.serve:
        from .editor_server import serve, install_toolbar
        if args.add_toolbar or args.remove_toolbar:
            changed, total = install_toolbar(args.serve, remove=args.remove_toolbar)
            print(f"Toolbar {'rimossa da' if args.remove_toolbar else 'aggiunta a'} {changed} pagine su {total} trovate")
            if args.remove_toolbar:
                return 0
        serve(args.serve, port=args.port, open_path=args.open_path, open_browser=bool(args.open_path),
              verbose=args.log_level == "DEBUG")
        return 0

    if not args.url:
        url, output, depth, workers, editor_toolbar = _interactive_prompt()
    else:
        url = args.url
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        depth = args.depth
        workers = args.workers
        netloc = urlparse(url).netloc.replace(".", "_") or "site"
        output = args.output or f"./mirror_{netloc}"
        editor_toolbar = args.editor_toolbar if args.editor_toolbar is not None else _ask_editor_toolbar()

    output = os.path.abspath(output)

    cfg = CrawlerConfig(
        start_url=url,
        output_dir=output,
        max_depth=depth,
        max_pages=args.max_pages,
        max_workers=max(1, workers),
        rewrite_workers=args.rewrite_workers,
        request_timeout=args.timeout,
        rate_limit_delay=args.rate,
        same_domain_only=True,
        include_subdomains=not args.exclude_subdomains,
        follow_external_assets=not args.no_external_assets,
        rewrite_links=not args.no_rewrite,
        parse_css_assets=True,
        parse_inline_styles=True,
        parse_js_urls=not args.no_parse_js,
        parse_sitemap=not args.no_parse_sitemap,
        download_fonts=not args.no_fonts,
        download_media=not args.no_media,
        download_documents=not args.no_documents,
        max_asset_size_mb=args.max_asset_mb,
        user_agent=args.user_agent or CrawlerConfig.__dataclass_fields__["user_agent"].default,
        verify_tls=not args.no_verify_tls,
        respect_robots=args.respect_robots,
        extract_metadata=not args.no_metadata,
        skip_login_pages=not args.keep_login_pages,
        skip_cms_endpoints=not args.keep_cms_endpoints,
        add_editor_toolbar=editor_toolbar,
        log_level=args.log_level,
        log_file=args.log_file,
        ignored_url_patterns=tuple(args.ignore or ()),
        use_priority_queue=not args.no_priority_queue,
        cb_error_threshold=args.cb_threshold,
        cb_reset_timeout=args.cb_reset,
    )

    setup_logging(level=cfg.log_level, log_file=cfg.log_file)

    try:
        crawler = Crawler(cfg)
        stats = crawler.run()
    except KeyboardInterrupt:
        print("\nInterrotto.", file=sys.stderr)
        return 130
    except Exception as exc:
        import traceback
        traceback.print_exc()
        print(f"Errore fatale: {exc}", file=sys.stderr)
        return 1

    print()
    print("Risultati finali:")
    for k, v in stats.items():
        print(f"  {k:24s} = {v}")
    print(f"Output: {output}")

    if not stats.get("html_pages"):
        print()
        print("ATTENZIONE: nessuna pagina HTML scaricata. Il sito non ha risposto (timeout/502/blocco).")
        print("Riprova piu' tardi con meno carico, ad esempio:  -w 3 --rate 1 --timeout 60")

    if editor_toolbar and sys.stdin.isatty():
        start_local = None
        try:
            from .utils import normalize_url
            nu = normalize_url(url, url)
            lp = crawler.registry.get_local_path(nu) if nu else None
            if lp:
                start_local = "/" + os.path.relpath(lp, output).replace(os.sep, "/")
        except Exception:
            pass
        ans = _ask("Avviare ora il server di editing per usare la toolbar? (0 = no, 1 = si): ")
        if ans == "1":
            from .editor_server import serve
            serve(output, port=8000, open_path=start_local, open_browser=True)
    elif editor_toolbar:
        print(f"Per usare la toolbar con salvataggio su disco:  python crawl.py --serve \"{output}\"")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
