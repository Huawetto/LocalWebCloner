"""
editor_server.py
================
Server HTTP locale (solo 127.0.0.1) che serve il sito clonato e, in piu',
espone le API usate dalla toolbar di editing per fare cio' che un file
statico aperto nel browser non puo' fare:

- salvare le pagine modificate direttamente sul disco (con backup)
- elencare / leggere / scrivere script (js, css...) con verifica
  sintattica tramite compilatore (node --check) PRIMA di scrivere
- caricare asset (immagini, video, audio, html, css, js, font...); file PHP
  e database (.db .sqlite .sql ...) vengono rifiutati

Sicurezza: bind solo su loopback, token casuale per sessione (iniettato nel
toolbar.js servito da questo stesso server), controllo Host/Origin, nessuna
scrittura fuori dalla cartella radice, nessuna esecuzione di codice caricato.
"""

from __future__ import annotations
import functools
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
import webbrowser
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse, unquote, parse_qs, quote

from .editor_toolbar import build_toolbar_js

API_PREFIX = "/__sc__/"
TOOLBAR_URL_SUFFIX = "/_sitecloner_editor/toolbar.js"
BACKUP_DIR = "_sitecloner_backups"
SKIP_DIRS = {BACKUP_DIR, "_sitecloner_editor", ".git", "node_modules", "__pycache__"}
TEXT_EXT = {
    ".html", ".htm", ".xhtml", ".css", ".js", ".mjs", ".cjs", ".json",
    ".txt", ".xml", ".svg", ".md", ".csv", ".yml", ".yaml", ".ini", ".htaccess",
}
BLOCKED_UPLOAD_EXT = {
    ".php", ".php3", ".php4", ".php5", ".php7", ".php8", ".phtml", ".phar", ".phps",
    ".db", ".sqlite", ".sqlite3", ".db3", ".sql", ".mdb", ".accdb", ".dump",
}
MAX_UPLOAD = 500 * 1024 * 1024
MAX_TEXT_READ = 6 * 1024 * 1024


CLIENT_GONE = (ConnectionAbortedError, ConnectionResetError, BrokenPipeError)


class QuietServer(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        import sys
        if isinstance(sys.exc_info()[1], CLIENT_GONE):
            return  # connessione chiusa dal browser: normale, nessun traceback
        super().handle_error(request, client_address)


class ApiError(Exception):
    def __init__(self, status: int, message: str, **extra):
        super().__init__(message)
        self.status = status
        self.message = message
        self.extra = extra


def find_tool(name: str) -> Optional[str]:
    return shutil.which(name)


class EditorHandler(SimpleHTTPRequestHandler):
    server_version = "SiteClonerEditor/2"

    # -- infrastruttura ----------------------------------------------------

    @property
    def root(self) -> Path:
        return self.server.sc_root  # type: ignore[attr-defined]

    def log_message(self, fmt, *args):  # silenzioso: niente rumore in console
        if getattr(self.server, "sc_verbose", False):
            super().log_message(fmt, *args)

    def guess_type(self, path):
        ctype = super().guess_type(path)
        if ctype in ("text/html", "text/css", "text/javascript", "application/javascript",
                     "application/json", "text/plain", "image/svg+xml"):
            return ctype + "; charset=utf-8"
        return ctype

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def _json(self, status: int, payload) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self) -> bool:
        port = self.server.server_address[1]
        allowed = {f"127.0.0.1:{port}", f"localhost:{port}", f"[::1]:{port}"}
        host = (self.headers.get("Host") or "").lower()
        if host not in allowed:
            return False
        origin = self.headers.get("Origin")
        if origin and origin.lower() not in {f"http://{a}" for a in allowed}:
            return False
        return True

    def _auth_ok(self) -> bool:
        token = self.headers.get("X-SC-Token") or ""
        return self._host_ok() and hmac.compare_digest(
            token.encode(), self.server.sc_token.encode()  # type: ignore[attr-defined]
        )

    def fs_path(self, url_path: str) -> Path:
        """URL path -> percorso su disco, garantendo che resti sotto la radice."""
        p = unquote(urlparse(url_path).path)
        p = p.lstrip("/")
        target = (self.root / p).resolve()
        try:
            target.relative_to(self.root.resolve())
        except ValueError:
            raise ApiError(403, "Percorso fuori dalla cartella del sito")
        return target

    def url_of(self, fs: Path) -> str:
        return "/" + fs.resolve().relative_to(self.root.resolve()).as_posix()

    # -- routing -----------------------------------------------------------

    def do_GET(self):
        path = urlparse(self.path).path
        if path.startswith(API_PREFIX):
            return self._api("GET")
        if path.endswith(TOOLBAR_URL_SUFFIX):
            body = build_toolbar_js(self.server.sc_token).encode("ascii")  # type: ignore[attr-defined]
            self.send_response(200)
            self.send_header("Content-Type", "text/javascript; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        return super().do_GET()

    def do_POST(self):
        if urlparse(self.path).path.startswith(API_PREFIX):
            return self._api("POST")
        self.send_error(HTTPStatus.NOT_IMPLEMENTED, "Unsupported method ('POST')")

    def handle(self):
        # Il browser chiude spesso le connessioni a meta' (ricarica, cambio pagina, richieste
        # annullate): non e' un errore del server e non deve riempire la console di traceback.
        try:
            super().handle()
        except CLIENT_GONE:
            pass

    def _api(self, method: str):
        self._body_consumed = False
        try:
            if not self._auth_ok():
                raise ApiError(403, "Token o origine non validi")
            parsed = urlparse(self.path)
            name = parsed.path[len(API_PREFIX):]
            qs = {k: v[0] for k, v in parse_qs(parsed.query).items()}
            handler = getattr(self, "api_" + name.replace("-", "_"), None)
            if handler is None:
                raise ApiError(404, f"Endpoint sconosciuto: {name}")
            result = handler(method, qs)
            self._json(200, result)
        except CLIENT_GONE:
            return  # il browser non aspetta piu' la risposta: niente da inviare
        except ApiError as e:
            self._drain_body()
            self._safe_json(e.status, {"error": e.message, **e.extra})
        except Exception as e:  # pragma: no cover
            self._drain_body()
            self._safe_json(500, {"error": f"{type(e).__name__}: {e}"})

    def _safe_json(self, status: int, payload) -> None:
        try:
            self._json(status, payload)
        except CLIENT_GONE:
            pass

    # -- body helpers ------------------------------------------------------

    def _read_body(self, limit: int) -> bytes:
        length = int(self.headers.get("Content-Length") or 0)
        if length > limit:
            raise ApiError(413, "File troppo grande")
        self._body_consumed = True
        chunks, remaining = [], length
        while remaining > 0:
            chunk = self.rfile.read(min(65536, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def _drain_body(self) -> None:
        """
        Se si risponde con un errore PRIMA di leggere il file inviato, chiudere la connessione mentre
        il browser sta ancora trasmettendo la fa 'resettare' (su Windows: WinError 10053) e il client
        non vede nemmeno il messaggio di errore. Si scarta quindi il corpo rimanente.
        """
        if getattr(self, "_body_consumed", False):
            return
        try:
            remaining = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return
        self._body_consumed = True
        if remaining > MAX_UPLOAD * 2:
            self.close_connection = True
            return
        while remaining > 0:
            chunk = self.rfile.read(min(65536, remaining))
            if not chunk:
                break
            remaining -= len(chunk)

    def _read_json(self) -> dict:
        try:
            return json.loads(self._read_body(MAX_TEXT_READ * 4).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ApiError(400, "JSON non valido")

    # -- backup ------------------------------------------------------------

    def _backup_dir(self, fs: Path) -> Path:
        """
        Cartella dei backup di un file. Nome corto (hash del percorso) perche' ricopiare il
        percorso intero del file dentro _sitecloner_backups superava il limite di 260
        caratteri di Windows (WinError 206) e faceva fallire il salvataggio delle pagine.
        """
        rel = fs.resolve().relative_to(self.root.resolve()).as_posix()
        d = self.root / BACKUP_DIR / hashlib.sha1(rel.encode("utf-8")).hexdigest()[:16]
        return d

    def _backup(self, fs: Path) -> bool:
        """Copia di sicurezza prima di sovrascrivere. Ritorna False se non e' stato possibile."""
        if not fs.exists() or not fs.is_file():
            return True
        try:
            dest_dir = self._backup_dir(fs)
            dest_dir.mkdir(parents=True, exist_ok=True)
            info = dest_dir / "file.txt"
            if not info.exists():
                info.write_text(self.url_of(fs), encoding="utf-8")
            stamp = time.strftime("%Y%m%d-%H%M%S")
            dest = dest_dir / f"{stamp}.bak"
            n = 1
            while dest.exists():
                dest = dest_dir / f"{stamp}-{n}.bak"
                n += 1
            shutil.copy2(fs, dest)
            for old in sorted(dest_dir.glob("*.bak"))[:-30]:  # tiene solo gli ultimi 30
                try:
                    old.unlink()
                except OSError:
                    pass
            return True
        except OSError:
            return False  # il backup non deve mai impedire il salvataggio

    # -- verifica sintattica ----------------------------------------------

    @staticmethod
    def check_code(ext: str, code: str) -> dict:
        ext = ext.lower()
        if ext in (".js", ".mjs", ".cjs"):
            node = find_tool("node")
            if not node:
                return {"ok": False, "available": False, "checker": "node",
                        "errors": [{"line": 1, "message": "Compilatore node non trovato nel PATH"}]}
            is_module = ext == ".mjs" or re.search(r"^\s*(import|export)\b", code, re.M) is not None
            suffix = ".mjs" if is_module else ".cjs" if ext == ".cjs" else ".js"
            return EditorHandler._run_checker(
                [node, "--check", "{file}"], code, suffix, "node --check",
                re.compile(r":(\d+)\s*\n"), lambda out: out,
            )
        if ext == ".json":
            try:
                json.loads(code)
                return {"ok": True, "available": True, "checker": "json", "errors": []}
            except ValueError as e:
                line = getattr(e, "lineno", 1)
                return {"ok": False, "available": True, "checker": "json",
                        "errors": [{"line": line, "message": str(e)}]}
        return {"ok": True, "available": True, "checker": "nessuno", "errors": []}

    @staticmethod
    def _run_checker(cmd, code, suffix, label, line_re, _fmt) -> dict:
        with tempfile.TemporaryDirectory() as td:
            f = Path(td) / ("check" + suffix)
            f.write_text(code, encoding="utf-8")
            full = [str(f) if c == "{file}" else c for c in cmd]
            try:
                proc = subprocess.run(full, capture_output=True, text=True, timeout=15)
            except (OSError, subprocess.TimeoutExpired) as e:
                return {"ok": False, "available": False, "checker": label,
                        "errors": [{"line": 1, "message": f"Impossibile eseguire il compilatore: {e}"}]}
            out = (proc.stderr or "") + (proc.stdout or "")
            if proc.returncode == 0:
                return {"ok": True, "available": True, "checker": label, "errors": []}
            out = re.sub(r"\x1b\[[0-9;]*m", "", out).replace(str(f), "file")
            out = "\n".join(ln for ln in out.splitlines()
                            if not re.match(r"\s+at ", ln) and not ln.startswith("Node.js v"))
            m = line_re.search(out)
            line = int(m.group(1)) if m else 1
            msg = [ln for ln in out.splitlines() if ln.strip()]
            summary = next((ln for ln in msg if "Error" in ln or "error" in ln), msg[0] if msg else "Errore")
            return {"ok": False, "available": True, "checker": label,
                    "errors": [{"line": line, "message": summary.strip(), "detail": out.strip()[:2000]}]}

    # -- endpoint ----------------------------------------------------------

    def api_ping(self, method, qs):
        return {
            "ok": True,
            "root": self.root.name,
            "node": bool(find_tool("node")),
        }

    def api_files(self, method, qs):
        exts = {("." + e.strip().lower().lstrip(".")) for e in (qs.get("ext") or "").split(",") if e.strip()}
        out = []
        root = self.root.resolve()
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for fn in filenames:
                p = Path(dirpath) / fn
                if exts and p.suffix.lower() not in exts:
                    continue
                try:
                    st = p.stat()
                except OSError:
                    continue
                out.append({"path": "/" + p.relative_to(root).as_posix(),
                            "size": st.st_size, "mtime": int(st.st_mtime)})
                if len(out) > 20000:
                    break
        return {"files": out}

    def api_file(self, method, qs):
        fs = self.target(qs.get("path", ""))
        if not fs.is_file():
            raise ApiError(404, "File non trovato")
        if fs.stat().st_size > MAX_TEXT_READ:
            raise ApiError(413, "File troppo grande per l'editor")
        data = fs.read_bytes()
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            text = data.decode("latin-1")
        return {"path": self.url_of(fs), "content": text, "mtime": int(fs.stat().st_mtime)}

    def api_check(self, method, qs):
        body = self._read_json()
        ext = body.get("ext") or Path(body.get("path", "")).suffix
        return self.check_code(ext, body.get("content", ""))

    def target(self, url_path: str) -> Path:
        """Come fs_path, ma un indirizzo che finisce in una cartella (es. /sito/) vale la sua index.html."""
        fs = self.fs_path(url_path)
        if fs.is_dir():
            for name in ("index.html", "index.htm"):
                if (fs / name).is_file():
                    return fs / name
            return fs / "index.html"
        return fs

    @staticmethod
    def _check_writable(fs: Path) -> None:
        if fs.suffix.lower() in BLOCKED_UPLOAD_EXT:
            raise ApiError(400, "Il salvataggio di file PHP e database non e' consentito")

    def api_write(self, method, qs):
        body = self._read_json()
        fs = self.target(body.get("path", ""))
        self._check_writable(fs)
        content = body.get("content", "")
        result = self.check_code(fs.suffix, content)
        if not result["ok"] and not (body.get("skipCheck") and not result.get("available", True)):
            raise ApiError(422, "Verifica del compilatore fallita: file NON salvato", check=result)
        if not fs.parent.exists():
            raise ApiError(404, "Cartella inesistente")
        backup_ok = self._backup(fs)
        fs.write_text(content, encoding="utf-8", newline="")
        return {"ok": True, "path": self.url_of(fs), "check": result, "backup": backup_ok}

    def api_save_page(self, method, qs):
        body = self._read_json()
        fs = self.target(body.get("path", ""))
        self._check_writable(fs)
        html = body.get("html", "")
        if not isinstance(html, str) or "<" not in html:
            raise ApiError(400, "HTML non valido")
        backup_ok = self._backup(fs)
        fs.parent.mkdir(parents=True, exist_ok=True)
        fs.write_text(html, encoding="utf-8", newline="")
        return {"ok": True, "path": self.url_of(fs), "bytes": len(html.encode("utf-8")), "backup": backup_ok}

    def api_upload(self, method, qs):
        if method != "POST":
            raise ApiError(405, "Usa POST")
        raw_name = os.path.basename(unquote(qs.get("name", "file.bin")).replace("\\", "/")).strip()
        ext = Path(raw_name).suffix.lower()
        if not re.fullmatch(r"\.[a-z0-9]{1,10}", ext):
            ext = ".bin"
        if ext in BLOCKED_UPLOAD_EXT:
            raise ApiError(400, "Upload di file PHP e database non consentito")
        folder = self.fs_path(qs.get("dir", "/_uploads"))
        # un componente del percorso che e' un FILE (es. /index.html/_uploads) farebbe fallire
        # mkdir con "il file esiste gia'": in quel caso si carica nella cartella _uploads della radice
        p = folder
        while p != self.root.resolve() and p != p.parent:
            if p.is_file():
                folder = self.fs_path("/_uploads/" + folder.name)
                break
            p = p.parent
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise ApiError(400, f"Impossibile creare la cartella di destinazione: {e}")
        # nome sempre nuovo e casuale (uuid): niente collisioni ne' sovrascritture
        dest = folder / f"{uuid.uuid4().hex}{ext}"
        while dest.exists():
            dest = folder / f"{uuid.uuid4().hex}{ext}"
        data = self._read_body(MAX_UPLOAD)
        dest.write_bytes(data)
        return {"ok": True, "path": self.url_of(dest), "size": len(data), "original": raw_name}

    def _backup_dirs(self, fs: Path) -> List[Path]:
        """Cartella attuale + quella del vecchio formato (percorso completo), se esiste."""
        dirs = [self._backup_dir(fs)]
        try:
            legacy = self.root / BACKUP_DIR / fs.resolve().relative_to(self.root.resolve())
            if legacy.is_dir():
                dirs.append(legacy)
        except OSError:
            pass
        return dirs

    def api_backups(self, method, qs):
        fs = self.target(qs.get("path", ""))
        items = []
        for d in self._backup_dirs(fs):
            if d.is_dir():
                items += [{"stamp": b.stem, "size": b.stat().st_size} for b in d.glob("*.bak")]
        items.sort(key=lambda x: x["stamp"], reverse=True)
        return {"backups": items}

    def api_restore(self, method, qs):
        body = self._read_json()
        fs = self.target(body.get("path", ""))
        stamp = re.sub(r"[^\w\-]", "", str(body.get("stamp", "")))
        src = next((d / f"{stamp}.bak" for d in self._backup_dirs(fs) if (d / f"{stamp}.bak").is_file()), None)
        if src is None:
            raise ApiError(404, "Backup non trovato")
        self._backup(fs)
        shutil.copy2(src, fs)
        return {"ok": True}


def install_toolbar(root: str, remove: bool = False) -> tuple:
    """
    Aggiunge (o toglie) la toolbar a tutte le pagine .html di un clone
    GIA' scaricato, senza riscaricare nulla. Ritorna (pagine_modificate, totale).
    Idempotente: le pagine che hanno gia' la toolbar non vengono toccate.
    """
    from .utils import relative_path

    root_path = Path(root).resolve()
    toolbar = root_path / "_sitecloner_editor" / "toolbar.js"
    marker = "data-sitecloner-editor"
    tag_re = re.compile(r"<script[^>]*data-sitecloner-editor[^>]*>\s*</script>", re.IGNORECASE)
    changed = total = 0
    for dirpath, dirnames, filenames in os.walk(root_path):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if Path(fn).suffix.lower() not in (".html", ".htm", ".xhtml"):
                continue
            total += 1
            p = Path(dirpath) / fn
            raw = p.read_bytes()
            try:
                text, enc = raw.decode("utf-8"), "utf-8"
            except UnicodeDecodeError:
                text, enc = raw.decode("latin-1"), "latin-1"
            if remove:
                new = tag_re.sub("", text)
            elif marker in text:
                continue
            else:
                rel = relative_path(str(p), str(toolbar))
                tag = (f'<script src="{rel}" charset="utf-8" defer="defer" '
                       f'{marker}="1"></script>')
                new = text.replace("</body>", tag + "</body>", 1) if "</body>" in text else text + tag
            if new != text:
                p.write_bytes(new.encode(enc))
                changed += 1
    if not remove:
        toolbar.parent.mkdir(parents=True, exist_ok=True)
        toolbar.write_text(build_toolbar_js(), encoding="ascii")
    return changed, total


def refresh_toolbar_files(root: str) -> int:
    """
    Riscrive con la versione corrente tutte le copie statiche di toolbar.js presenti nel clone
    (cartelle _sitecloner_editor). Il server le sostituisce comunque al volo, ma una copia vecchia
    resterebbe in uso aprendo le pagine con doppio click o da un altro server: mancherebbero le
    funzioni nuove (es. il bottone personalizzato in Inserisci).
    """
    root_path = Path(root).resolve()
    fresh = build_toolbar_js()
    n = 0
    for dirpath, dirnames, _files in os.walk(root_path):
        dirnames[:] = [d for d in dirnames if d not in (BACKUP_DIR, ".git", "node_modules", "__pycache__")]
        if Path(dirpath).name == "_sitecloner_editor":
            f = Path(dirpath) / "toolbar.js"
            try:
                if not f.exists() or f.read_text(encoding="ascii", errors="replace") != fresh:
                    f.write_text(fresh, encoding="ascii")
                    n += 1
            except OSError:
                pass
    return n


def make_server(root: str, host: str = "127.0.0.1", port: int = 8000, verbose: bool = False):
    root_path = Path(root).resolve()
    if not root_path.is_dir():
        raise SystemExit(f"Cartella non trovata: {root_path}")
    handler = functools.partial(EditorHandler, directory=str(root_path))
    last_err: Optional[Exception] = None
    for p in range(port, port + 30):
        try:
            httpd = QuietServer((host, p), handler)
            break
        except OSError as e:
            last_err = e
    else:
        raise SystemExit(f"Nessuna porta libera a partire da {port}: {last_err}")
    httpd.sc_root = root_path  # type: ignore[attr-defined]
    httpd.sc_token = secrets.token_urlsafe(24)  # type: ignore[attr-defined]
    httpd.sc_verbose = verbose  # type: ignore[attr-defined]
    return httpd


def serve(root: str, port: int = 8000, open_path: Optional[str] = None,
          open_browser: bool = False, verbose: bool = False) -> None:
    httpd = make_server(root, "127.0.0.1", port, verbose)
    updated = refresh_toolbar_files(root)
    actual = httpd.server_address[1]
    base = f"http://127.0.0.1:{actual}"
    print("=" * 78)
    print(f"  Server di editing attivo su {base}  (solo questo PC)")
    print(f"  Cartella servita: {httpd.sc_root}")  # type: ignore[attr-defined]
    print(f"  node: {'si' if find_tool('node') else 'NO'} (per verificare gli script .js)")
    if updated:
        print(f"  Toolbar aggiornata all'ultima versione in {updated} file")
    if open_path:
        print(f"  Apri: {base}{quote(open_path)}")
    print("  CTRL+C per fermare")
    print("=" * 78)
    if open_browser and open_path:
        threading.Timer(0.6, lambda: webbrowser.open(base + quote(open_path))).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer fermato.")
    finally:
        httpd.server_close()
