"""
registry.py
===========
Tracciamento thread-safe degli URL.

Miglioramenti:
- get_path_by_hash(): permette la deduplica content-hash in _process_task
- _hash_to_path: mapping hash -> primo path locale (per link_or_copy)
- snapshot() ora include anche hash_count per stats
"""

from __future__ import annotations
import threading
from enum import Enum
from typing import Dict, Optional, Set, Tuple


class UrlState(Enum):
    DISCOVERED = "discovered"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    FAILED = "failed"
    SKIPPED = "skipped"


class UrlRegistry:
    """Registro thread-safe di URL e dei loro path locali."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._state: Dict[str, UrlState] = {}
        self._local_path: Dict[str, str] = {}
        self._content_hashes: Set[str] = set()
        self._hash_to_path: Dict[str, str] = {}   # NUOVO: hash -> local_path
        self._final_url: Dict[str, str] = {}
        self.stats: Dict[str, int] = {
            "discovered": 0, "in_progress": 0,
            "done": 0, "failed": 0, "skipped": 0,
            "bytes_downloaded": 0, "deduped": 0,
        }

    # ------------------------------------------------------------------
    # Stato URL
    # ------------------------------------------------------------------

    def mark_discovered(self, url: str) -> bool:
        with self._lock:
            if url in self._state:
                return False
            self._state[url] = UrlState.DISCOVERED
            self.stats["discovered"] += 1
            return True

    def try_acquire(self, url: str) -> bool:
        with self._lock:
            current = self._state.get(url)
            if current in (UrlState.DISCOVERED, None):
                self._state[url] = UrlState.IN_PROGRESS
                self.stats["in_progress"] += 1
                return True
            return False

    def release(self, url: str) -> None:
        """Rimette in coda un URL in corso (es. per riprovare dopo un errore transitorio)."""
        with self._lock:
            if self._state.get(url) == UrlState.IN_PROGRESS:
                self._state[url] = UrlState.DISCOVERED
                self.stats["in_progress"] = max(0, self.stats["in_progress"] - 1)

    def mark_done(self, url: str, *, bytes_size: int = 0) -> None:
        with self._lock:
            self._state[url] = UrlState.DONE
            self.stats["done"] += 1
            self.stats["bytes_downloaded"] += bytes_size

    def mark_failed(self, url: str) -> None:
        with self._lock:
            self._state[url] = UrlState.FAILED
            self.stats["failed"] += 1

    def mark_skipped(self, url: str) -> None:
        with self._lock:
            if url not in self._state:
                self._state[url] = UrlState.SKIPPED
                self.stats["skipped"] += 1

    def get_state(self, url: str) -> Optional[UrlState]:
        with self._lock:
            return self._state.get(url)

    def is_known(self, url: str) -> bool:
        with self._lock:
            return url in self._state

    # ------------------------------------------------------------------
    # Mapping URL -> path locale
    # ------------------------------------------------------------------

    def set_local_path(self, url: str, local_path: str) -> None:
        with self._lock:
            self._local_path[url] = local_path

    def get_local_path(self, url: str) -> Optional[str]:
        with self._lock:
            return self._local_path.get(url)

    def all_mappings(self) -> Dict[str, str]:
        with self._lock:
            return dict(self._local_path)

    # ------------------------------------------------------------------
    # Redirect tracking
    # ------------------------------------------------------------------

    def set_final_url(self, original: str, final: str) -> None:
        if original != final:
            with self._lock:
                self._final_url[original] = final
                if final in self._local_path and original not in self._local_path:
                    self._local_path[original] = self._local_path[final]

    def resolve_final(self, url: str) -> str:
        with self._lock:
            return self._final_url.get(url, url)

    def reconcile_redirects(self) -> int:
        """
        Da chiamare a fine crawl, prima della fase di riscrittura.

        FIX: un URL che reindirizza (redirect) verso una pagina scoperta ma
        scartata/fallita *dopo* che il redirect è stato registrato (o
        scaricata con successo da un altro worker in una race) non riceve
        mai un local_path in `_process_task` (quel metodo esce subito dopo
        `set_final_url` se `mark_discovered(final_url)` fallisce). Qui
        seguiamo ogni catena original -> final fino in fondo e copiamo il
        local_path del target su tutti gli URL originali che ancora non ne
        hanno uno, così il rewriter può risolverli verso il file locale
        invece di lasciarli come URL assoluti del sito live.

        Ritorna il numero di mapping aggiunti.
        """
        with self._lock:
            added = 0
            for original in list(self._final_url.keys()):
                if original in self._local_path:
                    continue
                # Segue la catena di redirect (con guardia anti-loop)
                target = original
                seen = set()
                while target in self._final_url and target not in seen:
                    seen.add(target)
                    target = self._final_url[target]
                local_target = self._local_path.get(target)
                if local_target:
                    self._local_path[original] = local_target
                    added += 1
            return added

    # ------------------------------------------------------------------
    # Deduplica per content-hash (FIX: aggiunto get_path_by_hash)
    # ------------------------------------------------------------------

    def seen_hash(self, content_hash: str) -> bool:
        with self._lock:
            return content_hash in self._content_hashes

    def add_hash(self, content_hash: str, local_path: str = "") -> None:
        with self._lock:
            is_new = content_hash not in self._content_hashes
            self._content_hashes.add(content_hash)
            if is_new and local_path:
                self._hash_to_path[content_hash] = local_path
            elif not is_new:
                self.stats["deduped"] += 1

    def get_path_by_hash(self, content_hash: str) -> Optional[str]:
        """Ritorna il path locale del primo file con questo hash (per link_or_copy)."""
        with self._lock:
            return self._hash_to_path.get(content_hash)

    # ------------------------------------------------------------------
    # Snapshot statistiche
    # ------------------------------------------------------------------

    def snapshot(self) -> Tuple[Dict[str, int], int]:
        with self._lock:
            s = dict(self.stats)
            s["hash_deduped"] = s.pop("deduped", 0)
            return s, len(self._state)
