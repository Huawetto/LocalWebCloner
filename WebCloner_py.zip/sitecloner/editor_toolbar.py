"""
editor_toolbar.py
==================
Assembla la toolbar di editing GUI locale (JavaScript) iniettata in ogni
pagina clonata quando l'utente lo richiede (CrawlerConfig.add_editor_toolbar).

Il codice JS vive in sitecloner/editor_js/*.js (un file per area funzionale)
e viene concatenato in ordine alfabetico dentro un'unica IIFE: nessuna
dipendenza esterna, nessuna chiamata di rete (deve funzionare 100% offline).

Il risultato e' puro ASCII (ogni carattere non-ASCII diventa \\uXXXX):
l'interpretazione di \\uXXXX dentro una stringa JS non dipende dal charset
con cui il file viene servito (file://, server statico senza header, ...).

Il token di sessione dell'editor-server viene sostituito al segnaposto
__SC_TOKEN__ solo quando il file e' servito da editor_server.py; il file
statico scritto su disco contiene il segnaposto e quindi funziona solo in
modalita' "senza server" (download invece di salvataggio diretto).
"""

from __future__ import annotations
from pathlib import Path

JS_DIR = Path(__file__).resolve().parent / "editor_js"
TOKEN_PLACEHOLDER = "__SC_TOKEN__"


def _escape_non_ascii(src: str) -> str:
    out = []
    for ch in src:
        cp = ord(ch)
        if cp < 128:
            out.append(ch)
        elif cp <= 0xFFFF:
            out.append("\\u%04x" % cp)
        else:  # carattere "astral": coppia surrogata UTF-16
            cp -= 0x10000
            out.append("\\u%04x\\u%04x" % (0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF)))
    return "".join(out)


def build_toolbar_js(token: str | None = None) -> str:
    parts = []
    for f in sorted(JS_DIR.glob("*.js")):
        parts.append(f"/* ---- {f.name} ---- */\n" + f.read_text(encoding="utf-8"))
    body = "\n".join(parts)
    src = '(function () {\n"use strict";\n' + body + "\n})();\n"
    if token:
        src = src.replace(TOKEN_PLACEHOLDER, token)
    return _escape_non_ascii(src)


TOOLBAR_JS = build_toolbar_js()
