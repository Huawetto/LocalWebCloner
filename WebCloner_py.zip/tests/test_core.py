"""
Test di base di SiteCloner (solo libreria standard + dipendenze del progetto).

    python -m unittest discover -s tests -v
"""
import json
import os
import shutil
import subprocess
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from bs4 import BeautifulSoup

from sitecloner.editor_server import make_server, refresh_toolbar_files
from sitecloner.editor_toolbar import build_toolbar_js
from sitecloner.registry import UrlRegistry
from sitecloner.rewriter import LinkRewriter
from sitecloner.utils import (
    ResourceKind,
    classify_url,
    is_cms_internal_url,
    looks_like_login_page,
    normalize_url,
    relative_path,
    sniff_binary,
    url_to_local_path,
)


class UtilsTests(unittest.TestCase):
    def test_normalize_url_strips_fragment_and_tracking(self):
        u = normalize_url("../a/b.html?utm_source=x&id=3#top", "https://Example.com/x/y/z.html")
        self.assertEqual(u, "https://example.com/x/a/b.html?id=3")

    def test_normalize_url_rejects_non_http(self):
        for bad in ("mailto:a@b.it", "javascript:void(0)", "tel:123", "data:text/plain,hi"):
            self.assertIsNone(normalize_url(bad, "https://example.com/"))

    def test_local_path_and_relative_path(self):
        base = os.path.abspath("out")
        page = url_to_local_path("https://example.com/a/", base, "example.com", ResourceKind.HTML)
        img = url_to_local_path("https://example.com/img/x.png", base, "example.com", ResourceKind.IMAGE)
        self.assertTrue(page.endswith(os.path.join("a", "index.html")))
        self.assertEqual(relative_path(page, img), "../img/x.png")

    def test_classify_binary_download_is_not_html(self):
        self.assertEqual(classify_url("https://x/get.php?id=1", "application/octet-stream"), ResourceKind.OTHER)
        self.assertEqual(classify_url("https://x/page.php", "text/html"), ResourceKind.HTML)

    def test_sniff_binary(self):
        self.assertEqual(sniff_binary(b"\xff\xd8\xff\xe0abc"), (ResourceKind.IMAGE, ".jpg"))
        self.assertEqual(sniff_binary(b"%PDF-1.7"), (ResourceKind.DOCUMENT, ".pdf"))
        self.assertIsNone(sniff_binary("<html>àè</html>".encode("utf-8")))

    def test_cms_endpoints(self):
        for u in ("https://x/wp-json/wp/v2/pages/1", "https://x/xmlrpc.php?rsd", "https://x/feed/", "https://x/wp-admin/a.php"):
            self.assertTrue(is_cms_internal_url(u), u)
        for u in ("https://x/chi-siamo/", "https://x/feedback/", "https://x/wp-content/uploads/a.png"):
            self.assertFalse(is_cms_internal_url(u), u)

    def test_login_page_detection(self):
        login = b'<html><body class="login wp-core-ui"><form method="post"><input type="password"></form></body></html>'
        home = (b'<html><head><title>Home</title></head><body class="home"><form method="post" name="loginform">'
                b'<input type="password"></form><p>contenuto</p></body></html>')
        self.assertTrue(looks_like_login_page(login))
        self.assertFalse(looks_like_login_page(home))


class StorageTests(unittest.TestCase):
    def test_output_folder_gets_gitignore(self):
        from sitecloner.storage import Storage
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "pappagallo_bar"
            Storage(str(out))
            self.assertEqual((out / ".gitignore").read_text(encoding="utf-8").splitlines()[-1], "*")
            proj = Path(td) / "progetto"
            proj.mkdir()
            (proj / "pyproject.toml").write_text("", encoding="utf-8")
            Storage(str(proj))
            self.assertFalse((proj / ".gitignore").exists())  # non tocca una cartella che e' un progetto


class RegistryRewriterTests(unittest.TestCase):
    def test_reconcile_redirects(self):
        r = UrlRegistry()
        r.mark_discovered("https://s.com/new")
        r.mark_skipped("https://s.com/new")
        r.set_final_url("https://s.com/old", "https://s.com/new")
        r.set_local_path("https://s.com/new", "/out/new.html")
        self.assertEqual(r.reconcile_redirects(), 1)
        self.assertEqual(r.get_local_path("https://s.com/old"), "/out/new.html")

    def test_rewriter_local_and_absolute_fallback(self):
        mapping = {"https://s.com/a/": "/out/s.com/a/index.html"}
        soup = BeautifulSoup('<a href="/a/">a</a><a href="/missing">m</a>', "html.parser")
        out = LinkRewriter(mapping).rewrite_html(soup, "https://s.com/", "/out/s.com/index.html")
        self.assertIn('href="a/index.html"', out)
        self.assertIn('href="https://s.com/missing"', out)  # non scaricata -> URL assoluto, mai path rotto


class ToolbarBundleTests(unittest.TestCase):
    def test_bundle_is_ascii_and_has_features(self):
        js = build_toolbar_js("TOKEN")
        js.encode("ascii")  # solleva se resta un carattere non ASCII
        for marker in ("openButtonBuilder", "openPaint", "siteWide", "TOKEN"):
            self.assertIn(marker, js)

    @unittest.skipUnless(shutil.which("node"), "node non installato")
    def test_bundle_syntax_with_node(self):
        with tempfile.TemporaryDirectory() as td:
            f = Path(td) / "toolbar.js"
            f.write_text(build_toolbar_js("x"), encoding="ascii")
            r = subprocess.run(["node", "--check", str(f)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)

    def test_refresh_toolbar_files(self):
        with tempfile.TemporaryDirectory() as td:
            d = Path(td) / "site" / "_sitecloner_editor"
            d.mkdir(parents=True)
            (d / "toolbar.js").write_text("old", encoding="ascii")
            self.assertEqual(refresh_toolbar_files(td), 1)
            self.assertEqual(refresh_toolbar_files(td), 0)
            self.assertIn("openButtonBuilder", (d / "toolbar.js").read_text(encoding="ascii"))


class EditorServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        root = Path(cls.tmp)
        (root / "www.sito.it").mkdir()
        (root / "www.sito.it" / "index.html").write_text("<html><body><p>x</p></body></html>", encoding="utf-8")
        cls.httpd = make_server(cls.tmp, "127.0.0.1", 0)
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()
        cls.port = cls.httpd.server_address[1]
        cls.token = cls.httpd.sc_token

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def call(self, path, body=None, raw=None, token=None, host=None):
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        headers = {"X-SC-Token": self.token if token is None else token, "Content-Type": "application/json"}
        if host:
            headers["Host"] = host
        req = urllib.request.Request(f"http://127.0.0.1:{self.port}/__sc__/{path}", data=data, headers=headers)
        try:
            r = urllib.request.urlopen(req, timeout=5)
            return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())

    def test_auth(self):
        self.assertEqual(self.call("ping")[0], 200)
        self.assertEqual(self.call("ping", token="sbagliato")[0], 403)
        self.assertEqual(self.call("ping", host="evil.example")[0], 403)

    def test_path_traversal_blocked(self):
        self.assertEqual(self.call("file?path=/../../etc/passwd")[0], 403)

    def test_upload_uuid_names_and_blocked_types(self):
        names = set()
        for _ in range(3):
            st, r = self.call("upload?dir=/www.sito.it/_uploads/images&name=Foto.JPG", raw=b"data")
            self.assertEqual(st, 200)
            self.assertRegex(r["path"], r"/[0-9a-f]{32}\.jpg$")
            names.add(r["path"])
        self.assertEqual(len(names), 3)
        for bad in ("a.php", "b.PHTML", "c.sqlite", "d.sql"):
            self.assertEqual(self.call(f"upload?dir=/_uploads&name={bad}", raw=b"x")[0], 400, bad)

    def test_upload_when_dir_component_is_a_file(self):
        st, r = self.call("upload?dir=/www.sito.it/index.html/_uploads/images&name=a.png", raw=b"x")
        self.assertEqual(st, 200)

    def test_save_page_by_directory_url_and_backup(self):
        html = "<html><body><p>nuovo</p></body></html>"
        st, r = self.call("save-page", {"path": "/www.sito.it/", "html": html})
        self.assertEqual(st, 200)
        self.assertEqual((Path(self.tmp) / "www.sito.it" / "index.html").read_text(encoding="utf-8"), html)
        self.assertTrue(r["backup"])

    def test_php_cannot_be_written(self):
        self.assertEqual(self.call("write", {"path": "/www.sito.it/a.php", "content": "<?php"})[0], 400)

    @unittest.skipUnless(shutil.which("node"), "node non installato")
    def test_js_compiler_check_blocks_bad_code(self):
        st, r = self.call("write", {"path": "/www.sito.it/a.js", "content": "var a = ;"})
        self.assertEqual(st, 422)
        self.assertFalse((Path(self.tmp) / "www.sito.it" / "a.js").exists())
        st, _ = self.call("write", {"path": "/www.sito.it/a.js", "content": "var a = 1;\n"})
        self.assertEqual(st, 200)


if __name__ == "__main__":
    unittest.main()
